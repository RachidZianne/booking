<?php

namespace App\Http\Controllers;

use App;
use App\Language;
use App\UserPreference;
use Exception;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Lang;
use Redirect;
use Response;

class LanguagesController extends Controller
{

    public function index()
    {
        View::share('sub_highlight', 'settings_languages');
        $data['languages'] = Language::all();
        return View::make('admin.languages.index',$data);
    }

    public function add()
    {
        $data = array();
        return View::make('admin.languages.new',$data);
    }

    public function easyTranslator()
    {
        $data = [];
        $data['sections'] = lang_get_phrases("en");
        return view("admin.languages.easy_translator",$data);

    }

    public function saveEasyTranslator(Request $request)
    {
        $title = $request->input('title');
        $locale = $request->input('locale');
        $language = Language::where("code",$locale)->first();
        if(!empty($language))
        {
            // already exists
            return Redirect::back()->withInput($request->all())->with('error',trans('messages.lang_exist_err'));
        }
        $data['title'] = $title;
        $data['locale'] = $locale;
        $data['language'] =  $request->input('language');
        $data['author'] =  $request->input('author');
        $data['link'] =  $request->input('link');
        $xml = View::make("admin.languages.translator_template",$data)->render();
        Language::installPayload($xml);
        return redirect()->route("admin.languages.index")->with('status',trans('messages.modeladded'));
    }

    public function updateLanguage(Request $request,$id)
    {

        $english = lang_get_phrases("en");
        $language = Language::findOrFail($id);
        $foreign  = $language->code;
        $foreign = lang_get_phrases($foreign);
        $differences = array_key_diff_recursive($english,$foreign);
        if(empty($differences))
        {
            return redirect()->route("admin.languages.index")->with('status',trans('messages.languptodate'));
        }
        $data['language'] = $language;
        $data['sections'] = $differences;
        return view("admin.languages.update_translator",$data);
    }

    public function deleteLanguage(Request $request)
    {
        $lang = $request->input('model_id');
        $language = Language::find($lang);
        $locale = $language->code;

        // delete directory
        if(!empty($locale))
        {
            File::deleteDirectory(lang_path($locale));
        }

        UserPreference::where("key","=","language")->where("value","=",$locale)->delete();
        $language->delete();
        Language::regenerateJS();

        return redirect()->route("admin.languages.index")->with('status',trans('messages.modeldeleted'));

    }
    public function defaultLanguage(Request $request)
    {
        $lang = $request->input('model_id');
        $language = Language::find($lang);
        $locale = $language->code;
        \Config::write("app",['locale' => $locale]);

        return redirect()->route("admin.languages.index")->with('status',trans("messages.langdefault"));

    }

    public function SaveUpdateLanguage(Request $request,$id)
    {

        $language = Language::findOrFail($id);
        $foreign  = $language->code;
        $foreign = lang_get_phrases($foreign);

        if($request->hasFile('langfile'))
        {
            $xml = File::get($request->file('langfile')->getRealPath());
        }
        else{
            $new_phrases = $request->input('language');
            $data['title'] = $language->language;
            $data['author'] = $language->author;
            $data['link'] = $language->author_url;
            $data['locale'] = $language->code;
            $data['language'] = array_merge_recursive($foreign,$new_phrases);
            $xml = View::make("admin.languages.translator_template",$data)->render();
        }
        Language::installPayload($xml,false);

        return redirect()->route("admin.languages.index")->with('status',trans('messages.modelupdated'));

    }

    public function create(Request $request)
    {
        if (!($request->hasFile('language')))
        {
            return redirect()->route("admin.languages.add")->with('error',trans("messages.missingfile") );
        }
        if($request->file('language')->getClientOriginalExtension() != "xml"){
            return redirect()->route("admin.languages.add")->with('error',trans("messages.invalidfiletype") );
        }
        $languageFile = $request->file('language');
        try{
            Language::installFile($languageFile->getRealPath());
        }
        catch(Exception $e){
            return redirect()->route("admin.languages.add")->with('error',$e->getMessage());
        }
        return redirect()->route("admin.languages.index")->with('status',trans("messages.modeladded") );
    }

    public function getExport($id)
    {
        $language = Language::findOrFail($id);
        $foreign = lang_get_phrases($language->code);
        $data['title'] = $language->language;
        $data['author'] = $language->author;
        $data['link'] = $language->author_url;
        $data['locale'] = $language->code;
        $data['language'] = $foreign;
        $responsedata = View::make("admin.languages.export_template",$data)->render();
        $response =  Response::make($responsedata);
        $filename = $language->code.".xml";
        $response->header('Content-Type', "application/octet-stream");
        $response->header('Content-Disposition', "attachment; filename=$filename");
        return $response;
    }



}
