<?php

namespace App\Http\Controllers;

use App\Project;
use App\Team;
use Illuminate\Http\Request;

class InsightController extends Controller
{
    public function teams()
    {
        $data['teams'] = Team::with("tasks")->get();
        $date = new \Carbon\Carbon;

        $date->subWeek()->addDay()->startOfDay();

        $teams_data = Team::with(["tasks" => function($q)use($date){
            $q->done()->where('done_at', '>', $date->toDateTimeString() );
        }])->get();

        $teamlist = collect([]);
        $teamlist_arr = [];
        foreach($teams_data as $td)
        {
          $newDate = $date->copy();
          $team_id = $td->id;
          $teamlist[$team_id] = $tgrouped = $td->tasks->groupBy(function($item) {
              return $item->done_at->format('Y-m-d');
          })->map(function ($item) {
              return count($item);
          });

          for($i=0;$i<7;$i++)
          {
              $dateString = $newDate->toDateString();
              if(!isset($teamlist[$team_id][$dateString])){
                  $teamlist[$team_id][$dateString] = 0;
              }
              $newDate->addDay();
          }
            $sortable = $teamlist[$team_id]->toArray();
            ksort($sortable);
            $teamlist_arr[$team_id] = $sortable;
        }

        $data['team_data'] = json_encode($teamlist_arr);

        return view("insights.teams",$data);
    }

    public function projects()
    {
        $data['allprojects'] = Project::notpersonal()->with("tasks")->orderBy('id','desc')->paginate(20);
        $date = new \Carbon\Carbon;

        $date->subWeek()->addDay()->startOfDay();

        $project_data = Project::notpersonal()->with(["tasks" => function($q)use($date){
            $q->done()->where('done_at', '>', $date->toDateTimeString() );
        }])->orderBy('id','desc')->paginate(20);

        $project_data = $project_data->keyBy("id");
        $prjlist = collect([]);
        $projlist_arr = [];
        foreach($project_data as $td)
        {
            $newDate = $date->copy();
            $pr_id = $td->id;
            $prjlist[$pr_id] = $tgrouped = $td->tasks->groupBy(function($item) {
                return $item->done_at->format('Y-m-d');
            })->map(function ($item) {
                return count($item);
            });

            for($i=0;$i<7;$i++)
            {
                $dateString = $newDate->toDateString();
                if(!isset($prjlist[$pr_id][$dateString])){
                    $prjlist[$pr_id][$dateString] = 0;
                }
                $newDate->addDay();
            }
            $sortable = $prjlist[$pr_id]->toArray();
            ksort($sortable);
            $projlist_arr[$pr_id] = $sortable;
        }
        $data['project_data'] = json_encode($projlist_arr);

        return view("insights.projects",$data);

    }

}
