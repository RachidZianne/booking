<?php

namespace App\Http\Controllers\Api;

use App\TaskSection;
use App\Team;
use App\TeamUser;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TeamController extends ApiController
{

    public function getTeam($id){
        return $this->respond(Team::find($id));
    }

   public function createTeam(Request $request){
        $title = $request->input('title');
        $team = new Team;
        $team->title = $title;
        $team->save();
        return $this->respond($team);
    }

   public function addUser(Request $request,$team){
        $user = $request->input('user_id');

        $umodel = User::where("id",$user)->firstOrFail();
        $uteam = Team::where("id",$team)->firstOrFail();

        $creatable = [
            'user_id' => $user,
            'team_id' => $team
        ];
        $ut = TeamUser::firstOrCreate($creatable);

        return $this->respond($creatable);
    }

   public function removeUser(Request $request,$team){

        $user = $request->input('user_id');
        $umodel = User::where("id",$user)->firstOrFail();
        $uteam = Team::where("id",$team)->firstOrFail();

        $creatable = [
            'user_id' => $user,
            'team_id' => $team
        ];
        $ut = TeamUser::where($creatable)->first();
        if(!empty($ut)){
            $ut->delete();
        }
        else{
            $creatable = [];
        }
        return $this->respond($creatable);
    }

   public function listUsers(Request $request,$team){
        $uteams = TeamUser::where("team_id",$team)->select('user_id')->get()->pluck('user_id');
        return $this->respond($uteams);
    }

   public function allTeams(Request $request){
        $teams = Team::select('id','title','created_at')->paginate(100);
        return $this->respond($teams);
    }

    public function getTeamSections(Request $request,$id)
    {

        $sections = TaskSection::where("team_id","=",$id)->paginate(100);
        return $this->respond($sections);

    }

}
