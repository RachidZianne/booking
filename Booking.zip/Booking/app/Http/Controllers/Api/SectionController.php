<?php

namespace App\Http\Controllers\Api;

use App\Project;
use App\TaskSection;
use App\Team;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SectionController extends ApiController
{

    public function overview(Request $request)
    {
        if(!$this->isBearer()){
            $this->setStatusCode(403);
            return $this->respond();
        }

        $with_archive = (bool)$request->input("archive",false);
        $sections = TaskSection::allowed()->with(["tasks" => function($q) use($with_archive){
            $q->archived($with_archive);
        },'tasks.subtasks'])->orderBy("id","desc")->paginate(50);
        return $this->respond($sections);

    }

    public function getSection($id)
    {
        $section = TaskSection::select(['id','title','team_id','project_id']);
        if($this->isBearer()){
            $section = $section->allowed();
        }
        $section = $section->findOrFail($id);
        return $this->respond($section);
    }

    public function moveSection(Request $request,$id)
    {
        $team_id = $request->input('team_id');
        $project_id = $request->input('project_id');
        $team = null;
        $project = null;

        $section = TaskSection::select(['id','title','team_id','project_id']);
        if($this->isBearer()){
            $section = $section->allowed();
        }
        $section = $section->findOrFail($id);

        if(!empty($team_id))
        {
            $team = Team::find($team_id);
            $section->team_id = $team;
            $section->project_id = null;
        }
        elseif(!empty($project_id)){
            $project = Project::find($project_id);
            $section->project_id = $project_id;
            $section->team_id = null;
        }
        else{
            $this->setStatusCode(428);
            return $this->respond();
        }
        $section->save();
        return $this->respond($section);
    }

    public function renameSection(Request $request,$id)
    {
        $title = $request->input('title');
        $section = TaskSection::select(['id','title','team_id','project_id']);
        if($this->isBearer()){
            $section = $section->allowed();
        }
        $section = $section->findOrFail($id);
        if(!empty($title))
        {
            $section->title = $title;
            $section->save();
            return $this->respond($section);
        }else{
            $this->setStatusCode(400);
            return $this->respond();
        }
    }

    public function createSection(Request $request)
    {
        $type = strtolower($request->input('type'));
        $title = $request->input('title');
        $model_id = $request->input('model_id');

        if($type != "team" || $type != "project" || empty($title))
        {
            $this->setStatusCode(400);
            return $this->respond();
        }

        $section = new TaskSection;
        $section->title = $title;
        if($type == 'team')
        {
            $section->team_id = $model_id;
        }
        elseif($type == 'project')
        {
            $section->project_id = $model_id;
        }

        if($this->isBearer())
        {
            if(!empty($section->project_id))
            {
                if(!Auth::user()->hasProjectAccess($section->project_id)){
                    $this->setStatusCode(403);
                    $this->respond();
                }
            }
            elseif(!empty($section->team_id))
            {
                if(!Auth::user()->hasTeamAccess($section->team_id)){
                    $this->setStatusCode(403);
                    $this->respond();
                }
            }
        }

        $section->save();
        return $this->respond($section);
    }

    public function deleteSection(Request $request)
    {
        $section_id = $request->input('section_id');
        $section = TaskSection::findOrFail($section_id);
        if($this->isBearer())
        {
            if(!empty($section->project_id))
            {
                if(!Auth::user()->hasProjectAccess($section->project_id)){
                    $this->setStatusCode(403);
                    $this->respond();
                }
            }
            elseif(!empty($section->team_id))
            {
                if(!Auth::user()->hasTeamAccess($section->team_id)){
                    $this->setStatusCode(403);
                    $this->respond();
                }
            }
        }
        $section->delete();
        return $this->respond([
            'id' => $section_id,
            'deleted' => true
        ]);
    }

}
