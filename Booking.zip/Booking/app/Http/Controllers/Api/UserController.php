<?php

namespace App\Http\Controllers\Api;

use App\ActionLog;
use App\Http\Controllers\Api\ApiController;
use App\ProjectUser;
use App\TeamUser;
use App\User;
use Auth;
use Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserController extends ApiController
{

    public function getUser($id){
        return $this->respond(User::findOrFail($id));
    }

    public function searchUser($name){
        $users = User::where("name",'like',"%$name%")->paginate(100);
        return $this->respond($users);
    }

    public function createUser(Request $request){

        $name = $request->input('name');
        $email = $request->input('email');
        $type = $request->input('type');
        $password = $request->input('password');
        $teams = $request->input('teams');

        $user = new User;
        $user->name = $name;
        $user->email = $email;
        $user->type = $type;
        $user->password = Hash::make($password);
        $user->save();

        if(!empty($teams)){
            $new_teams = explode(',',$teams);
            foreach ($new_teams as $tm)
            {
                $tu = new TeamUser;
                $tu->team_id =  $tm;
                $tu->user_id = $user->id;
                $tu->save();
            }
        }

        return $this->respond($user);
    }

    public function updateUser(Request $request,$id){

        $name = $request->input('name');
        $email = $request->input('email');
        $type = $request->input('type');
        $password = $request->input('password');

        $user = User::findOrFail($id);

        if(!empty($name))
        {
            $user->name = $name;
        }

        if(!empty($email))
        {
            $user->email = $email;
        }

        if(!empty($type))
        {
            $user->type = $type;
        }

        if(!empty($password))
        {
            $user->password = Hash::make($password);
        }

        $user->save();

        return $this->respond($user);
    }


    public function deleteUser(Request $request){
        $user_id = (int) $request->input('user_id');
        $user = User::find($user_id);
        ActionLog::log(0,sprintf("Deleted user %s from API",$user->id));
        // Delete from teams & Other stuff
        TeamUser::where("user_id","=",$user->id)->delete();
        ProjectUser::where("user_id","=",$user->id)->delete();

        $user->delete();
        return $this->respond([
            'id' => $user_id,
            'deleted' => true
        ]);
    }

}
