<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\UserToken;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Settings;

class AuthController extends ApiController
{
    public function __construct(Request $request)
    {
        parent::__construct($request);
    }

    public function generate(Request $request)
        {
            $email = $request->input('email');
            $password = $request->input('password');

            if (Auth::attempt(['email' => $email, 'password' => $password],false,false)) {
                $user = Auth::getLastAttempted();
                $tokenLong = str_random(65);
                UserToken::where("user_id","=",$user->id)->delete();
                $token = new UserToken;
                $token->user_id = $user->id;
                $token->token = $tokenLong;
                $token->save();
                return $this->respond([
                    'token' => $tokenLong
                ]);
            }
            else{
                $this->setStatusCode(401);
                return $this->respond([
                    'message' => 'Invalid username or Password'
                ]);
            }

        }

        public function self(Request $request)
        {
             $self = User::find($this->getAuthUser());
             $self->accessible_teams = $self->getTeams();
            return $this->respond($self);
        }
}
