<?php

namespace App\Http\Controllers\Api;

use App\Project;
use App\ProjectTeam;
use App\ProjectUser;
use App\TaskSection;
use App\Team;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProjectController extends ApiController
{
    public function overview(Request $request)
    {
        if(!$this->isBearer()){
                $this->setStatusCode(403);
                return $this->respond();
        }
        $projects = Auth::user()->allowedProjects();
        return $this->respond($projects);

    }

    public function getProject(Request $request,$id)
    {
        $withables = [];

        if($this->isBearer()){
            if(!Auth::user()->hasProjectAccess($id)){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }

        $include_sections = $request->input('sections',false);
        if($include_sections == 'true')
        {
            $withables[] = "tasksections.tasks";
        }
        $project = Project::select(['id','user_id','title','privacy','created_at'])->with($withables)->find($id);
        return $this->respond($project);
    }

    public function getProjectSections(Request $request,$id)
    {
        if($this->isBearer()){
            if(!Auth::user()->hasProjectAccess($id)){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }
        $sections = TaskSection::where("project_id","=",$id)->paginate(100);
        return $this->respond($sections);

    }

    public function createProject(Request $request)
    {
        $title = $request->input('title');
        $privacy = $request->input('privacy');
        $user_id = $request->input('user_id');
        $project = new Project;

        if(!empty($user_id)){
            $project->user_id = $user_id;
        }

        if($this->isBearer()){
            $project->user_id = Auth::id();
        }

        $project->title = $title;
        $project->layout = 'kanban';
        $project->privacy = $privacy;
        $project->save();

        return $this->respond($project);

    }

    public function addTeamPrivacy(Request $request,$id)
    {
        $teams = $request->input('teams');
        $project = Project::find($id);
        if($this->isBearer()){
            if( (Auth::id() !=  $project->user_id) &&  !Auth::user()->isAdmin() ){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }
        if($project->privacy != 'teams')
        {
            $this->setStatusCode('406');
            return $this->respond();
        }

        $newList = explode(',',$teams);

        $teams = ProjectTeam::where("project_id","=",$project->id)->get()->pluck('team_id')->toArray();
        $new = array_diff($newList,$teams);
        if($new){
            foreach ($new as $key=>$team_id)
            {
                $pt = new ProjectTeam;
                $pt->project_id = $project->id;
                $pt->team_id = $team_id;
                $pt->save();
            }
        }

        return $this->respond();
    }

    public function removeTeamPrivacy(Request $request,$id)
    {
        $teams = $request->input('teams');
        $project = Project::find($id);
        if($this->isBearer()){
            if( (Auth::id() !=  $project->user_id) &&  !Auth::user()->isAdmin() ){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }
        if($project->privacy != 'teams')
        {
            $this->setStatusCode('406');
            return $this->respond();
        }

        $newList = explode(',',$teams);
        $teams = ProjectTeam::where("project_id","=",$project->id)->whereIn("team_id",$newList)->delete();
        return $this->respond();
    }

    public function addUserPrivacy(Request $request,$id)
    {
        $users = $request->input('users');
        $project = Project::find($id);
        if($this->isBearer()){
            if( (Auth::id() !=  $project->user_id) &&  !Auth::user()->isAdmin() ){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }
        if($project->privacy != 'users')
        {
            $this->setStatusCode('406');
            return $this->respond();
        }

        $newList = explode(',',$users);

        $users = ProjectUser::where("project_id","=",$project->id)->get()->pluck('user_id')->toArray();
        $new = array_diff($newList,$users);
        if($new){
            foreach ($new as $key=>$user_id)
            {
                $pt = new ProjectUser;
                $pt->project_id = $project->id;
                $pt->user_id = $user_id;
                $pt->save();
            }
        }

        return $this->respond();
    }

    public function removeUserPrivacy(Request $request,$id)
    {
        $teams = $request->input('teams');
        $project = Project::find($id);
        if($this->isBearer()){
            if( (Auth::id() !=  $project->user_id) &&  !Auth::user()->isAdmin() ){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }
        if($project->privacy != 'users')
        {
            $this->setStatusCode('406');
            return $this->respond();
        }

        $newList = explode(',',$teams);
        $teams = ProjectUser::where("project_id","=",$project->id)->whereIn("user_id",$newList)->delete();
        return $this->respond();
    }

    public function deleteProject(Request $request)
    {
        $model = $request->input('project_id');
        $project = Project::find($model);
        if($this->isBearer()){
            if( (Auth::id() !=  $project->user_id) &&  !Auth::user()->isAdmin() ){
                $this->setStatusCode(403);
                return $this->respond();
            }
        }
        $project->delete();
        return $this->respond([
            'id' => $model,
            'deleted' => true
        ]);
    }

}
