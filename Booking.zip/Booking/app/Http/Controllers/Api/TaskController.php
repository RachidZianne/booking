<?php

namespace App\Http\Controllers\Api;

use App\Task;
use App\TaskComment;
use App\TaskCommentAttachment;
use App\TaskSection;
use Auth;
use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
class TaskController extends ApiController
{

    public function getTask(Request $request,$id)
    {
        $withables = [];
        $include_comments = $request->input('comments',false);
        $include_tags = $request->input('tags',false);
        $include_subtasks = $request->input('subtasks',false);

        if($include_comments == 'true')
        {
            $withables[] = "comments";
        }

        if($include_tags == 'true')
        {
            $withables[] = "tasktags.tag";
        }

        if($include_subtasks == 'true')
        {
            $withables[] = "subtasks";
        }

        $task = Task::with($withables)->where("id","=",$id)->first();
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }
        $task->comments->each(function ($eloquent) {
            $eloquent->setAppends([]);
        });
        return $this->respond($task);
    }

    public function markDone(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $task->done = 1;
        $task->done_at = Carbon::now();
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'done' => true
        ]);
    }

    public function markUndone(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }
        $task->done = 0;
        $task->done_at = null;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'done' => false
        ]);
    }

    public function assign(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $assigned_to = $request->input('user_id');
        $task->assigned_to = $assigned_to;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'user_id' => $task->assigned_to
        ]);
    }

    public function move(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $sectionid = $request->input('section_id');
        $task->task_section_id = $sectionid;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'section_id' => $task->task_section_id
        ]);
    }

    public function archive(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $task->archived = 1;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'archived' => true
        ]);
    }

    public function unarchive(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $task->archived = 0;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'archived' => false
        ]);
    }

    public function setDueDate(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $date = $request->input('date');
        try{
            $date = Carbon::parse($date);
        }catch (\Exception $e)
        {
            $this->setStatusCode(406);
            return $this->respond();
        }
        $task->due_date = $date;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'due_date' => $task->due_date
        ]);
    }

    public function unsetDueDate(Request $request,$id)
    {
        $task = Task::find($id);
        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section); // 404 on no access
        }

        $task->due_date = null;
        $task->save();
        return $this->respond([
            'id' => $task->id,
            'due_date' => $task->due_date
        ]);
    }

    public function addComment(Request $request,$id)
    {
        $task = Task::findOrFail($id);
        $user_id = $request->input('user_id');

        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->find($section); // 404 on no access
            $user_id = Auth::id();
        }

        $content = $request->input('text');
        $comment = new TaskComment;
        $comment->user_id = $user_id;
        $comment->content = $content;
        $comment->task_id = $id;
        $comment->save();

        if($request->hasFile('attachments'))
        {
            $files = $request->file('attachments');
            if(!is_array($files))
            {
                $this->setStatusCode('406');
            }
            else{
                foreach ($files as $file){
                    $filename = $file->getClientOriginalName();
                    $ext = strtolower($file->getClientOriginalExtension());
                    $attachment = new TaskCommentAttachment;
                    $attachment->task_comment_id = $comment->id;
                    $attachment->task_comment_attachment_type = 'file';
                    $attachment->name =  $filename;
                    $attachment->ext = $ext;
                    $attachment->save();
                    $path = $file->storeAs('tc_attach', $attachment->id);
                }
            }
        }

        return $this->respond($comment);
    }

    public function createTask(Request $request)
    {
        $task = new Task;
        $title = $request->input('content');
        $user_id = $request->input('user_id');
        $section_id = $request->input('section_id');
        $task->user_id = $user_id;

        if($this->isBearer())
        {
            $section = $task->task_section_id;
            $section = TaskSection::allowed()->findOrFail($section_id); // 404 on no access
            $task->user_id = Auth::id();
        }

        $task->title = $title;
        $task->task_section_id = $section_id;
        if($request->input('assigned_to') !== null){
            $assigned_to = $request->input('assigned_to');
            $task->assigned_to = $assigned_to;
        }
        if($request->input('due_date') !== null){
            $date = $request->input('due_date');
            $date = Carbon::parse($date);
            $task->due_date = $date;
        }

        $task->save();

        return $this->respond($task);
    }



}
