<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;
use View;

class MediaController extends Controller
{
    public function avatar($user_id = 0)
    {

        $exists = Storage::disk()->exists('avatars/'.$user_id);
        if(!$exists){
            $contents = Storage::disk()->get('avatars/default');
        }
        else{
            $contents = Storage::disk()->get('avatars/'.$user_id);

        }
        return response($contents)
            ->header('Content-Type', "image/png")
            ->header('Cache-control', 'public');
    }

    public function logo()
    {
        $contents = Storage::disk()->get('essentials/logo.png');
        return response($contents)
            ->header('Content-Type', "image/png")
            ->header('Cache-control', 'public');
    }

    public function customCss()
    {
        $contents = View::make("fragments.customcss")->render();
        return response($contents)
            ->header('Content-Type', "text/css")
            ->header('Cache-control', 'public');


    }


}
