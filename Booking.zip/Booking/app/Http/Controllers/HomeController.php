<?php

namespace App\Http\Controllers;

use App\Language;
use App\Like;
use App\Project;
use App\ProjectTeam;
use App\Tag;
use App\Task;
use App\TaskComment;
use App\TaskSection;
use App\TaskTag;
use App\Team;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\View;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function overview(Request $request)
    {

        $with_archive = (bool)$request->input("archive",false);
        $data['sections'] = TaskSection::allowed()->with(["tasks" => function($q) use($with_archive){
            $q->archived($with_archive);
        },'tasks.subtasks'])->orderBy("id","desc")->get();
        $data['view_type'] = "overview";

        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;



        return view('app',$data);
    }

    public function team(Request $request,$id)
    {
        $with_archive = (bool)$request->input("archive",false);
        $team = Team::with("tasksections.tasks","teamprojects.project")->with(["tasksections.tasks" => function($q) use($with_archive){
            $q->archived($with_archive);
        },'tasksections.tasks.subtasks'])->where("id",$id)->first();
        if(!Auth::user()->hasTeamAccess($team->id)){
            return redirect()->route('overview')->with('error', trans('common.no_access'));
        }

        $data['team'] = $team;
        $data['sections'] = $team->tasksections;
        $data['view_type'] = "team";
        // Team projects
        $data['projects'] = $team->teamprojects->pluck('project');
        return view('app',$data);
    }


    public function selfassigned()
    {
        $data['sections'] = TaskSection::with(['tasks' => function($query){
            $query->where("assigned_to","=",Auth::id());
        },'tasks.subtasks'])->whereHas('tasks', function ($query) {
            $query->where("assigned_to","=",Auth::id());
        })->get();
        $data['view_type'] = "assigned";
        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;
        $data['layout_type'] = 'linear';
        return view('app',$data);
    }

    public function tag(Request $request,$tag)
    {
        $tag = Tag::where("title",$tag)->first();
        $tagged_tasks = TaskTag::where("tag_id","=",$tag->id)->orderBy("id","desc")->get();
        $tagged = $tagged_tasks->pluck('task_id')->toArray();
        $data['sections'] = TaskSection::allowed()->whereHas('tasks', function ($query) use($tagged) {
            $query->whereIn('id',$tagged);
        })->with(['tasks' => function ($query) use($tagged) {
            $query->whereIn('id',$tagged)->orderBy('id',"desc");
        },'tasks.subtasks'])->get();
        $data['view_type'] = "assigned";
        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;
        $data['layout_type'] = 'linear';
        return view('app',$data);
    }

    public function calendar(Request $request)
    {
        $with_archive = $request->input("archive",0);

        $data['sections'] = TaskSection::allowed()->with(["tasks" => function($q) use($with_archive){
            $q->archived($with_archive);
        }])->get();
        $data['view_type'] = "overview";
        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;
        $data['with_archive'] = $with_archive;
        return view('calendar',$data);
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('overview');
    }


    public function permalinkTask($alphaid)
    {
        $alphaid = (int) alphaID($alphaid,true);
        return response()->redirectToRoute('overview')->with('view_task',$alphaid);
    }

    public function permalinkComment($alphaid)
    {
        $id = (int) alphaID($alphaid,true);
        $task = TaskComment::find($id);
        $task_id = $task->task_id;
        return response()->redirectToRoute('overview')->with([
            'view_task_comment' => $id,
            'task_id' => $task_id
        ]);
    }


    public function clientSearch(Request $request)
    {
        $query = $request->input('query');
        $clients = User::select('name','id','type')->where("type","=","client")->where("name",'like',"%$query%")->get();
        return response()->json($clients);
    }

}
