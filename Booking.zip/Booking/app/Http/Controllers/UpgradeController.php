<?php

namespace App\Http\Controllers;

use App\Language;
use App\Settings;
use Config;
use DB;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

use Illuminate\Http\Request;
use Schema;

class UpgradeController extends Controller
{
    const METIS_LATEST_VERSION = 112;

    const version_list = [
        100,
        101,
        102,
        103,
        104,
        105,
        106,
        107,
        108,
        109,
        110,
        111,
        112
    ];

    public function upgrade(Request $request)
    {

        Settings::flush();
        $current_version = Settings::gets("version",true);

        if($current_version == self::METIS_LATEST_VERSION)
        {
            return redirect()->route('overview');
        }

        // Call upgrades

        $pos = array_search($current_version,self::version_list);
        for($i=$pos+1;$i<(sizeof(self::version_list)); $i++){
            $next_version = self::version_list[$i];
            $function = "_upgrade_".$next_version;
            if(method_exists($this,$function))
            {
                $this->$function();
            }
        }

        Settings::put("version",self::METIS_LATEST_VERSION);
        Settings::flush();
        Language::regenerateJS();
        return redirect()->route('admin.info')->with('status',"Update Done")->with('rate',true);
    }

    static function _upgrade_103()
    {

        // Create PT Table

        Schema::connection('mysql')->create('project_templates', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->string('title');
            $table->longText('template_code');
            $table->timestamps();
        });

        $settings = new Settings;
        $settings->name = 'tweaks_ddm';
        $settings->value = 0;
        $settings->save();

        $settings = new Settings;
        $settings->name = 'tweaks_stack';
        $settings->value = 0;
        $settings->save();


    }

    static function _upgrade_104()
    {

        // Create Invites Table

        Schema::connection('mysql')->create('user_invites', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->string('token');
            $table->string('type');
            $table->timestamps();
        });

        $settings = new Settings;
        $settings->name = 'pref_user_invited';
        $settings->value = 'client';
        $settings->save();

        $settings = new Settings;
        $settings->name = 'api_key';
        $settings->value = '';
        $settings->save();



    }

    static function _upgrade_105()
    {

        // Create Tokens Table

        Schema::connection('mysql')->create('user_tokens', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('token');
            $table->integer('user_id');
        });

        $settings = new Settings;
        $settings->name = 'enable_oauth';
        $settings->value = 1;
        $settings->save();

        $settings = new Settings;
        $settings->name = 'purchase_code';
        $settings->value = '';
        $settings->save();

        $settings = new Settings;
        $settings->name = 'start_day';
        $settings->value = '0';
        $settings->save();


        $config = Config::get("app");
        copy(resource_path('updates/105/app.php'), config_path('app.php'));
        Config::write("app", [
            "name"     => $config['name'],
            "key"      => $config['key'],
            "timezone" => $config['timezone'],
            "url"      => $config['url'],

        ]);


    }


    static function _upgrade_106()
    {

        $config = Config::get("app");
        copy(resource_path('updates/105/app.php'), config_path('app.php'));
        Config::write("app", [
            "name"     => $config['name'],
            "key"      => $config['key'],
            "timezone" => $config['timezone'],
            "url"      => $config['url'],

        ]);

        $settings = new Settings;
        $settings->name = 'pref_view_stackgutter';
        $settings->value = 15;
        $settings->save();


    }

    static function _upgrade_107()
    {

        Schema::connection('mysql')->create('task_subtasks', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('user_id');
            $table->string('title');
            $table->integer('assigned_to')->nullable();
            $table->integer('task_id')->nullable();
            $table->boolean('done')->default(false);
            $table->dateTime('done_at')->default(null)->nullable();
            $table->boolean('archived')->default(false);
            $table->date('due_date')->nullable();
        });

    }

    static function _upgrade_108()
    {

        Schema::connection('mysql')->create('user_preferences', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('user_id');
            $table->string('key');
            $table->text('value')->nullable();
        });

    }

    static function _upgrade_109()
    {

        Schema::connection('mysql')->table('projects', function($table) {
            $table->boolean('archived')->default(false);
        });

        Schema::connection('mysql')->table('tasks', function($table) {
            $table->dateTime('snoozed_until')->default(null)->nullable();
        });

        $settings = new Settings;
        $settings->name = 'pref_project_archiveaccess';
        $settings->value = 1;
        $settings->save();

    }

    static function _upgrade_110()
    {

    }

    static function _upgrade_111()
    {
        Schema::connection('mysql')->create('languages', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('code');
            $table->string('language');
            $table->string('author')->nullable();
            $table->string('author_url')->nullable();
            $table->boolean('active')->default(true);
            $table->boolean('rtl')->default(false);
        });

        DB::table('languages')->insert([
            'created_at' => '2017-10-10 00:00:00',
            'updated_at' => '2017-10-10 00:00:00',
            'code' => 'en',
            'language' => 'English',
            'author' => 'Metis',
            'author_url' => 'http://www.gometis.com',
            'active' => '1',
            'rtl' => '0',
        ]);


    }

    static function _upgrade_112()
    {
        Schema::connection('mysql')->create('hardsettings', function (Blueprint $table) {
            $table->string('name')->unique();
            $table->longText('value')->nullable();
        });

        DB::table('hardsettings')->insert([
            'name' => 'customcss',
            'value' => ''
        ]);

        $settings = new Settings;
        $settings->name = 'fullscreen_mode';
        $settings->value = 0;
        $settings->save();

    }

}
