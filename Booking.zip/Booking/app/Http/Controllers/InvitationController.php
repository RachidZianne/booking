<?php

namespace App\Http\Controllers;

use App\Settings;
use App\User;
use App\UserInvite;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

class InvitationController extends Controller
{
    public function form(Request $request,$token)
    {
        $invite = UserInvite::where("token","=",$token)->where('created_at', '>=', Carbon::now()->subDays(2))->first();
        if(!$invite)
        {
            return redirect()->route('login')->with('error', trans("messages.invite_expired"));
        }

        $user_id = $invite->user_id;
        $user = User::find($user_id);
        if(!$user)
        {
            return redirect()->route('login')->with('error', trans("messages.u_not_found"));
        }

        $data['token'] = $token;
        return view('auth.invite',$data);
    }
    public function accept(Request $request,$token)
    {
        $invite = UserInvite::where("token","=",$token)->where('created_at', '>=', Carbon::now()->subDays(2))->first();

        if(!$invite)
        {
            return redirect()->route('login')->with('error', trans("messages.invite_expired"));
        }


        $user_id = $invite->user_id;
        $user = User::find($user_id);

        if(!$user)
        {
            return redirect()->route('login')->with('error', trans("messages.u_not_found"));
        }

        $user->name = $request->input('name');
        $password = $request->input('password');

        if(empty($password))
        {
            return redirect()->back()->with('error', trans("messages.pass_no_empty"));
        }

        $user->password = \Hash::make($password);

        $pref_inv = Settings::gets("pref_user_invited",true);
        if($pref_inv == 'staff'){
            $user->type = 'staff';
        }
        else{
            $user->type = 'client';
        }

        $user->save();


        UserInvite::where("user_id","=",$invite->user_id)->delete();
        $data['token'] = $token;
        Auth::loginUsingId($user_id);
        return redirect()->route('overview')->with('status', trans("common.saved"));

    }

}
