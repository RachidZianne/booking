<?php

namespace App\Http\Controllers;

use App\Notification;
use App\TaskComment;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Event;

class NotificationController extends Controller
{

    function getLatest(Request $request)
    {
        $cursor = $request->input('cursor','0');
        $notification = Notification::with("related")->where("user_id",Auth::id());
        $notification = $notification->where("id",">",$cursor)->orderBy("id","desc")->take(10)->get();
        Event::fire("seen",Auth::id());
        return response()->json($notification);
    }

    function redirectTask($id = 0)
    {
        $id = (int) $id;
        return response()->redirectToRoute('overview')->with('view_task',$id);
    }

    function redirectTaskComment($id = 0)
    {
        $id = (int) $id;
        $task = TaskComment::find($id);
        $task_id = $task->task_id;
        return response()->redirectToRoute('overview')->with([
            'view_task_comment' => $id,
            'task_id' => $task_id
        ]);
    }

    function markRead(Request $request)
    {
        $notifications = $request->input('list');
        Notification::where("user_id",Auth::id())->whereIn("id",$notifications)->update(['read' => 1]);
    }
}
