<?php

namespace App\Http\Controllers;

use App\ActionLog;
use App\Like;
use App\Notification;
use App\Tag;
use App\Task;
use App\TaskComment;
use App\TaskCommentAttachment;
use App\TaskCommentAttachmentLocation;
use App\TaskSection;
use App\TaskSubtask;
use App\TaskTag;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Storage;
use Image;
use JeroenDesloovere\VCard\VCard;

class TaskController extends Controller
{


    public function addTask(Request $request)
    {
        $section_id = $request->input('section_id');
        if(!Auth::user()->hasSectionAccess($section_id)){
            return abort(403);
        }
        $task = new Task;
        $task->user_id = Auth::id();
        $task->title = $request->input('title');
        $task->task_section_id = $section_id;


        if($request->input('assigned_to') !== null){
            $assigned_to = $request->input('assigned_to');
            $task->assigned_to = $assigned_to;
        }

        if($request->input('due_date') !== null){
            $date = $request->input('due_date');
            $date = Carbon::parse($date);
            $task->due_date = $date;
        }

        $task->save();
        if($task->assigned_to)
        {
            Event::fire('task.assigned',[[
                'assigned' => $task->assigned_to,
                'model_id' => $task->id
                 ]]);
        }
        if($request->input('tags') !== null){
            $tags = $request->input('tags');
            $tags = explode(",",$tags);
            // Add new tags
            foreach ($tags as $tag)
            {
                if(empty($tag))
                {
                    continue;
                }
                $newTag = Tag::firstOrCreate(['title' => $tag]);
                // Associate
                $newAssocTask = new TaskTag;
                $newAssocTask->task_id = $task->id;
                $newAssocTask->tag_id = $newTag->id;
                $newAssocTask->save();
            }
        }


        return response()->json([
            'status' => 'ok',
            'id' => $task->id
        ]);


    }

    public function addSubTask(Request $request)
    {
        $task_id = $request->input('task_id');
        $task = Task::find($task_id);
        $section = $task->task_section_id;
        if(!Auth::user()->hasSectionAccess($section)){
            return abort(403);
        }

        $subtask = new TaskSubtask;
        $subtask->user_id = Auth::id();
        $subtask->title = $request->input('title');
        $subtask->task_id = $task_id;
        $subtask->save();
        return response()->json([
            'status' => 'ok',
            'id' => $subtask->id,
            'user_id' => $subtask->user_id
        ]);

    }

    public function edit(Request $request)
    {
        $taskid = $request->input('taskid');
        $title = $request->input('title');
        $tags = $request->input('tags');
        $assigned = $request->input('assigned');
        $due = $request->input('due');


        $task = Task::find($taskid);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        if($task->assigned_to != $assigned)
        {
            Event::fire('task.assigned',[[
                'assigned' => $assigned,
                'model_id' => $task->id
            ]]);
        }
        $task->assigned_to = $assigned;
        $task->due_date = $due;
        $task->title = $title;
        $task->save();

        // delete and reassociate
        $currentTags = TaskTag::where("task_id",$task->id)->delete();
        $tags = explode(",",$tags);
        // Add new tags
        foreach ($tags as $tag)
        {
            if(empty($tag))
            {
                continue;
            }
            $newTag = Tag::firstOrCreate(['title' => $tag]);
            // Associate
            $newAssocTask = new TaskTag;
            $newAssocTask->task_id = $task->id;
            $newAssocTask->tag_id = $newTag->id;
            $newAssocTask->save();
        }

        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function commentLike(Request $request)
    {
        $taskCommentId = $request->input('tc_id');
        $task = TaskComment::find($taskCommentId);
        $like = Like::firstOrCreate(['task_comment_id' => $task->id , 'user_id' => Auth::id()]);
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function commentUnlike(Request $request)
    {
        $taskCommentId = $request->input('tc_id');
        $task = TaskComment::find($taskCommentId);
        $like = Like::where(['task_comment_id' => $task->id , 'user_id' => Auth::id()])->delete();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function checkTask(Request $request)
    {
        $taskId = $request->input('task_id');
        $task = Task::find($taskId);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        $task->done = 1;
        $task->done_at = Carbon::now();
        $task->save();
        return response()->json([
            'status' => 'ok',
            'id' => $task->id
        ]);
    }

    public function uncheckTask(Request $request)
    {
        $taskId = $request->input('task_id');
        $task = Task::find($taskId);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }

        $task->done = 0;
        $task->done_at = null;
        $task->save();
        return response()->json([
            'status' => 'ok',
            'id' => $task->id
        ]);
    }

    public function checkSubTask(Request $request)
    {
        $taskId = $request->input('subtask_id');
        $subtask = TaskSubtask::find($taskId);
        $section = $subtask->task->task_section_id;
        if(!Auth::user()->hasSectionAccess($section)){
            return abort(403);
        }

        $subtask->done = 1;
        $subtask->done_at = Carbon::now();
        $subtask->save();
        return response()->json([
            'status' => 'ok',
            'id' => $subtask->id
        ]);
    }


    public function uncheckSubTask(Request $request)
    {
        $taskId = $request->input('subtask_id');
        $subtask = TaskSubtask::find($taskId);
        $section = $subtask->task->task_section_id;
        if(!Auth::user()->hasSectionAccess($section)){
            return abort(403);
        }

        $subtask->done = 0;
        $subtask->done_at = null;
        $subtask->save();
        return response()->json([
            'status' => 'ok',
            'id' => $subtask->id
        ]);
    }

    public function move(Request $request)
    {
        $taskId = $request->input('task_id');
        $from = $request->input('from_section');
        $to_section = $request->input('to_section');
        $task = Task::find($taskId);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        $task->task_section_id = $to_section;
        $task->save();
        return response()->json([
            'status' => 'ok',
            'id' => $task->id
        ]);
    }

    public function commentAttach(Request $request)
    {
        $filename = $request->file->getClientOriginalName();
        $ext = strtolower($request->file->getClientOriginalExtension());


        $attachment = new TaskCommentAttachment;
        $attachment->task_comment_id = 0; // Still pending
        $attachment->task_comment_attachment_type = 'file';
        $attachment->name =  $filename;
        $attachment->ext = $ext;
        $attachment->save();
        $path = $request->file->storeAs('tc_attach', $attachment->id);

        return response()->json([
            'status' => 'ok',
            'id' => $attachment->id
        ]);
    }

    public function commentLoad(Request $request)
    {
        $task_id = $request->input('task_id');
        $cursor = $request->input('cursor');

        $task = Task::with("comments.likes","comments.user_basic","comments.attachment_files","comments.attachment_vcard","comments.attachment_location.location","tasktags.tag","task_section","assigned_basic","subtasks");
        if(!empty($cursor))
        {
            $task->with(['comments' => function($query) use($cursor){
                $query->where('id','>',$cursor);
            }]);
        }
        $task = $task->find($task_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        return response()->json([
            'status' => 'ok',
            'data' => $task
        ]);

    }

    public function commentLoadLive(Request $request)
    {

        $task_id = $request->input('task_id');
        $cursor = $request->input('cursor');
        $theTask = Task::find($task_id);
        if(!Auth::user()->hasSectionAccess($theTask->task_section_id)){
            return abort(403);
        }


        $task = TaskComment::with("likes","user_basic","attachment_files","attachment_vcard","attachment_location.location");
        $task->where("id",">",$cursor);
        $task = $task->where("task_id","=",$task_id);
        $task = $task->get();

        return response()->json([
            'status' => 'ok',
            'data' => $task
        ]);

    }

    public function addComment(Request $request)
    {

        $task = $request->input('task_id');
        $task = Task::find($task);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }

        $content = $request->input('content');
        $content = parse_comment_text($content);
        $mention = (int) $content['user_id'];
        $content = $content['content'];
        $taskComment = new TaskComment;
        $taskComment->user_id = Auth::id();
        $taskComment->task_id = $task->id;
        $taskComment->content = $content;
        $taskComment->save();

        if(!empty($mention))
        {
            Event::fire("task.mention", [['related_user' => Auth::id(),
                                          'user_id' => $mention,
                                          'model_id' => $taskComment->id
                                         ]]);
        }

        // Parse location;
        $latitude = trim($request->input('latitude'));
        $longitude = trim($request->input('longitude'));
        $locationName = trim($request->input('locationName'));
        if(!empty($latitude) && !empty($longitude))
        {
            if(empty($locationName))
            {
                $locationName = 'Location';
            }

            $taskCommentAttachment = new TaskCommentAttachment;
            $taskCommentAttachment->task_comment_id = $taskComment->id;
            $taskCommentAttachment->task_comment_attachment_type = 'location';
            $taskCommentAttachment->name = $locationName;
            $taskCommentAttachment->ext = 'loc';
            $taskCommentAttachment->save();
            // new location
            $taskCommentAttachmentLocation = new TaskCommentAttachmentLocation;
            $taskCommentAttachmentLocation->long = $longitude;
            $taskCommentAttachmentLocation->lat = $latitude;
            $taskCommentAttachmentLocation->name = $locationName;
            $taskCommentAttachmentLocation->task_comment_attachment_id = $taskCommentAttachment->id;
            $taskCommentAttachmentLocation->save();
        }

        // Parse vCards;
        $vcardAddr = trim($request->input('vcardAddr'));
        $vcardEMail = trim($request->input('vcardEMail'));
        $vcardName = strip_tags(trim($request->input('vcardName'),'./\@#<> '));
        $vcardNumber = trim($request->input('vcardNumber'));

        if(!empty($vcardAddr) || !empty($vcardEMail) || !empty($vcardName) || !empty($vcardNumber) )
        {

            $vcard = new VCard();
            $vcard->addName($vcardName);
            $vcard->addPhoneNumber($vcardNumber, 'PREF;WORK');
            $vcard->addEmail($vcardEMail);
            $vcard->addAddress($vcardAddr);

            if(empty($vcardName))
            {
                $contactName = "Contact";
            }
            else{
                $contactName = $vcardName;
            }
            $vCardContent = $vcard->getOutput();
            $taskCommentAttachment = new TaskCommentAttachment;
            $taskCommentAttachment->task_comment_id = $taskComment->id;
            $taskCommentAttachment->task_comment_attachment_type = 'vcard';
            $taskCommentAttachment->name = $contactName.".vcf";
            $taskCommentAttachment->ext = 'vcf';
            $taskCommentAttachment->save();
            Storage::disk()->put("tc_attach/".$taskCommentAttachment->id,$vCardContent);

        }

        // Claim files
        $files = $request->input('files');
        if(!empty($files))
        {
            $rows = TaskCommentAttachment::whereIn("id",$files)
                ->where('task_comment_id',0)
                ->update(['task_comment_id' => $taskComment->id]);
        }

        if($task->user_id != Auth::id()){
            Event::fire("task.comment", [['related_user' => Auth::id(),
              'user_id' => $task->user_id,
              'model_id' => $taskComment->id
              ]]);
        }

        return response()->json([
            'status' => 'ok'
        ]);

    }

    public function editComment(Request $request)
    {
        $content = $request->input('content');
        $comment_id = $request->input('tc_id');
        $content = parse_comment_text($content);
        $content = $content['content'];
        $tc = TaskComment::find($comment_id);
        if($tc->user_id != Auth::id()){
            abort(403);
        }
        $tc->content = $content;
        $tc->edited = 1;
        $tc->save();
        return response()->json([
            'status' => 'ok'
        ]);

    }

    public function downloadAttachment($id)
    {
        $attachment = TaskCommentAttachment::with('taskComment.task')->find($id);
        $task = $attachment->taskComment->task->task_section_id;
        if($task)
        {
            $section = $attachment->taskComment->task->task_section_id;
            if(!Auth::user()->hasSectionAccess($section)){
                return abort(403);
            }
        }
        $exists = Storage::disk()->exists('tc_attach/'.$attachment->id);
        if(!$exists){
            // @TODO ERROR MISSING FILE
            return abort(404);
        }
        else{
            $contents = Storage::disk()->get('tc_attach/'.$attachment->id);
            $attachment_name = $attachment->name;
            return response($contents)
                ->header('Content-Type', "application/octet-stream")
                ->header('Content-Disposition', "attachment; filename=\"$attachment_name\" ")
                ->header('Cache-control', 'public');
        }

    }

    public function previewAttachment($id)
    {
        $attachment = TaskCommentAttachment::with('taskComment.task')->find($id);
        $task = $attachment->taskComment->task->task_section_id;
        if($task)
        {
            $section = $attachment->taskComment->task->task_section_id;
            if(!Auth::user()->hasSectionAccess($section)){
                return abort(403);
            }
        }
        $exists = Storage::disk()->exists('tc_attach/'.$attachment->id);
        if(!$exists){
            // @TODO ERROR MISSING FILE
            return abort(404);
        }
        else{
            if($exists = Storage::disk()->exists('tc_thumb/'.$attachment->id)){
                $contents = Storage::disk()->get('tc_thumb/'.$attachment->id);
                return response($contents)
                    ->header('Content-Type', "image/png")
                    ->header('Cache-control', 'public');
            }
            else{
                $img = Image::make(Storage::disk()->get('tc_attach/'.$attachment->id));
                $img->resize(100, null, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
                $pngData = $img->encode('png');
                Storage::disk()->put("tc_thumb/".$attachment->id,$pngData);
                return $img->response('png');
            }

        }
    }

    public function previewAttachmentMedium($id)
    {
        $attachment = TaskCommentAttachment::with('taskComment.task')->find($id);
        $task = $attachment->taskComment->task->task_section_id;
        if($task)
        {
            $section = $attachment->taskComment->task->task_section_id;
            if(!Auth::user()->hasSectionAccess($section)){
                return abort(403);
            }
        }
        $exists = Storage::disk()->exists('tc_attach/'.$attachment->id);
        if(!$exists){
            // @TODO ERROR MISSING FILE
            return abort(404);
        }
        else{
            if($exists = Storage::disk()->exists('tc_thumb_med/'.$attachment->id)){
                $contents = Storage::disk()->get('tc_thumb_med/'.$attachment->id);
                return response($contents)
                    ->header('Content-Type', "image/png")
                    ->header('Cache-control', 'public');
            }
            else{
                $img = Image::make(Storage::disk()->get('tc_attach/'.$attachment->id));
                $img->resize(500, null, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
                $pngData = $img->encode('png');
                Storage::disk()->put("tc_thumb_med/".$attachment->id,$pngData);
                return $img->response('png');
            }

        }
    }

    public function previewAttachmentCustom(Request $request,$id)
    {
        $height = $request->input('height',null);
        $width = $request->input('width',null);
        $attachment = TaskCommentAttachment::with('taskComment.task')->find($id);
        $task = $attachment->taskComment->task->task_section_id;
        if($task)
        {
            $section = $attachment->taskComment->task->task_section_id;
            if(!Auth::user()->hasSectionAccess($section)){
                return abort(403);
            }
        }
        $exists = Storage::disk()->exists('tc_attach/'.$attachment->id);
        if(!$exists){
            // @TODO ERROR MISSING FILE
            return abort(404);
        }
        else{
                $img = Image::make(Storage::disk()->get('tc_attach/'.$attachment->id));
                $img->resize($height, $width, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
                $pngData = $img->encode('png');
                return $img->response('png');
        }
    }

    public function snoozeTask(Request $request)
    {
        $model_id = $request->input('task_id');
        $snoozeDate = $request->input('date');
        $task = Task::find($model_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        $date = Carbon::parse($snoozeDate);
        $task->snoozed_until = $date;
        $task->save();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function unsnoozeTask(Request $request)
    {
        $model_id = $request->input('task_id');
        $task = Task::find($model_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        $task->snoozed_until = null;
        $task->save();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function deleteTask(Request $request)
    {
            $model_id = $request->input('model_id');
            $task = Task::find($model_id);
            if(!Auth::user()->hasSectionAccess($task->task_section_id)){
                return abort(403);
            }
        ActionLog::log(Auth::id(),sprintf("Deleted task from section ID %s with task id %s",$task->task_section_id,$task->id));

        $task->delete();
        return redirect()->route('overview')->with('status', trans("messages.task_deleted"));
    }

    public function deleteSubTask(Request $request)
    {
        $model_id = $request->input('model_id');
        $subtask = TaskSubtask::find($model_id);
        $task = Task::find($subtask->task_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        ActionLog::log(Auth::id(),sprintf("Deleted subtask from Task ID %s",$task->id));
        $subtask->delete();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function renameSubTask(Request $request)
    {
        $model_id = $request->input('model_id');
        $title = trim($request->input('title'));
        $subtask = TaskSubtask::find($model_id);
        $task = Task::find($subtask->task_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        ActionLog::log(Auth::id(),sprintf("Renamed subtask from Task ID %s",$task->id));
        $subtask->title = $title;
        $subtask->save();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function reassignSubTask(Request $request)
    {
        $model_id = $request->input('model_id');
        $user_id = trim($request->input('user_id'));
        if($user_id == 0){
            $user_id = null;
        }
        $subtask = TaskSubtask::find($model_id);
        $task = Task::find($subtask->task_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        ActionLog::log(Auth::id(),sprintf("Assigned subtask from Task ID %s to user id %s",$task->id,$user_id));
        $subtask->assigned_to = $user_id;
        $subtask->save();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function dueSubTask(Request $request)
    {
        $model_id = $request->input('model_id');
        $due_date = trim($request->input('due_date'));
        if($due_date == 0){
            $due_date = null;
        }
        else{
            $due_date = Carbon::parse($due_date);
        }
        $subtask = TaskSubtask::find($model_id);
        $task = Task::find($subtask->task_id);
        if(!Auth::user()->hasSectionAccess($task->task_section_id)){
            return abort(403);
        }
        ActionLog::log(Auth::id(),sprintf("Due date for a subtask from Task ID %s was set",$task->id));
        $subtask->due_date = $due_date;
        $subtask->save();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function deleteTaskComment(Request $request)
    {
        $model = $request->input('comment_id');
        $taskcomment = TaskComment::find($model);
        if(Auth::user()->isAdmin() || ($taskcomment->user_id == Auth::id() ) )
        {
            $taskcomment->delete();
            return response()->json([
                'status' => 'ok'
            ]);
        }
        else{
            return abort(403);
        }
    }

    public function loadTasks(Request $request)
    {
        $start = $request->input('start');
        $end = $request->input('end');
        $with_archive = (bool)$request->input("with_archive",false);
        $ts = TaskSection::allowed()->with([
            'tasks' => function($query)use($start,$end,$with_archive){
                $query->archived($with_archive);
                $query->whereNotNull('due_date')->
                where('due_date','<=',Carbon::parse($end))
                    ->where('due_date','>=',Carbon::parse($start));
        }
        ])->whereHas('tasks',function($query)use($start,$end){
            $query->whereNotNull('due_date')->
            where('due_date','<=',Carbon::parse($end))
                ->where('due_date','>=',Carbon::parse($start));
        })->get();
        $tasks = $ts->pluck('tasks')->flatten();

        return response()->json([
            'status' => 'ok',
            'data' => $tasks
        ]);

    }

}
