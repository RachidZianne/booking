<?php

namespace App\Http\Controllers;

use App\ActionLog;
use App\Language;
use App\ProjectTemplate;
use App\UserPreference;
use Auth;
use Exception;
use Hash;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;
use Response;
use Storage;

class ProfileController extends Controller
{

    public function me()
    {
        $data = [];
        $data['languages'] = Language::active()->get();
        $data['language_selected'] = UserPreference::getPref("language");
        return view("profile.me",$data);
    }

    public function meSave(Request $request)
    {
            $name = $request->input('name');
            $email = $request->input('email');
            $name = trim($name);
            $email = trim($email);
            $language = $request->input('language');
            if($language == "0")
            {
                UserPreference::removePref("language");
            }
            else{
                UserPreference::setPref("language",$language);
            }

            if(!validate_email($email)){
                return redirect()->back()->with('error', trans("messages.invalid_email"));

            }

            $user = Auth::user();
            if($name != $user->name)
            {
                ActionLog::log(Auth::id(),sprintf("Changed name from %s to %s",$user->name,$name));
                $user->name = $name;
            }
            if($email != $user->email)
            {
                ActionLog::log(Auth::id(),sprintf("Changed email from %s to %s",$user->email,$email));
                $user->email = $email;
            }
            $user->save();

        if ($request->hasFile('avatar')) {
            $content = "";
            try{
                $content = Image::make($request->file('avatar'))->resize(300, 300)->stream();
            }catch (Exception $e){
                return redirect()->back()->with('error', $e->getMessage());

            }
            Storage::disk()->put('avatars/'.Auth::id(),$content);
            $request->avatar->storeAs('avatars', Auth::id());

        }

        return redirect()->back()->with('status', trans("common.successfully_updated"));
    }

    public function changePw()
    {
        $data = [];
        return view("profile.change_pw",$data);
    }

    public function changePwSave(Request $request)
    {

        $pass = $request->input('password');
        $new_pass = $request->input('passwordnew');

        if(Hash::check($pass, Auth::user()->password)) {
            $user = Auth::user();
            $user->password = Hash::make($new_pass);
            $user->save();
            return redirect()->back()->with('status', trans("common.successfully_updated"));
        }
        else{
            return redirect()->back()->with('error', trans("messages.curr_pass_invalid"));
        }


    }

    public function projectTemplates()
    {
        $data['templates'] = ProjectTemplate::where("user_id","=",Auth::id())->paginate(20);
        return view("profile.templates",$data);
    }

    public function projectTemplateDownload($id)
    {
        $template = ProjectTemplate::where("user_id","=",Auth::id())->find($id);
        if(!($template)){
            return abort(404);
        }
        $filename = $template->title."-".time();
        $headers = [
            'Content-type'        => 'application/json',
            'Content-Disposition' => 'attachment; filename="'.$filename.'.json"',
        ];
        $projectCode = $template->template_code;
        return Response::make($projectCode, 200, $headers);

    }

    public function deleteProjectTemplate(Request $request)
    {
        $model_id = $request->input('model_id');
        $tp = ProjectTemplate::where("user_id","=",Auth::id())->find($model_id);
        $tp->delete();
        return redirect()->route('profile.templates')->with('status', trans('common.deleted'));
    }

    public function importProjectTemplate(Request $request)
    {
        if(!$request->hasFile('file'))
        {
            return redirect()->route('profile.templates')->with('error', trans("messages.must_upload_file"));
        }
        $file = $request->file('file');
        $code  = (file_get_contents($file->path()));
        if(!(validate_project_template_code($code)))
        {
            return redirect()->route('profile.templates')->with('error', trans("messages.invalidfiletype"));
        }

        $code = json_decode($code);

        $template = new ProjectTemplate;
        $template->title = $code->title;
        $template->user_id = Auth::id();
        $template->template_code = json_encode($code);
        $template->save();

        return redirect()->route('profile.templates')->with('status', trans("common.saved"));
    }
    public function renameProjectTemplate(Request $request)
    {
        $model_id = $request->input('model_id');
        $title = $request->input('title');
        $tp = ProjectTemplate::where("user_id","=",Auth::id())->find($model_id);
        $tp->title = $title;
        $tp->save();
        return response()->json([
            'status' => 'ok'
        ]);

    }

}
