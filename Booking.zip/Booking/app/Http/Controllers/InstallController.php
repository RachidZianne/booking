<?php

namespace App\Http\Controllers;

use App\Team;
use App\User;
use Exception;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use PDO;
use PDOException;
use Settings;

class InstallController extends Controller
{

    public function compatibility()
    {
        $data['title'] = "Welcome";
        return view("install.compatibility",$data);
    }

    public function db()
    {
        $data['title'] = "Database";
        return view("install.database",$data);
    }

    public function dbSave(Request $request)
    {
        $dbname = $request->input('dbname');
        $username = $request->input('username');
        $password = $request->input('password');
        $host = $request->input('host');
        try {
            $pdoc = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        } catch (Exception $e) {
            $msg = $e->getMessage();
            $error = "Couldn't connect to database ( $msg )  ";
            return redirect()->back()->with("error",$error);
        }

        \Config::write("database",[
                "connections" => [
                    'mysql' => [
                        'host' => $host,
                        'database' => $dbname,
                        'username' => $username,
                        'password' => $password,
                    ]
                ]
            ]
        );

        $sqlfile = file_get_contents(storage_path("install/metis.sql"));
        try {
            $statements = $pdoc->prepare($sqlfile);
            $statements->execute();
        }
        catch (PDOException $e)
        {
            $msg = $e->getMessage();
            $error = "Couldn't import the database file ( $msg )  ";
            return redirect()->back()->with("error",$error);
        }

        return redirect()->route('inst2');
    }

    public function config()
    {
        $data['title'] = "Config";
        return view("install.config",$data);
    }

    public function configSave(Request $request)
    {
        $data = [];

        // Config

        $url = $request->input('siteurl');
        \Config::write("app",[
                "url" => $url,
                "key" => Str::random("32")
            ]
        );

        // Admin
        $name = $request->input("aname");
        $email = $request->input("aemail");
        $password = $request->input("apass");

        if(empty($email) || empty($password))
        {
            $error = "Admin email and password cannot be empty";
            return redirect()->back()->with("error",$error);
        }

        $admin = new User;
        $admin->name = $name;
        $admin->email = $email;
        $admin->password = Hash::make($password);
        $admin->type = 'root';
        $admin->save();

        // Settings
        $sitename = $request->input('sitename');

        Settings::put("site_name",$sitename);
        // Defaults



        return redirect()->route('inst3');


    }

    public function setup()
    {
        $data['title'] = "Setting you up";
        return view("install.setup_teams",$data);
    }

    public function setupSave(Request $request)
    {
        $list = $request->input('teamlist');
        if(!empty($list)){
            foreach($list as $team)
            {
                $te = new Team;
                $te->title = $team;
                $te->save();
            }
        }
        return redirect()->route('inst4');
    }

    public function done(Request $request)
    {
        \Config::write("metis",[
                "installed" => 1
            ]
        );
        return view("install.done");
    }


}
