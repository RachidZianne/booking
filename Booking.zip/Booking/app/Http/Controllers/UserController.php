<?php

namespace App\Http\Controllers;

use App\ActionLog;
use App\Jobs\SendUserInvite;
use App\ProjectUser;
use App\Team;
use App\TeamUser;
use App\User;
use App\UserInvite;
use Auth;
use Exception;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\View;
use Intervention\Image\Facades\Image;
use Log;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $data['users'] = User::staff()->with("teams")->orderBy("id","desc")->paginate(15);

        return view('user.index',$data);
    }

    public function create()
    {
        $data['user'] = null;
        $data['teams'] = Team::all();
        return view('user.create',$data);
    }

    public function edit($id)
    {
        $data['user'] = User::with("teams")->find($id);
        $data['teams'] = Team::all();
        return view('user.create',$data);
    }

    public function store(Request $request)
    {
        $email = trim($request->input('email'));

        $id = $request->input('user_id');
        if($id)
        {
            $user = User::find($id);
        }
        else{
            $user = new User;
            $old = User::withTrashed()->where("email","like",$email)->first();
            if(count($old))
            {
                if($old->trashed())
                {
                    $old->forceDelete();
                }
                else{
                    return redirect()->route('user.new')->with('error', trans("messages.user_exist"));
                }
            }
        }

        $name = trim($request->input('name'));



        $type = trim($request->input('user_type'));
        $password = $request->input('password');
        $requestedTeams = $request->input('teams');

        $user->name = $name;
        if(!empty($password)){
            $user->password = \Hash::make($password);
        }
        $user->email = $email;
        $user->type = $type;
        try{
            $user->save();
        }
        catch (Exception $e)
        {
            \Log::error($e);
            return redirect()->route('user.index')->with('error', trans("messages.req_fields_missing"));
        }

        $teams = TeamUser::where("user_id","=",$user->id)->delete();
        if(!empty($requestedTeams)){
            $new_teams = explode(',',$requestedTeams);
            foreach ($new_teams as $tm)
            {
                $tu = new TeamUser;
                $tu->team_id =  $tm;
                $tu->user_id = $user->id;
                $tu->save();
            }
        }

        if ($request->hasFile('avatar')) {
            try{
                $content = Image::make($request->file('avatar'))->resize(300, 300)->stream();
            }catch (Exception $e){
                return redirect()->back()->with('error', $e->getMessage());

            }
            Storage::disk()->put('avatars/'.$user->id,$content);
        }
        ActionLog::log(Auth::id(),sprintf("Updated user %s",$user->id));
        return redirect()->route('user.index')->with('status', trans("messages.modelupdated"));

    }

    public function teamIndex()
    {
        $data['teams'] = Team::orderBy("id","desc")->paginate(15);
        return view('user.teams.index',$data);
    }

    public function teamNew()
    {
        $data['team'] = null;
        return view('user.teams.create',$data);
    }
    public function teamEdit($id)
    {
        $data['team'] = Team::find($id);
        return view('user.teams.create',$data);
    }

    public function teamStore(Request $request)
    {
        $team = $request->input('team_id');
        if($team){
            $team = Team::find($team);
        }
        else{
            $team = new Team;
        }
        $team->title = $request->input('title');
        try{
        $team->save();
        }catch (Exception $e)
        {
            \Log::error($e);
            return redirect()->route('user.team.index')->with('error', trans("messages.req_fields_missing"));
        }
        return redirect()->route('user.team.index')->with('status', trans("messages.modelupdated"));
    }

    public function deleteUser(Request $request)
    {
        $id = $request->input('model_id');
        $user = User::find($id);
        ActionLog::log(Auth::id(),sprintf("Deleted user %s",$user->id));
        // Delete from teams & Other stuff
        TeamUser::where("user_id","=",$user->id)->delete();
        ProjectUser::where("user_id","=",$user->id)->delete();
        $user->delete();
        return redirect()->route('user.index')->with('status', trans("messages.modeldeleted"));
    }


    public function deleteTeam(Request $request)
    {
        $id = $request->input('model_id');
        $team = Team::find($id);
        ActionLog::log(Auth::id(),sprintf("Deleted team %s",$team->title));
        $team->delete();
        return redirect()->route('user.team.index')->with('status', trans("messages.modeldeleted"));
    }

    public function clientIndex(Request $request)
    {
        $data['users'] = User::where("type","=","client")->orderBy("id","desc")->paginate(15);
        return view('user.client',$data);
    }

    public function invitedIndex(Request $request)
    {
        $data['users'] = User::where("type","=","invited")->orderBy("id","desc")->paginate(15);
        return view('user.invited',$data);
    }

    public function resendInvite(Request $request)
    {
        $user_id = $request->input('model_id');
        $user = User::find($user_id);

        if($user->type != 'invited')
        {
            return redirect()->route('user.team.index')->with('error', trans("messages.user_completed_reg"));
        }
        // Delete old invitations
        UserInvite::where("user_id","=",$user->id)->delete();
        dispatch(new SendUserInvite($user));
        return redirect()->back()->with('status', trans('messages.invite_sent'));
    }

    public function sendInvite(Request $request)
    {
        $email = $request->input('email');
        $old = User::withTrashed()->where("email","like",$email)->first();
        if(count($old))
        {
            if($old->trashed())
            {
                $old->forceDelete();
            }
            else{
                return redirect()->route('user.new')->with('error', trans("messages.user_exist"));
            }
        }

        if(filter_var($email, FILTER_VALIDATE_EMAIL))
        {

            $user = new User;
            $user->name = $email;
            $user->password = Hash::make(random_bytes(20));
            $user->type = 'invited';
            $user->email = $email;
            $user->save();
            try{
                dispatch(new SendUserInvite($user));
                return redirect()->back()->with('status', trans('messages.invite_sent'));
            }
            catch(Exception $e){
                Log::error($e);
                return redirect()->back()->with('error', trans("messages.error_mailing"));
            }
        }
        else{
            return redirect()->route('user.index')->with('error', trans("messages.invalid_email"));
        }

    }

}
