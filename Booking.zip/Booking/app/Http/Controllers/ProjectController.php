<?php

namespace App\Http\Controllers;

use App\ActionLog;
use App\Jobs\ImportProjectTemplate;
use App\Jobs\SendUserInvite;
use App\Project;
use App\ProjectTeam;
use App\ProjectTemplate;
use App\ProjectUser;
use App\Settings;
use App\Task;
use App\TaskCommentAttachment;
use App\TaskSection;
use App\User;
use Auth;
use Carbon;
use Exception;
use Hash;
use Illuminate\Bus\Dispatcher;
use Illuminate\Http\Request;
use Log;
use Response;
use View;

class ProjectController extends Controller
{
    public function __construct()
    {
        $tpls = ProjectTemplate::select("id", "title")->get();
        View::share('personal_templates', $tpls);
    }

    public function view(Request $request,$id)
    {
        $with_archive = (bool)$request->input("archive",false);
        $project = Project::with("tasksections.tasks","sharedusers.user","sharedteams.team")->with(["tasksections.tasks" => function($q) use($with_archive){
            $q->archived($with_archive);
        }])->where("id",$id)->first();
        if($project->archived == 1 && (Settings::gets("pref_project_archiveaccess") == 1) && Auth::id() != $project->user_id && !Auth::user()->isAdmin() )
        {
            return redirect()->route('overview')->with('error', trans('messages.project_is_archived'));
        }
        if(!Auth::user()->hasProjectAccess($project->id)){
            return redirect()->route('overview')->with('error', trans("common.no_access"));
        }
        $data['project'] = $project;
        $data['sections'] = $project->tasksections;
        $data['view_type'] = "project";
        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;
        $data['subcat_active'] = 'board';
        return view('app',$data);
    }

    public function about(Request $request,$id)
    {
        $with_archive = true;
        $project = Project::with("tasksections.tasks")->with(["tasksections.tasks" => function($q) use($with_archive){
            $q->archived($with_archive);
        }])->where("id",$id)->first();
        if(!Auth::user()->hasProjectAccess($project->id)){
            return redirect()->route('overview')->with('error', trans("common.no_access"));
        }
        $data['project'] = $project;
        $data['sections'] = $project->tasksections;
        $data['view_type'] = "project";
        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;
        $data['subcat_active'] = 'about';
        $project_tasks =  $project->tasks;
        $project_tasks = $project_tasks->filter(function ($value, $key) {
            return $value->done == 1;
        });
        $pt_count = [];
        if(!empty($project_tasks))
        {
            $project_tasks = $project_tasks->groupBy(function ($item, $key) {
                return $item->done_at->toDateString();
            });

            $pt_count = $project_tasks->map(function ($item, $key) {
                return collect($item)->count();
            });
        }
        $data['pt_data'] = json_encode($pt_count);
        return view('project.progress',$data);
    }

    public function files(Request $request,$id)
    {
        $project = Project::with("tasks.comments.attachments.taskComment")->where("id",$id)->first();
        if(!Auth::user()->hasProjectAccess($project->id)){
            return redirect()->route('overview')->with('error', trans("common.no_access"));
        }
        $data['project'] = $project;
        $data['view_type'] = "project";
        $projects = Auth::user()->allowedProjects();
        $data['projects'] = $projects;


        $data['subcat_active'] = 'files';
        $attachments = [];
        $tc = $project->tasks->each(function ($item, $key)use(&$attachments) {
                    $item->comments->each(function($item2,$key2)use(&$attachments) {
                       $item2->attachments->each(function ($item3,$key3)use(&$attachments) {
                            $attachments[]= $item3;
                       });
                    });
        });

        $data['attachments'] = $attachments;
        return view('project.files',$data);
    }

    public function createProject(Request $request)
    {
        $title = $request->input('title');
        $privacy = $request->input('privacy');

        $project = new Project;
        $project->user_id = Auth::id();
        $project->title = $title;
        $project->layout = 'kanban';
        $project->privacy = $privacy;
        $project->save();

        $list = $request->input('list');
        $nList = explode(',',$list);
        if(!empty($list)){

            if($privacy == 'teams')
            {
                foreach($nList as $tlist){
                    $projectTeam = new ProjectTeam;
                    $projectTeam->project_id = $project->id;
                    $projectTeam->team_id = $tlist;
                    $projectTeam->save();
                }
            }
            elseif($privacy == 'users')
            {
                $my_user = Auth::id();
                if(!in_array($my_user,$nList)){
                    $nList[] = $my_user;
                }
                foreach($nList as $tlist){

                    $user_id = $tlist;

                    if(!is_numeric($tlist))
                    {
                        // is email ?
                        if(filter_var($tlist, FILTER_VALIDATE_EMAIL))
                        {
                            $email = $tlist;
                            $user = new User;
                            $user->name = $email;
                            $user->password = Hash::make(random_bytes(20));
                            $user->type = 'invited';
                            $user->email = $email;
                            $user->save();
                            try{
                                dispatch(new SendUserInvite($user));
                            }
                            catch(Exception $e){
                                Log::error($e);
                            }
                            $user_id = $user->id;
                        }
                        else{
                            // Skip
                            continue;
                        }
                    }

                    $projectTeam = new ProjectUser;
                    $projectTeam->project_id = $project->id;
                    $projectTeam->user_id = $user_id;
                    $projectTeam->save();


                }
            }

        }
        return response()->json([
            'status' => 'ok',
            'id' => $project->id
        ]);
    }

    public function updatePrivacy(Request $request)
    {
        $privacy = $request->input('privacy');
        $project = $request->input('project');
        $list = $request->input('list');
        $project = Project::find($project);
        if(! Auth::user()->isAdmin() && !(Auth::id() == $project->user_id) ){
            return abort(403);
        }
        $newList = explode(',',$list);
        if($project->privacy == $privacy)
        {
            // get current ids;
            // check add+del
            if($project->privacy == 'teams')
            {
                $teams = ProjectTeam::where("project_id","=",$project->id)->get()->pluck('team_id')->toArray();
                $removed = array_diff($teams,$newList);
                $new = array_diff($newList,$teams);
                if(count($removed)){
                    ProjectTeam::where("project_id","=",$project->id)->whereIn("team_id",$removed)->delete();
                }
                if($new){
                    foreach ($new as $key=>$team_id)
                    {
                        $pt = new ProjectTeam;
                        $pt->project_id = $project->id;
                        $pt->team_id = $team_id;
                        $pt->save();
                    }
                }
            }
            elseif($project->privacy == 'users')
            {
                $users =  ProjectUser::where("project_id","=",$project->id)->get()->pluck('user_id')->toArray();
                $removed = array_diff($users,$newList);
                $new = array_diff($newList,$users);
                if(count($removed)){
                    ProjectUser::where("project_id","=",$project->id)->whereIn("user_id",$removed)->delete();
                }
                $my_user = Auth::id();
                if( (!in_array($my_user,$users) && !in_array($my_user,$new)) || in_array($my_user,$removed) ){
                    $pt = new ProjectUser;
                    $pt->project_id = $project->id;
                    $pt->user_id = $my_user;
                    $pt->save();
                }
                if($new){
                    foreach ($new as $key=>$user_id)
                    {
                        $pt = new ProjectUser;
                        $pt->project_id = $project->id;
                        $pt->user_id = $user_id;
                        $pt->save();
                    }
                }
            }
        }
        else{

            // Delete old stuff
            if($project->privacy == 'teams')
            {
                ProjectTeam::where("project_id","=",$project->id)->delete();
            }
            elseif($project->privacy == 'users')
            {
                ProjectUser::where("project_id","=",$project->id)->delete();
            }
            $project->privacy = $privacy;

            if(!empty($list)){
                if($privacy == 'teams')
                {
                    foreach($newList as $tlist){
                        $projectTeam = new ProjectTeam;
                        $projectTeam->project_id = $project->id;
                        $projectTeam->team_id = $tlist;
                        $projectTeam->save();
                    }
                }
                elseif($privacy == 'users')
                {
                    foreach($newList as $tlist){
                        $projectTeam = new ProjectUser;
                        $projectTeam->project_id = $project->id;
                        $projectTeam->user_id = $tlist;
                        $projectTeam->save();
                    }
                    $my_user = Auth::id();
                    if(!in_array($my_user,$newList)){
                        $pt = new ProjectUser;
                        $pt->project_id = $project->id;
                        $pt->user_id = $my_user;
                        $pt->save();
                    }
                }
            }

        }

        $project->save();

        return response()->json([
            'status' => 'ok',
            'id' => $project->id
        ]);

    }

    public function archiveProject(Request $request)
    {

        $model = $request->input('model_id');
        $project = Project::find($model);
        if($project->user_id != Auth::id() && !Auth::user()->isAdmin())
        {
            return redirect()->route('overview')->with('status', trans("common.no_access"));
        }
        if($project->archived == 0)
        {
            $project->archived = 1;
            ActionLog::log(Auth::id(),sprintf("Archived project with ID %s with and titled %s",$project->id,$project->title));
            $project->save();
            return redirect()->route('overview')->with('status', trans("messages.project_is_archived"));
        }
        else
        {
            $project->archived = 0;
            ActionLog::log(Auth::id(),sprintf("Restored project with ID %s with and titled %s",$project->id,$project->title));
            $project->save();
            return redirect()->route('project',$project)->with('status', trans("messages.project_is_restored"));
        }

    }

//    public function restoreProject(Request $request)
//    {
//
//        $model = $request->input('model_id');
//        $project = Project::find($model);
//        if($project->user_id != Auth::id() && !Auth::user()->isAdmin())
//        {
//            return redirect()->route('overview')->with('status', 'No Permissions');
//        }
//        ActionLog::log(Auth::id(),sprintf("Restored project with ID %s with and titled %s",$project->id,$project->title));
//        // Associated
//        $project->archived = 0;
//        $project->save();
//        return redirect()->route('overview')->with('status', 'Project archived!');
//
//    }

    public function deleteProject(Request $request)
    {
        $model = $request->input('model_id');
        $project = Project::find($model);
        if($project->user_id != Auth::id() && !Auth::user()->isAdmin())
        {
            return redirect()->route('overview')->with('status', trans("common.no_access"));
        }
        ActionLog::log(Auth::id(),sprintf("Deleted project with ID %s with and titled %s",$project->id,$project->title));
        // Associated
        $pt = ProjectTeam::where("project_id","=",$project->id)->delete();
        $pu = ProjectUser::where("project_id","=",$project->id)->delete();
        // Sections
        $sections = TaskSection::where("project_id","=",$project->id)->get();
        if(!empty($sections))
        {
            foreach($sections as $section)
            {
                $tks = Task::where("task_section_id","=",$section->id)->delete();
                $section->delete();
            }
        }

        $project->delete();
        return redirect()->route('overview')->with('status', trans("messages.modeldeleted"));

    }

    public function renameProject(Request $request)
    {
        $model = $request->input('model_id');
        $title = $request->input('title');
        $project = Project::find($model);
        $project->title = $title;
        $project->save();
        ActionLog::log(Auth::id(),sprintf("Project with ID %s was renamed to %s",$project->id,$project->title));
        return response()->json([
            'status' => 'ok',
            'id' => $project->id
        ]);
    }

    public function TemplateactionProject(Request $request)
    {
        $id = $request->input('model_id');
        $title = $request->input('title');
        $action = $request->input('templateaction');

        $export_done = (int) $request->input('done_status',0);
        $export_assigned = (int) $request->input('assigned_status',0);

        $project = Project::with('tasksections.tasks','sharedusers','sharedteams')->find($id);
        if(!Auth::user()->hasProjectAccess($project->id)){
            return redirect()->route('overview')->with('error', trans("common.no_access"));
        }
        // Options

        if(empty($title))
        {
            $title = $project->title;
        }

        $projectCode = $project->templateify($export_done,$export_assigned);

        if($action == 'template')
        {
            $ptpl = new ProjectTemplate;
            $ptpl->title = $title;
            $ptpl->template_code = $projectCode;
            $ptpl->user_id = Auth::id();
            $ptpl->save();
            return redirect()->route('overview')->with('status', trans("common.saved"));

        }
        else if($action == 'file'){
            $filename = $project->title."-".time();
            $headers = [
                'Content-type'        => 'application/json',
                'Content-Disposition' => 'attachment; filename="'.$filename.'.json"',
            ];
            return Response::make($projectCode, 200, $headers);
        }
        elseif($action == 'importtemplatefile')
        {
            // hasfile
            $file = $request->file('templatefile');
            $code  = json_decode(file_get_contents($file->path()));
            try{
                dispatch(new ImportProjectTemplate($project,$code,false));
            }catch (Exception $e)
            {
                Log::error($e);
            }
            return redirect()->route('project',$project)->with('status', trans("messages.template_imported"));

        }
        elseif($action == 'importtemplate')
        {
            $tpl = $request->input('project-import-template');
            $template = ProjectTemplate::where("user_id","=",Auth::id())->find($tpl);
            $code = json_decode($template->template_code);
            try{
                dispatch(new ImportProjectTemplate($project,$code,false));
            }catch (Exception $e)
            {
                Log::error($e);
            }
            return redirect()->route('project',$project)->with('status', trans("messages.template_imported"));

        }
        else{
            return redirect()->route('overview')->with('error', trans("common.error"));
        }









    }

    function loadTemplates(Request $request)
    {
        $templates = ProjectTemplate::where("user_id","=",Auth::id())->get();
        $templates = $templates->pluck('title','id');
        return response()->json($templates);
    }

    function createFromTemplate(Request $request)
    {

        $file = $request->file('file');
        $tpl = $request->input('tpl');
        $title = $request->input('title');

        if($request->hasFile('file')){
            $code  = json_decode(file_get_contents($file->path()));
        }
        elseif($request->has("tpl"))
        {
            $template = ProjectTemplate::where("user_id","=",Auth::id())->find($tpl);
            $code = json_decode($template->template_code);
        }
        else{
            return abort(404);
        }

        try{
            $project = new Project;
            $project->title = $code->title;
            $project->user_id = Auth::id();
            $project->title = $code->title;
            $project->layout = 'kanban';
            $project->privacy = $code->privacy;
            $project->save();
            dispatch(new ImportProjectTemplate($project,$code));
        }
        catch(Exception $e){
            Log::error($e);
        }

       return response()->json([
            'status' => 'ok',
            'id' => $project->id
        ]);

    }




}
