<?php

namespace App\Http\Controllers;

use App\ActionLog;
use App\Project;
use App\Task;
use App\TaskSection;
use Auth;
use Illuminate\Http\Request;

class SectionController extends Controller
{

    public function addSection(Request $request)
    {
        $title = $request->input('title');
        $view_type = $request->input('view_type');
        $view_id = $request->input('view_id');
        $section = new TaskSection;
        $section->title = $title;

        if($view_type == 'team')
        {
            $section->team_id = $view_id;
            if(!Auth::user()->hasTeamAccess($view_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }
        elseif($view_type == 'project')
        {
            $section->project_id = $view_id;
            if(!Auth::user()->hasProjectAccess($view_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }

        $section->save();
        return response()->json([
            'status' => 'ok',
            'id' => $section->id,
            'title' => $section->title
        ]);

    }

    public function renameSection(Request $request)
    {
        $title = $request->input('title');
        $section_id = $request->input('section_id');
        $section = TaskSection::find($section_id);
        if(!empty($section->project_id))
        {
            if(!Auth::user()->hasProjectAccess($section->project_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }
        elseif(!empty($section->team_id))
        {
            if(!Auth::user()->hasTeamAccess($section->team_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }
        ActionLog::log(Auth::id(),sprintf("Renamed section from %s to %s",$section->title,$title));
        $section->title = $title;
        $section->save();
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function deleteSection(Request $request)
    {
        $section_id = $request->input('section_id');
        $section = TaskSection::find($section_id);
        $allowedFlag = false;
        if(!empty($section->project_id))
        {
            if( empty(Project::find($section->project_id)) && Auth::user()->isAdmin())
            {
                    // allowed
                $allowedFlag = true;
            }
            else if(!Auth::user()->hasProjectAccess($section->project_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }
        elseif(!empty($section->team_id))
        {
            if(!Auth::user()->hasTeamAccess($section->team_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }

        ActionLog::log(Auth::id(),sprintf("Deleted section named '%s' ",$section->title));
        $tasks = Task::where("task_section_id",'=',$section->id)->delete();
        $section->delete();

        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function archiveSectionTasks(Request $request)
    {
        $section_id = $request->input('section_id');
        $section = TaskSection::find($section_id);
        if(!empty($section->project_id))
        {
            if(!Auth::user()->hasProjectAccess($section->project_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }
        elseif(!empty($section->team_id))
        {
            if(!Auth::user()->hasTeamAccess($section->team_id)){
                return redirect()->route('overview')->with('error', trans("common.no_access"));
            }
        }
        $tasks = Task::where("task_section_id",$section->id)->where("done",1)->update(['archived' => 1]);
        return response()->json([
            'status' => 'ok'
        ]);
    }

    public function resortTasks(Request $request)
    {
        $section_id = $request->input('section_id');
        $new_order = $request->input('new_order');
        // Check sort syntax
        $exp = explode('|',$new_order);
        if(is_numeric_array($exp)){
            $section = TaskSection::find($section_id);
            $section->sort = $new_order;
            $section->save();
            return response()->json([
                'status' => 'ok'
            ]);
        }
        else{
            return response()->json([
                'status' => 'error'
            ]);
        }

    }

}
