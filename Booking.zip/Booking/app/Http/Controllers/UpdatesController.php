<?php

namespace App\Http\Controllers;

use App\Settings;
use Exception;
use File;
use Illuminate\Http\Request;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Storage;

class UpdatesController extends Controller
{
    const METIS_UPDATE_SERVER = "http://updates.gometis.com";

    public function link(Request $request)
    {
        return view("admin.updates.link");
    }

    public function check(Request $request)
    {
        $code = $request->input('code');
        // Verify code
        $link = self::METIS_UPDATE_SERVER."/verify";
        $client = new \GuzzleHttp\Client();
        $res = $client->request('POST', $link,[
            'form_params' => [
                'code' => $code
            ]
        ]);
        if($res->getStatusCode() == 200){
            $body = json_decode($res->getBody());
            if($body->status == 200)
            {
                Settings::put("purchase_code",$code);
                Settings::flush();
                return redirect()->route('admin.info')->with('status',$body->message);
            }
            else
            {
                return redirect()->route('admin.info')->with('error',$body->message);
            }
        }
        else{
            return redirect()->route('admin.info')->with('error',"Couldn't connect to update server");
        }
    }

    public function checkUpdates(Request $request)
    {
        $code = Settings::gets("purchase_code");
        $version = Settings::gets("version");

        $link = self::METIS_UPDATE_SERVER."/get-latest";
        $client = new \GuzzleHttp\Client();
        $res = $client->request('GET', $link,[
            'query' => [
                'code' => $code,
                'version' => $version
            ]
        ]);

        if($res->getStatusCode() == 200)
        {
            $body = json_decode($res->getBody());

            if($body->status == 200)
            {
                return redirect()->route('admin.info')->with('status',$body->message);
            }
            elseif($body->status == 426)
            {
                return view('admin.updates.download_update',json_decode(json_encode($body),true));
            }
            elseif(in_array($body->status,[403,404,500]))
            {
                return redirect()->route('admin.info')->with('error',$body->message);
            }
            else{
                return redirect()->route('admin.info')->with('error',"Unknown error occurred in update server - Try again later");
            }

        }
        else{
            return redirect()->route('admin.info')->with('error',"Couldn't connect to update server");
        }

    }

    public function downloadUpdate(Request $request)
    {
        $code = Settings::gets("purchase_code");
        $version = Settings::gets("version");
        $from = $request->input('from');
        $to = $request->input('to');
        $checksum = $request->input('checksum');
        if($version != $from)
        {
            return redirect()->route('admin.info')->with('error',"Updates were already installed");
        }
        $link = self::METIS_UPDATE_SERVER."/download-latest";
        $client = new \GuzzleHttp\Client();
        try{
            $res = $client->request('GET', $link,[
                'query' => [
                    'code' => $code,
                    'from' => $from,
                    'to' => $to
                ]
            ]);
        }catch (\GuzzleHttp\Exception\BadResponseException $e){
            $res = $e->getResponse();
            $rbody = json_decode($res->getBody()->getContents());
        }



        if($res->getStatusCode() == 200)
        {
            $contents  = $res->getBody();
            $zipfile=  $from."_to_".$to.".zip";
            Storage::put('updates/'.$zipfile, $contents);
            return redirect()->route('update.apply-updates');
        }
        else{
            return redirect()->route('admin.info')->with('error',"Couldn't download update file - Try again later");
        }

    }

    public function ApplyUpdates(Request $request)
    {
//        $version = Settings::gets("version");
        $path =  storage_path("app/updates");
        $files = File::glob($path."/*");
        if(!count($files))
        {
            return redirect()->route('admin.info')->with('error',"Updates files missing");
        }
        $update_path = $files[0];
        if(!file_exists($update_path)){
            return redirect()->route('admin.info')->with('error',"Updates files not found");
        }
        $mainZip = \Zipper::make($update_path);
        $versions = $mainZip->listFiles();;
        asort($versions,SORT_NUMERIC);

        $mainZip->extractTo(storage_path('app/temp_updates'));

        foreach($versions as $version)
        {
            $currentZip = $version;
            $x = \Zipper::make(storage_path('app/temp_updates/'.$version));
            $x->extractTo(base_path());
        }
        unlink($update_path);
        return redirect()->route('upgrade');
    }

}
