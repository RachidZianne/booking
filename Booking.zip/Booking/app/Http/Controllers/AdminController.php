<?php

namespace App\Http\Controllers;

use App\ActionLog;
use App\Hardsetting;
use App\Language;
use App\Settings;
use Config;
use Exception;
use Illuminate\Http\Request;
use Log;
use Storage;

class AdminController extends Controller
{

    public function general()
    {
        $data = [];
        return view("admin.general",$data);
    }


    public function generalSave(Request $request)
    {
        $site_name = $request->input('site_name');
        $site_url = $request->input('site_url');
        $site_timezone = $request->input('timezone');
        $first_day = (int) $request->input('firstday');
        \Config::write("app",['name' => $site_name,'timezone' => $site_timezone, 'url' => $site_url]);

        Settings::put('site_name',$site_name);
        Settings::put('timezone',$site_timezone);
        Settings::put('start_day',$first_day);
        Settings::flush();

        if($request->hasFile("logo"))
        {
            try{
                $img =  $request->logo->storeAs('essentials', 'logo.png');
            }catch(Exception $e){
                Log::error($e);
                return redirect()->back()->with('error', $e->getMessage());
            }
        }
        return redirect()->back()->with('status', trans('messages.settingssaved'));

    }

    public function preferences()
    {
        $data = [];
        return view("admin.preferences",$data);
    }

    public function preferencesSave (Request $request)
    {
        $inputs = $request->all();
        foreach ($inputs as $ikey => $input)
        {
            if(starts_with($ikey,"pref_")){
                Settings::put($ikey,$input);
            }
        }
        Settings::flush();
        return redirect()->back()->with('status', trans('messages.prefssaved'));

    }

    public function mail()
    {
        $data = [];
        return view("admin.mail",$data);
    }

    public function mailSave (Request $request)
    {
        // Mail
        $driver = $request->input("driver");
        $host = $request->input("host");
        $username = $request->input("username");
        $password = $request->input("password");
        $port = $request->input("port");
        $encryption = $request->input("encryption");
        $sitename = Config::get("app.name");
        $defaultmail = $request->input("defaultmail");

        try {
            \Config::write("mail", [
                "driver"     => $driver,
                "host"       => $host,
                "port"       => $port,
                "encryption" => $encryption,
                "username"   => $username,
                "password"   => $password,
                "from"       => [
                    'address' => $defaultmail,
                    'name'    => $sitename,
                ]
            ]);
        }catch(Exception $e){
            Log::error($e);
            return redirect()->back()->with('error', trans("messages.config_unwriteable"));
        }
        return redirect()->back()->with('status', trans("messages.settingssaved"));

    }

    public function map()
    {
        $data = [];
        return view("admin.map",$data);
    }

    public function mapSave(Request $request)
    {
        $location_enabled = $request->input('location_enabled');
        if($location_enabled == 'on')
        {
            $location_enabled = 1;
        }
        else{
            $location_enabled = 0;
        }
        $location_js_api = $request->input('location_js_api');
        if($location_enabled == 1 && empty($location_js_api)){
            return redirect()->back()->with('error', trans("messages.gmaps_api_req"));
        }
        $location_embed_api = $request->input('location_embed_api');

        Settings::put('location_enabled',$location_enabled);
        Settings::put('location_js_api',$location_js_api);
        Settings::put('location_embed_api',$location_embed_api);

        Settings::flush();
        return redirect()->back()->with('status', trans("messages.settingssaved"));

    }

    public function info()
    {
        $data = [];
        return view("admin.info",$data);
    }

    public function history()
    {
        $data['logs'] = ActionLog::with("user")->orderBy("id","desc")->paginate(100);
        return view("admin.history",$data);
    }

    public function downloadLog(Request $request)
    {
        $day = $request->input('day');
        try{
            $date = \Carbon::parse($day);
            $ds = $date->toDateString();
            $fileName = "laravel-".$ds.".log";
            $contents = file_get_contents(storage_path('logs/'.$fileName));
            $attachment_name = "metis-$ds.log";
            return response($contents)
                ->header('Content-Type', "application/octet-stream")
                ->header('Content-Disposition', "attachment; filename=\"$attachment_name\" ")
                ->header('Cache-control', 'public');

        }
        catch (Exception $e)
        {
            Log::error($e);
            return redirect()->back()->with('error', trans("messages.no_log_day"));
        }
    }

    public function tweaks()
    {
        $data = [];
        return view("admin.tweaks",$data);
    }

    public function themes()
    {
        $data = [];
        return view("admin.themes",$data);
    }

    public function themesSave(Request $request)
    {
        $file = $request->input('cssdata');
        $removedPhpWrap = preg_replace('/^<\?php(.*)(\?>)?$/s', '$1', $file);
        Hardsetting::put("customcss",$removedPhpWrap);
        Hardsetting::flush();
        return redirect()->back()->with('status', trans("messages.settingssaved"));
    }

    public function tweaksSave(Request $request)
    {
        $tw_ddm = onToBool($request->input('tweaks_ddm'));
        $tw_stack = onToBool($request->input('tweaks_stack'));
        $fullscreen_mode = onToBool($request->input('fullscreen_mode'));

        Settings::put('tweaks_ddm',$tw_ddm);
        Settings::put('tweaks_stack',$tw_stack);
        Settings::put('fullscreen_mode',$fullscreen_mode);

        Settings::flush();
        return redirect()->back()->with('status', trans("messages.settingssaved"));
    }

    public function flushCache(Request $request)
    {
        Settings::flush();
        Language::regenerateJS();
        return redirect()->back()->with('status', trans("messages.flushed"));
    }


    public function api()
    {
        $data = [];
        return view("admin.api",$data);
    }

    public function apiRegen()
    {
        $random_key = str_random(65);
        Settings::put("api_key",$random_key);
        Settings::flush();
        return redirect()->back()->with('status', trans("messages.settingssaved"));
    }

    public function apiDelete()
    {
        Settings::put("api_key",'');
        Settings::flush();
        return redirect()->back()->with('status', trans("messages.api_disabled"));
    }

    public function oathToggle()
    {
        $oauth = Settings::gets("enable_oauth",true);
        if($oauth)
        {
            Settings::put("enable_oauth",0);
            Settings::flush();
            return redirect()->back()->with('status', trans('messages.oauth_dis'));
        }
        else{
            Settings::put("enable_oauth",1);
            Settings::flush();
            return redirect()->back()->with('status', trans('messages.oauth_en'));
        }

    }
}
