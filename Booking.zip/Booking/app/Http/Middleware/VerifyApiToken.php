<?php

namespace App\Http\Middleware;

use App\Settings;
use App\User;
use App\UserToken;
use Auth;
use Closure;

class VerifyApiToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */

    public function handle($request, Closure $next)
    {
        $key = Settings::gets("api_key",true);
        $oauth_enabled = Settings::gets("enable_oauth",true);

        $sent_request = explode(" ",$request->header('Authorization'));

        if( (!empty($key) && $sent_request[0] == $key )) // Comment
        {
            return $next($request);
        }
        elseif( ($oauth_enabled && isset($sent_request[1]) && ($sent_request[0] == "Bearer") ) )
        {

            if(!empty($request->get('token')))
            {
                $token = $request->get('token');
            }
            else{
                $token = UserToken::where("token","=",$sent_request[1])->first();
            }

            if(!$token)
            {
                return response()->json(['status' => '401']);
            }

            Auth::setUser(User::find($token->user_id));

            return $next($request);
        }
        elseif( ($oauth_enabled && $request->is('api/auth/*')) )
        {
            return $next($request);
        }
        else{
            return response()->json(['status' => '401']);
        }

    }
}
