<?php

namespace App\Http\Middleware;

use Auth;
use Closure;

class RestrictClient
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */

   public function handle($request, Closure $next)
    {
        $allowed_routes = [
            'overview',
            'project',
            'calendar',
            'avatar',
            'tasks.commentload',
            'tasks.commentloadlive',
            'tasks.commentlike',
            'tasks.editcomment',
            'tasks.addcomment',
            'tasks.commentattach',
            'tasks.loadtasks',
            'tasks.downloadattachment',
            'notifications.get',
            'notifications.mark_read',
            'notifications.task_view',
            'notifications.task_comment',
            'logo',
            'profile',
            'profile_changepw',
            'profile_save',
            'profile_savepw',
            'login',
            'logout',
            'projects.files',
            'projects.progress',
        ];

        if(!Auth::guest() && Auth::user()->type == 'client')
        {
            $route_name = $request->route()->getName();
            if(!in_array($route_name,$allowed_routes))
            {
                return redirect()->route('login')->with('error',"No permissions");
            }
        }
        return $next($request);
    }
}
