<?php

namespace App\Http\Middleware;

use Closure;

class VeryifyNotInstalled
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $ins = \Config::get("metis.installed");
        if($ins == 1){
            return redirect()->route("overview");
        }
        return $next($request);
    }
}
