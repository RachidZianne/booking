<?php

namespace App\Http\Middleware;

use Closure;

class VerifyInstalled
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $ins = \Config::get("metis.installed");
        if($ins == 0){
            return redirect()->route("install");
        }
        return $next($request);
    }
}
