<?php

namespace App\Http\Middleware;

use Closure;
use Config;

class VerifyDemoRestrictions
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */

    public function handle($request, Closure $next)
    {
        $disallowed_routes = [
            'admin.preferences_save',
            'admin.mail_save',
            'admin.map_save',
            'admin.general_save',
            'admin.log',
            'admin.tweaks_save',
            'admin.flushcache',
            'admin.api_delete',
            'admin.api_regen',
            'user.resend_invite',
            'user.send_invite',
            'user.team.delete',
            'profile.template_delete',
            'profile_save',
            'profile_savepw',
            'admin.languages.saveTranslator',
            'admin.languages.saveUpdateLanguage',
            'admin.languages.delete',
            'admin.languages.create',
        ];
        $disallowed_api_routes = [
            'api.user.delete',
            'api.user.update',
            'api.team.delete',

        ];
        $demo = Config::get("metis.demo");

        if(!$demo){
            return $next($request);
        }

        $name = $request->route()->getName();

        if(in_array($name,$disallowed_routes))
        {
            return redirect()->back()->with('error', 'Disabled in demo. Some features are disabled in demo for best experience to all customers');
        }

        if(in_array($name,$disallowed_api_routes))
        {
            return response()->json([
                'status' => 405,
                'msg' => 'Disabled in demo'
            ]);
        }

        return $next($request);

    }
}
