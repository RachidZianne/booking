<?php

namespace App\Http\Middleware;

use Closure;

class CheckTeamAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $teamId = intval($request->route()->parameter('id'));
        if(!$request->user()->hasTeamAccess($teamId)){
            return redirect()->route('overview');
        };
        return $next($request);
    }
}
