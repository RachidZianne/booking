<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\Pivot;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\User
 *
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Team[] $teams
 * @mixin \Eloquent
 * @property int $id
 * @property string $email
 * @property string $password
 * @property string $name
 * @property string $type
 * @property string|null $remember_token
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereUpdatedAt($value)
 * @property \Carbon\Carbon|null $last_login
 * @method static \Illuminate\Database\Eloquent\Builder|\App\User whereLastLogin($value)
 */
class User extends Authenticatable
{
    use Notifiable;
    protected $dates = ['last_login','deleted_at'];
    use SoftDeletes;

    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function isAdmin()
    {
        return (int)($this->type == "root");
    }
    public function isStaff()
    {
        return (int)($this->type == "root" || $this->type == 'staff');
    }

    public function getTeams()
    {
        if($this->type == "root")
        {
            return Team::all();
        }
        else{
            return $this->teams()->get();
        }
    }

    public function allowedProjectIds($limit = 25,$offset=0)
    {
        $user_id = $this->id;
        $type = $this->type;
        $public = [];
        $project_teams = ProjectTeam::whereIn("team_id",$this->getTeams()->pluck('id'))->orderBy("id","desc")->limit($limit)->get()->pluck('project_id')->toArray();
        $custom_section = ProjectUser::where("user_id","=",$user_id)->orderBy("id","desc")->limit($limit)->get()->pluck('project_id')->toArray();
        if($this->isStaff()){
        $public = Project::where("privacy","=","public")->orWhereRaw("(`privacy` = 'me' and `user_id` = '$user_id')")->orderBy("id","desc")->limit($limit)->get()->pluck('id')->toArray();
        }
        $return = array_unique(array_merge($project_teams,$custom_section,$public));
        arsort($return);

        $return = array_slice($return,$offset,$limit);

        return $return;
    }

    public function allowedProjects($limit = 25)
    {
        $allowed = $this->allowedProjectIds($limit);
        $projects = Project::active()->whereIn("id",$allowed)->orderBy("id","desc")->get();
        return $projects;
    }

    public function scopeStaff($query)
    {
        return $query->where("type","=","root")->orWhere("type","=","staff");
    }

    public function teams()
    {
        return $this->belongsToMany('App\Team');
    }

    public function hasTeamAccess($id)
    {
        return $this->getTeams()->contains($id);
    }

    public function hasProjectAccess($id)
    {
        $project = Project::find($id);
        if($project->privacy == 'public'){
            return true;
        }
        elseif($project->privacy == 'me'){
           return ($project->user_id == $this->id);
        }
        elseif($project->privacy == 'teams'){
            $teams = $this->getTeams()->pluck('id')->toArray();
            return ProjectTeam::where("project_id","=",$id)->whereIn("team_id",$teams)->get()->isNotEmpty();
        }
        elseif($project->privacy == 'users'){
            return ProjectUser::where("project_id","=",$id)->where("user_id",$this->id)->get()->isNotEmpty();
        }
        else{
            return false;
        }
    }

    public function hasSectionAccess($id)
    {
        $section = TaskSection::find($id);
        if($section->team_id)
        {
            return $this->hasTeamAccess($section->team_id);
        }
        elseif($section->project_id){
            return $this->hasProjectAccess($section->project_id);
        }
        else{
            return false;
        }
    }

}
