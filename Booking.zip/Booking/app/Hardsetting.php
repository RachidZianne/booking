<?php

namespace App;

use Cache;
use Illuminate\Database\Eloquent\Model;

class Hardsetting extends Model
{
    public $timestamps = false;
    public $primaryKey  = "name";
    protected $fillable = array('name','value');
    static public $prefix = "hstg_";

    public static function gets($keyname,$fresh=false,$default=null){

        if(is_null($fresh))
        {
            $fresh = false;
        }

        if(Cache::has(self::$prefix.$keyname) && !$fresh){
            $result = Cache::get(self::$prefix.$keyname);
        }
        else{
            $value = self::find($keyname);
            if($value){
                $result = $value->value;
            }
            else{
                $result = $default;
            }
            Cache::put(self::$prefix.$keyname,$result,1440);
        }
        return $result;
    }

    public static function put($keyname,$value){

        $result = self::find($keyname);
        if(!$result){
            $result = new Hardsetting;
            $result->name = $keyname;
        }
        $result->value = $value;
        $result->save();
        Cache::put(self::$prefix.$keyname,$value,1440);

        return $result;

    }

    public static function flush(){
        Cache::flush();
    }

    public static function forget($keyname){
        Cache::forget(self::$prefix.$keyname);
        return;
    }
}
