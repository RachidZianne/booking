<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Team
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskSection[] $tasksections
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\ProjectTeam[] $teamprojects
 * @mixin \Eloquent
 * @property int $id
 * @property string $title
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Team whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Team whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Team whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Team whereUpdatedAt($value)
 */
class Team extends Model
{
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
    ];

    public function tasksections()
    {
        return $this->hasMany('App\TaskSection');
    }

    public function tasks()
    {
        return $this->hasManyThrough('App\Task','App\TaskSection');
    }

    public function teamprojects()
    {
        return $this->hasMany('App\ProjectTeam');
    }
}
