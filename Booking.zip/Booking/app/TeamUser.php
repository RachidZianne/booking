<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\TeamUser
 *
 * @mixin \Eloquent
 */
class TeamUser extends Model
{
    protected $table = 'team_user';
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
        'team_id' => 'integer',
    ];
    protected $fillable = ['user_id', 'team_id'];
}
