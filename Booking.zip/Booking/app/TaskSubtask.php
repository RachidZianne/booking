<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskSubtask extends Model
{
    protected $fillable = ['archived','done'];
    protected $dates = ['done_at','due_date'];
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
        'assgined_to' => 'integer',
        'task_id' => 'integer',
        'done' => 'integer',
        'archived' => 'integer',
    ];

    public function task()
    {
        return $this->belongsTo('App\Task');
    }

}
