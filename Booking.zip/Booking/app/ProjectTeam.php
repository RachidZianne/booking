<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\ProjectTeam
 *
 * @property-read \App\Project $project
 * @property-read \App\Team $team
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property int $project_id
 * @property int $team_id
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ProjectTeam whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ProjectTeam whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ProjectTeam whereProjectId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ProjectTeam whereTeamId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\ProjectTeam whereUpdatedAt($value)
 */
class ProjectTeam extends Model
{
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'project_id' => 'integer',
        'team_id' => 'integer',
    ];

    public function team()
    {
        return $this->belongsTo('App\Team');
    }

    public function project()
    {
        return $this->belongsTo('App\Project');
    }

}
