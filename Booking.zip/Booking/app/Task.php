<?php

namespace App;

use App\Scopes\ArchiveScope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Task
 *
 * @property-read \App\User $assigned
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskComment[] $comments
 * @property-read \App\TaskSection $task_section
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskTag[] $tasktags
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task archived($value = false)
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property string $title
 * @property int|null $assigned_to
 * @property int|null $task_section_id
 * @property int $done
 * @property string|null $done_at
 * @property int $archived
 * @property string|null $due_date
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereArchived($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereAssignedTo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereDone($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereDoneAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereDueDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereTaskSectionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereUpdatedAt($value)
 * @property int $user_id
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Task whereUserId($value)
 */
class Task extends Model
{
    protected $fillable = ['archived','done'];
    protected $dates = ['done_at','due_date'];
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
        'assgined_to' => 'integer',
        'task_section_id' => 'integer',
        'done' => 'integer',
        'archived' => 'integer',
    ];

    protected static function boot()
    {
//        parent::boot();
//
//        static::addGlobalScope(new ArchiveScope());
    }

    public function subtasks()
    {
        return $this->hasMany('App\TaskSubtask');
    }

    public function comments()
    {
        return $this->hasMany('App\TaskComment');
    }

    public function tasktags()
    {
        return $this->hasMany('App\TaskTag');
    }

    public function task_section()
    {
        return $this->belongsTo('App\TaskSection');
    }

    public function assigned()
    {
        return $this->belongsTo('App\User','assigned_to');
    }

    public function assigned_basic()
    {
        return $this->assigned()->select(['id','name']);
    }

    public function scopeArchived($query,$value=false)
    {
        if($value){
            return $query;
        }
        else{
            return $query->where("archived",0)->whereNull("snoozed_until");
        }
    }

    public function scopeDone($query)
    {
        return $query->where('done', 1);
    }



}
