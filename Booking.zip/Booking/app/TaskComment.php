<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;


/**
 * App\TaskComment
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskCommentAttachment[] $attachment_files
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskCommentAttachment[] $attachment_images
 * @property-read \App\TaskCommentAttachment $attachment_location
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskCommentAttachment[] $attachment_vcard
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskCommentAttachment[] $attachments
 * @property-read mixed $is_comment_owner
 * @property-read mixed $liked_by_auth_user
 * @property-read mixed $likes_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Like[] $likes
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskCommentAttachment[] $other_attachments
 * @property-read \App\User $user
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property int $user_id
 * @property int $task_id
 * @property string|null $content
 * @property int $edited
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereEdited($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereTaskId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskComment whereUserId($value)
 */
class TaskComment extends Model
{
    protected $appends = ['liked_by_auth_user','is_comment_owner','likes_count'];

    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
        'task_id' => 'integer',
        'edited' => 'integer',
        'liked_by_auth_user' => 'integer',
        'is_comment_owner' => 'integer',
        'likes_count' => 'integer',
    ];
    public function attachments()
    {
        return $this->hasMany('App\TaskCommentAttachment');
    }

    public function other_attachments()
    {
        return $this->hasMany('App\TaskCommentAttachment');
    }

    public function attachment_files()
    {
        return $this->hasMany('App\TaskCommentAttachment')->where("task_comment_attachment_type","=","file");
    }

    public function attachment_images()
    {
        return $this->hasMany('App\TaskCommentAttachment')->where("task_comment_attachment_type","=","image");
    }

    public function attachment_vcard()
    {
        return $this->hasMany('App\TaskCommentAttachment')->where("task_comment_attachment_type","=","vcard");
    }

    public function attachment_location()
    {
        return $this->hasOne('App\TaskCommentAttachment')->where("task_comment_attachment_type","=","location");
    }

    public function likes()
    {

        return $this->hasMany('App\Like');
    }

    public function likesCount()
    {

        return $this->likes()->count();
    }

    public function task()
    {
        return $this->belongsTo('App\Task');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function user_basic()
    {

        return $this->user()->select(['id','name']);
    }

    public function getLikesCountAttribute()
    {
        return $this->likes->count();
    }

    public function getLikedByAuthUserAttribute()
    {
        $userId = auth()->user()->id;
        $like = $this->likes->first(function ($key, $value) use ($userId) {
            return $key->user_id === $userId;
        });
        if ($like) {
            return true;
        }
        return false;
    }

    public function getIsCommentOwnerAttribute()
    {
       $userId = auth()->user()->id;
       return ($this->user_id === $userId);
    }




}
