<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActionLog extends Model
{
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public static function log($user_id,$action)
    {
        $result = new ActionLog;
        $result->user_id = $user_id;
        $result->action = $action;
        $result->save();
        return $result;
    }

}
