<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\TaskCommentAttachment
 *
 * @property-read \App\TaskCommentAttachmentLocation $location
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property int $task_comment_id
 * @property string $task_comment_attachment_type
 * @property string $name
 * @property string|null $ext
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereExt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereTaskCommentAttachmentType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereTaskCommentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachment whereUpdatedAt($value)
 */
class TaskCommentAttachment extends Model
{
    protected $fillable = ['task_comment_id'];
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'task_comment_id' => 'integer',
    ];

    public function location()
    {
        return $this->hasOne('App\TaskCommentAttachmentLocation');
    }

    public function taskComment()
    {
        return $this->belongsTo('App\TaskComment');
    }
}
