<?php

namespace App;

use Auth;
use Illuminate\Database\Eloquent\Model;

class UserPreference extends Model
{
        public static function getPref($key)
        {
            $pref = self::where("user_id","=",Auth::id())->where("key","=",$key)->first();
            if(empty($pref))
            {
                return "";
            }
            else{
                return $pref->value;
            }
        }

        public static function setPref($key,$value)
        {
            $result = self::where("user_id","=",Auth::id())->where("key","=",$key)->first();
            if(!$result){
                $result = new UserPreference;
                $result->user_id = Auth::id();
                $result->key = $key;
            }
            $result->value = $value;
            $result->save();
        }

        public static function removePref($key)
        {
            $result = self::where("user_id","=",Auth::id())->where("key","=",$key)->delete();
        }
}
