<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

/**
 * App\TaskSection
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Task[] $tasks
 * @mixin \Illuminate\Database\Eloquent\Builder
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property string|null $title
 * @property int|null $team_id
 * @property int|null $project_id
 * @property string|null $sort
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereProjectId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereSort($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereTeamId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskSection whereUpdatedAt($value)
 */
class TaskSection extends Model
{
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'team_id' => 'integer',
        'project_id' => 'integer',
    ];

    public function tasks()
    {
        return $this->hasMany('App\Task');
    }

    public function subtasks()
    {
        return $this->hasManyThrough('App\TaskSubTask','App\Task');
    }

    public function selftasks()
    {
        return $this->tasks()->where("assigned_to","=",Auth::id());
    }

    public function team()
    {
        return $this->belongsTo('App\Team');
    }

    public function project()
    {
        return $this->belongsTo('App\Project');
    }

    public function projectVisible()
    {
        return $this->belongsTo('App\Project','project_id')->active();
    }

    public function scopeTeamallowed($query,$teams)
    {
        return $query->whereIn("team_id",$teams);
    }

    public static function scopeAllowed($query)
    {
        $teams = Auth::user()->getTeams()->pluck('id')->toArray();
        return $query->teamallowed($teams)->orWhereHas("projectVisible",function($query)use($teams){
            $query->visible($teams);
        });
    }


}
