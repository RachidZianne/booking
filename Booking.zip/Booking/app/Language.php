<?php

namespace App;

use Artisan;
use Exception;
use File;
use Illuminate\Database\Eloquent\Model;

class Language extends Model
{

    public function scopeActive($query)
    {
        return $query->where("active", "=","1");
    }

    public static function installFile($filePath)
    {
        return self::installPayload(file_get_contents($filePath));
    }

    public static function regenerateJS()
    {
        Artisan::call('lang:js');
    }

    public static function processXmlLanguage($xml,$languagePath)
    {

        foreach($xml->details->children() as $section){
            $section_name = $section->getName();
            $section_path = $languagePath."/".$section_name.".php";
            $languageString = "<?php
                return array(";
            foreach($section->children() as $phrase)
            {
                // This should output something like 'yes' => 'oui'
                $languageString.= "'".$phrase['name']."'"." => '".$phrase."'".",\n";
            }
            $languageString.= ");";
            $y = File::put($section_path, $languageString);
        }
        self::regenerateJS();
        return true;
    }

    public static function deleteLang($language)
    {
        $code = $language->code;
        $languagePath = lang_path($code);
        $directory = File::deleteDirectory($languagePath);
        return $directory;
    }

    public static function installPayload($payload,$create_language=true)
    {

        $language = simplexml_load_string($payload);
        $code = $language->meta->langCode;
        $languagePath = lang_path($code);
        // Overwrite directory if exists
        if(!file_exists($languagePath))
        {
            $directory = File::makeDirectory($languagePath, 0775, true, true);
            if(!$directory)
            {
                return false;
            }
        }
        if($create_language)
        {
            $lanz = Language::where("code","=",$code)->first();
            if(!empty($lanz))
            {
                throw new Exception(trans("messages.lang_exist_err"));
            }
            Language::makeLang($language->meta->name,$language->meta->langCode,1,$language->meta->author,$language->meta->authorUrl);
        }

        // Process XML to arrays of phrases
        self::processXmlLanguage($language,$languagePath);

        return true;

    }

    public static function makeLang($name,$code,$active,$author,$author_url)
    {

        $model = new Language;
        $model->language = $name;
        $model->code = $code;
        $model->active = $active;
        $model->author = $author;
        $model->author_url = $author_url;
        $model->save();

        return $model;
    }

}
