<?php

function slugify($text)
{
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    if (empty($text)) {
        return 'n-a';
    }
    return $text;
}

function language_sections()
{
    return ['common','messages','admin','auth','notifications','passwords','pagination','emails'];
}

function supported_airdatepicker_langs()
{
    return ['cs','da','de','es','fi','fr','hu','nl','pl','pt','ro','sk','zh'];
}

function supported_momentjs_langs()
{
    return ['af', 'ar-dz', 'ar-kw', 'ar-ly', 'ar-ma', 'ar-sa', 'ar-tn', 'ar', 'az', 'be', 'bg', 'bm', 'bn', 'bo', 'br', 'bs', 'ca', 'cs', 'cv', 'cy', 'da', 'de-at', 'de-ch', 'de', 'dv', 'el', 'en-au', 'en-ca', 'en-gb', 'en-ie', 'en-nz', 'eo', 'es-do', 'es-us', 'es', 'et', 'eu', 'fa', 'fi', 'fo', 'fr-ca', 'fr-ch', 'fr', 'fy', 'gd', 'gl', 'gom-latn', 'gu', 'he', 'hi', 'hr', 'hu', 'hy-am', 'id', 'is', 'it', 'ja', 'jv', 'ka', 'kk', 'km', 'kn', 'ko', 'ky', 'lb', 'lo', 'lt', 'lv', 'me', 'mi', 'mk', 'ml', 'mr', 'ms-my', 'ms', 'my', 'nb', 'ne', 'nl-be', 'nl', 'nn', 'pa-in', 'pl', 'pt-br', 'pt', 'ro', 'ru', 'sd', 'se', 'si', 'sk', 'sl', 'sq', 'sr-cyrl', 'sr', 'ss', 'sv', 'sw', 'ta', 'te', 'tet', 'th', 'tl-ph', 'tlh', 'tr', 'tzl', 'tzm-latn', 'tzm', 'uk', 'ur', 'uz-latn', 'uz', 'vi', 'x-pseudo', 'yo', 'zh-cn', 'zh-hk', 'zh-tw'];
}

function supported_fullcalendar_langs()
{
    return ['af', 'ar-dz', 'ar-kw', 'ar-ly', 'ar-ma', 'ar-sa', 'ar-tn', 'ar', 'bg', 'ca', 'cs', 'da', 'de-at', 'de-ch', 'de', 'el', 'en-au', 'en-ca', 'en-gb', 'en-ie', 'en-nz', 'es-do', 'es-us', 'es', 'et', 'eu', 'fa', 'fi', 'fr-ca', 'fr-ch', 'fr', 'gl', 'he', 'hi', 'hr', 'hu', 'id', 'is', 'it', 'ja', 'kk', 'ko', 'lb', 'lt', 'lv', 'mk', 'ms-my', 'ms', 'nb', 'nl-be', 'nl', 'nn', 'pl', 'pt-br', 'pt', 'ro', 'ru', 'sk', 'sl', 'sq', 'sr-cyrl', 'sr', 'sv', 'th', 'tr', 'uk', 'vi', 'zh-cn', 'zh-tw'];
}

function is_locale_supported($type,$locale)
{
    if($type == 'fullcalendar')
    {
        return in_array($locale,supported_fullcalendar_langs());
    }
    elseif($type == 'momentjs')
    {
        return in_array($locale,supported_momentjs_langs());
    }
    elseif($type == 'airpicker')
    {
        return in_array($locale,supported_airdatepicker_langs());
    }
    else{
        return false;
    }
}


function highlight_word_vars($input)
{
    $regex = '~(:\w+)~';
    if (preg_match_all($regex, $input, $matches, PREG_PATTERN_ORDER)) {
        foreach ($matches[1] as $word) {
            $input = str_replace($word,"<span class='variablekeyword'>$word</span>",$input);
        }
    }
    return $input;
}

function lang_get_phrases($code){
    $org = App::getLocale();
    App::setLocale($code);
    $lang = [];
    foreach(language_sections() as $section)
    {
               $lang[$section] = Lang::get($section);
    }
    App::setLocale($org); // reset to original language
    return $lang;
}

function metis_site_link()
{
    return "https://gometis.com";
}

function is_numeric_array($array) {
    foreach ($array as $key => $value) {
        if (!is_numeric($value)) return false;
    }
    return true;
}

function validate_email($email)
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function human_filesize($bytes)
{
    $filesizename = array(" Bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");
    return round($bytes/pow(1024, ($i = floor(log($bytes, 1024)))), 2) . $filesizename[$i];
}


function array_key_diff_recursive($aArray1, $aArray2) {
    $aReturn = array();

    foreach ($aArray1 as $mKey => $mValue) {
        if (array_key_exists($mKey, $aArray2)) {
            if (is_array($mValue)) {
                $aRecursiveDiff = array_key_diff_recursive($mValue, $aArray2[$mKey]);
                if (count($aRecursiveDiff)) { $aReturn[$mKey] = $aRecursiveDiff; }
            }
            else {
                if (!array_key_exists($mKey,$aArray2)) {
                    $aReturn[$mKey] = $mValue;
                }
            }
        } else {
            $aReturn[$mKey] = $mValue;
        }
    }
    return $aReturn;
}

function parse_comment_text($content)
{
    $user_id = null;
    if(!empty(trim($content))){
        // Parse HTML Content
        $content = strip_tags($content, '<b><i><span><br>');
        $content = str_replace('&nbsp;', ' ', $content);
        $dom = new \DOMDocument('1.0', 'utf-8');
        $dom->loadHTML($content);
        $spans = $dom->getElementsByTagName('span');
        for ($i = $spans->length - 1; $i >= 0; $i--) {
            $spann = $spans->item($i);
            if ($spann->hasAttribute('class') && $spann->getAttributeNode('class')->value == "atwho-inserted") {
                $user_id = $spann->getAttributeNode('data-userid')->value;
                $newTag = $dom->createElement('span', $spann->nodeValue);
                $newTag->setAttribute("class","mention-user");
                $newTag->setAttribute("data-userid",$user_id);
                $newTag->setAttribute("contenteditable",'false');
                $newTag->setAttribute("href","#");
                $spann->parentNode->replaceChild($newTag, $spann);
            }
            else {
                continue;
            }
        }
        $body = "";
        foreach($dom->getElementsByTagName("body")->item(0)->childNodes as $child) {
            $body .= $dom->saveHTML($child);
        }
        $content = strip_tags($body, '<b><i><a><br><span>');
    }
    else{
        $content = '';
    }
    $content = utf8_decode($content);
    $data['content'] = $content;
    $data['user_id'] = $user_id;
    return $data;
}

function version_format($number){
    return implode(".", str_split($number, 1));
}

// Laravel helpers

function lang_path($dir = "")
{
    return resource_path('lang/'.$dir);
}

function parseBladeDirectiveArgs($expression)
{
    return collect(explode(',', $expression))->map(function ($item) {
        return trim($item,' "');
    });

}
function onToBool($on)
{
    return ($on == 'on');
}

function validate_project_template_code($code)
{
    $json = json_decode($code);
    if(!json_last_error()===JSON_ERROR_NONE)
    {
        return false;
    }
    if( !property_exists($json, 'title') || !property_exists($json, 'privacy') ){
        return false;
    }

    return true;

}

function is_valid_image_type($ext)
{
    $ext = strtolower($ext);
    $allowed_images = ['png','gif','jpg','jpeg','bmp','WBMP','TIFF','TARGA','webp']; // Supported by GD
    if(in_array($ext,$allowed_images))
    {
        return true;
    }
    else{
        return false;
    }
}

function is_assoc(array $array)
{
    $keys = array_keys($array);
    return array_keys($keys) !== $keys;
}

/**
 * Translates a number to a short alhanumeric version
 *
 * this function is based on any2dec && dec2any by
 * fragmer[at]mail[dot]ru
 * see: http://nl3.php.net/manual/en/function.base-convert.php#52450
 *
 *
 * @author   Kevin van Zonneveld <kevin@vanzonneveld.net>
 * @author   Simon Franz
 * @author   Deadfish
 * @copyright 2008 Kevin van Zonneveld (http://kevin.vanzonneveld.net)
 * @license   http://www.opensource.org/licenses/bsd-license.php New BSD Licence
 * @version   SVN: Release: $Id: alphaID.inc.php 344 2009-06-10 17:43:59Z kevin $
 * @link   http://kevin.vanzonneveld.net/
 */

function alphaID($in, $to_num = false, $pad_up = false, $passKey = null)
{
    $index = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if ($passKey !== null) {
        // Although this function's purpose is to just make the
        // ID short - and not so much secure,
        // with this patch by Simon Franz (http://blog.snaky.org/)
        // you can optionally supply a password to make it harder
        // to calculate the corresponding numeric ID

        for ($n = 0; $n<strlen($index); $n++) {
            $i[] = substr( $index,$n ,1);
        }

        $passhash = hash('sha256',$passKey);
        $passhash = (strlen($passhash) < strlen($index))
            ? hash('sha512',$passKey)
            : $passhash;

        for ($n=0; $n < strlen($index); $n++) {
            $p[] =  substr($passhash, $n ,1);
        }

        array_multisort($p,  SORT_DESC, $i);
        $index = implode($i);
    }

    $base  = strlen($index);

    if ($to_num) {
        // Digital number  <<--  alphabet letter code
        $in  = strrev($in);
        $out = 0;
        $len = strlen($in) - 1;
        for ($t = 0; $t <= $len; $t++) {
            $bcpow = bcpow($base, $len - $t);
            $out   = $out + strpos($index, substr($in, $t, 1)) * $bcpow;
        }

        if (is_numeric($pad_up)) {
            $pad_up--;
            if ($pad_up > 0) {
                $out -= pow($base, $pad_up);
            }
        }
        $out = sprintf('%F', $out);
        $out = substr($out, 0, strpos($out, '.'));
    } else {
        // Digital number  -->>  alphabet letter code
        if (is_numeric($pad_up)) {
            $pad_up--;
            if ($pad_up > 0) {
                $in += pow($base, $pad_up);
            }
        }

        $out = "";
        for ($t = floor(log($in, $base)); $t >= 0; $t--) {
            $bcp = bcpow($base, $t);
            $a   = floor($in / $bcp) % $base;
            $out = $out . substr($index, $a, 1);
            $in  = $in - ($a * $bcp);
        }
        $out = strrev($out); // reverse
    }

    return $out;
}

function fa_file($extension)
{
    $extension = strtolower($extension);
    switch($extension)
    {
        case "png":
        case "jpg":
        case "jpeg":
        case "gif":
        case "bmp":
        case "tif":
        case "tiff":
        case "jif":
        case "jfif":
        case "epd":
        case "svg":
        case "psd":
        case "ai":
        case "mac":
        case "img":
            return "file-image-o";
            break;
        case "a":
        case "ar":
        case "cpio":
        case "shar":
        case "lbr":
        case "iso":
        case "mar":
        case "tar":
        case "gz":
        case "bz2":
        case "lz":
        case "7z":
        case "ace":
        case "rar":
        case "zip":
        case "apk":
        case "dmg":
        case "jar":
        case "zz":
            return "file-archive-o";
            break;
        case "mp3":
        case "wav":
        case "oga":
        case "aac":
        case "wma":
        case "rm":
        case "ram":
        case "ra":
        case "mid":
        case "ogg":
        case "mp2":
        case "wv":
        case "ac3":
            return "file-sound-o";
            break;
        case "php":
        case "php5":
        case "js":
        case "css":
        case "sass":
        case "coffe":
        case "xml":
        case "exe":
        case "asp":
        case "aspx":
            return "file-code-o";
            break;
        case "pdf":
            return "file-code-o";
            break;
        case "xls":
        case "xlsx":
        case "xlt":
        case "xltx":
        case "numbers":
        case "csv":
        case "xlc":
            return "file-excel-o";
            break;
        case "pptx":
        case "ppt":
        case "pot":
        case "pps":
        case "ppsx":
        case "pptm":
            return "file-powerpoint-o";
            break;
        case "txt":
        case "md":
            return "file-text-o";
            break;
        default:
            return "file-o";
    }
}