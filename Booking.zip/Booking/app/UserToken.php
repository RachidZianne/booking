<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserToken extends Model
{
    protected $casts = [
        'id' => 'integer',
    ];
}
