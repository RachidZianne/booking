<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\TaskCommentAttachmentLocation
 *
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property int $task_comment_attachment_id
 * @property string|null $name
 * @property string $long
 * @property string $lat
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereLat($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereLong($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereTaskCommentAttachmentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskCommentAttachmentLocation whereUpdatedAt($value)
 */
class TaskCommentAttachmentLocation extends Model
{
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'task_comment_attachment_id' => 'integer',
    ];

}
