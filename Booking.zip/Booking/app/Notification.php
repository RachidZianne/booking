<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Notification
 *
 * @mixin \Eloquent
 */

class Notification extends Model
{
    protected $fillable = ['read'];
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
        'model_id' => 'integer',
        'related_user' => 'integer',
        'read' => 'integer',
    ];

    public function related_user()
    {
        return $this->belongsTo('App\User','related_user');
    }

   public function related()
    {
        return $this->related_user()->select(['id','name']);
    }

}
