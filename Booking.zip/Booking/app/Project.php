<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

/**
 * App\Project
 *
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\TaskSection[] $tasksections
 * @mixin \Eloquent
 * @property int $id
 * @property \Carbon\Carbon|null $created_at
 * @property \Carbon\Carbon|null $updated_at
 * @property int $user_id
 * @property string $title
 * @property string $layout
 * @property string $privacy
 * @property string|null $start_date
 * @property string|null $end_date
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereEndDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereLayout($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project wherePrivacy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereStartDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Project whereUserId($value)
 */
class Project extends Model
{
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'user_id' => 'integer',
    ];

    // @TODO uncomment when implemented
    protected $hidden = array('layout', 'start_date','end_date');


    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function tasksections()
    {
        return $this->hasMany('App\TaskSection');
    }

    // @TODO improve relationships to less complex

    public function sharedusers()
    {
        return $this->hasMany('App\ProjectUser');
    }

    public function shareduserwithme()
    {
        return $this->hasMany('App\ProjectUser')->where("user_id","=",Auth::id());
    }

    public function sharedteams()
    {
        return $this->hasMany('App\ProjectTeam');
    }

    public function sharedteamswithme()
    {
        return $this->hasMany('App\ProjectTeam');
    }

    public function scopeVisible($query,$teams)
    {
        $query =  $query->where(function($q){
            $q->where("privacy",'=',"me")->where("user_id","=",Auth::id());
        })->orWhereHas("shareduserwithme")->orWhereHas("sharedteamswithme",function($query)use($teams){
                $query->whereIn("team_id",$teams);
        });
        if(Auth::user()->isStaff()){
            $query = $query->orWhere("privacy",'=','public');
        }
        return $query;
    }

    public function tasks()
    {
        return $this->hasManyThrough('App\Task','App\TaskSection');
    }

    public function scopeNotpersonal($query)
    {
        return $query->where("privacy",'<>','me');
    }

    public function scopeActive($query)
    {
            return $query->where("archived",0);
    }

    public function scopeArchived($query,$value=false)
    {
        if($value){
            return $query;
        }
        else{
            return $query->where("archived",0);
        }
    }

    public function templateify($export_assigned,$export_done_status)
    {

        $project = $this;
        $project = array_only($project->toArray(),['title','privacy','tasksections','sharedusers','sharedteams']);

        array_walk($project['tasksections'],function(&$v,$k)use($export_assigned,$export_done_status){
            $v = array_only($v,['title','tasks']);
            array_walk($v['tasks'],function(&$r,$j)use($export_assigned,$export_done_status){
                $filtered_tasks = ['user_id','title'];
                if($export_assigned){
                    $filtered_tasks[] = "assigned_to";
                }
                if($export_done_status){
                    $filtered_tasks[] = "done";
                }
                $r = array_only($r,$filtered_tasks);
            });
        });
        $project['sharedusers'] = array_pluck( $project['sharedusers'],"user_id");
        $project['sharedteams'] = array_pluck( $project['sharedteams'],"team_id");
        return json_encode($project,JSON_PRETTY_PRINT);
    }

}
