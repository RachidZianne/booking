<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * App\TaskTag
 *
 * @property-read \App\Tag $tag
 * @mixin \Eloquent
 * @property int $id
 * @property int $task_id
 * @property int $tag_id
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskTag whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskTag whereTagId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\TaskTag whereTaskId($value)
 */
class TaskTag extends Model
{
    public $timestamps  = false;
    // Fix for users without no MYSQLND - JSON CAST ISSUE
    protected $casts = [
        'id' => 'integer',
        'task_id' => 'integer',
        'tag_id' => 'integer',
    ];

    public function tag()
    {
        return $this->belongsTo('App\Tag');
    }

    public static function mostUsed()
    {
        $mostused = TaskTag::with("tag")->select(DB::raw('count(*) as count'),'tag_id')->groupBy("tag_id")->orderBy("count","desc")->get();
        return $mostused;
    }
}
