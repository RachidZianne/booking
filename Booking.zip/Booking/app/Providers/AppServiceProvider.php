<?php

namespace App\Providers;

use App;
use App\Team;
use App\User;
use App\UserPreference;
use Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);


        Blade::directive('iseqsel', function ($variables) {
            $variables = parseBladeDirectiveArgs($variables);
            return "<?php 
            if( isset({$variables[0]}) && {$variables[0]} == '{$variables[1]}' ) echo 'selected';          
             ?>";
        });

        if (!App::runningInConsole() && Config::get("metis.installed") == 1) {

            $users = User::staff()->select("id", "name")->get();
            View::share('public_users', $users);
            $teams = Team::select("id", "title")->get();
            View::share('public_teams', $teams);

        }
        if (!App::runningInConsole() && (Config::get("metis.installed") == 1) && !\Auth::guest()) {
            $lang =  UserPreference::getPref("language");
            if(!empty($lang))
            {
                App::setLocale($lang);
            }
        }

    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
