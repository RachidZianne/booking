<?php

namespace App\Providers;

use App\Notification;
use App\User;
use Auth;
use Illuminate\Support\Facades\Event;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Log;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        'Illuminate\Auth\Events\Login' => [
            'App\Listeners\LogSuccessfulLogin',
        ],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        // New task mention , normal notification
        Event::listen('seen', function ($payload) {
            $user = Auth::user();
            $user->last_login = \Carbon::now();
            $user->save();
        });

        // New task mention , normal notification
        Event::listen('task.mention', function ($payload) {
            $notification = new Notification;
            $notification->related_user = $payload['related_user'];
            $notification->user_id = $payload['user_id'];
            $notification->action = 'notifications.new_comment_mention';
            $notification->route = 'notifications.task_comment';
            $notification->model_id = $payload['model_id'];
            $notification->save();
        });

        // New task assigned notification
        Event::listen('task.assigned', function ($payload) {
            if (empty($payload['assigned'])){ return true; }
            if(Auth::id() == $payload['assigned'] ) { return true; }

            $notification = new Notification;
            $notification->user_id = $payload['assigned'];
            $notification->action = 'notifications.new_task_assigned';
            $notification->route = 'notifications.task_view';
            $notification->model_id = $payload['model_id'];
            $notification->save();
        });

        // New Comment on task notification
        Event::listen('task.comment', function ($payload) {
            $notification = new Notification;
            $notification->related_user = $payload['related_user'];
            $notification->user_id = $payload['user_id'];
            $notification->action = 'notifications.new_comment_task';
            $notification->route = 'notifications.task_comment';
            $notification->model_id = $payload['model_id'];
            $notification->save();
        });

        // Mails


        // New task mention , email notification
        Event::listen('task.mention', function ($payload) {
            $beautymail = $beautymail = app()->make(\Snowfire\Beautymail\Beautymail::class);
            if (empty($payload['user_id'])){ return true; }

            $user = User::find($payload['user_id']);
            $email = $user->email;
            $name = $user->name;
            $model = $payload['model_id'];
            try{
                $beautymail->send('emails.task_mention', ['name' => $name,'model' => $model], function($message) use($email,$name)
                 {
                $message->to($email, $name)->subject(trans('emails.someone_mentioned_you'));
                 });
            }
            Catch(\Exception $e)
            {
                Log::error($e->getMessage());
            }

        });

        // New task assigned , email notification
        Event::listen('task.assigned', function ($payload) {
            $beautymail = $beautymail = app()->make(\Snowfire\Beautymail\Beautymail::class);
            if (empty($payload['assigned'])){ return true; }
            if(Auth::id() == $payload['assigned'] ) { return true; }

            $user = User::find($payload['assigned']);
            $email = $user->email;
            $name = $user->name;
            $model = $payload['model_id'];
            try{
                $beautymail->send('emails.task_assign', ['name' => $name,'model' => $model], function($message) use($email,$name)
            {
                $message->to($email, $name)->subject(trans("emails.someone_assigned_you"));
            });
            }Catch(\Exception $e)
            {
                Log::error($e->getMessage());
            }


        });

    }
}
