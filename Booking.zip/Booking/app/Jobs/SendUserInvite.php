<?php

namespace App\Jobs;

use App\Settings;
use App\User;
use App\UserInvite;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Log;

class SendUserInvite implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $user;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    public function __construct(User $user)
    {
       $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $invite = new UserInvite;
        $invite->user_id = $this->user->id;
        $invite->token = str_random(64);
        $invite->type = 'normal';   // @FUTURE more types of invitation; e.g project/team/..
        $invite->save();

        $beautymail = $beautymail = app()->make(\Snowfire\Beautymail\Beautymail::class);
        try{
            $beautymail->send('emails.user_invite', ['user' => $this->user,'invite' => $invite], function($message)
            {
                $site_name = Settings::gets("site_name");
                $message->to($this->user->email)->subject(trans('emails.you_were_invited_to') .$site_name);
            });
        }Catch(\Exception $e)
        {
            Log::error($e->getMessage());
        }
    }
}
