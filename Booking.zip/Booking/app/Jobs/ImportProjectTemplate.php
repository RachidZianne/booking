<?php

namespace App\Jobs;

use App\Project;
use App\ProjectTeam;
use App\ProjectUser;
use App\Task;
use App\TaskSection;
use Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Log;

class ImportProjectTemplate implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $project;
    protected $code;
    protected $freshProject;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Project $project,$code,$freshProject=true)
    {
        $this->project = $project;
        $this->code = $code;
        $this->freshProject = $freshProject;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        try{
            $project = $this->project;
            $code = $this->code;

            if(!empty($code->sharedusers)){
                $list = $code->sharedusers;
            }
            elseif(!empty($code->sharedteams))
            {
                $list = $code->sharedteams;
            }
            else{
                $list = [];
            }
            if( (!empty($list)) && $this->freshProject){
                if($code->privacy == 'teams')
                {
                    foreach($list as $tlist){
                        $projectTeam = new ProjectTeam;
                        $projectTeam->project_id = $project->id;
                        $projectTeam->team_id = $tlist;
                        $projectTeam->save();
                    }
                }
                elseif($code->privacy == 'users')
                {
                    foreach($list as $tlist){
                        $projectTeam = new ProjectUser;
                        $projectTeam->project_id = $project->id;
                        $projectTeam->user_id = $tlist;
                        $projectTeam->save();
                    }
                }
            }
            // Sections and tasks

            // Sections
            $sections = $code->tasksections;

            if(!empty($sections)){

                foreach ($sections as $section)
                {
                    $new_section = new TaskSection;
                    $new_section->title = $section->title;
                    $new_section->project_id = $project->id;
                    $new_section->save();
                    if(!empty($section->tasks))
                    {

                        foreach($section->tasks as $task)
                        {
                            if(is_array($task)){
                                $task = json_encode($task);
                            }
                            $new_task = new Task;
                            $new_task->title = $task->title;
                            $new_task->user_id = $task->user_id;
                            if(property_exists($task,"done"))
                            {
                                $new_task->done = $task->done;
                            }
                            if(property_exists($task,"assigned_to"))
                            {
                                $new_task->assigned_to = $task->assigned_to;
                            }
                            $new_task->done_at = Carbon::now();
                            $new_task->task_section_id = $new_section->id;
                            $new_task->save();
                        }
                    }
                }
            }
        }
        catch (\Exception $e)
        {
            Log::error($e);
        }
    }
}
