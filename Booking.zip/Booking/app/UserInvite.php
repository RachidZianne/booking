<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserInvite extends Model
{
    protected $casts = [
        'id' => 'integer',
    ];
}
