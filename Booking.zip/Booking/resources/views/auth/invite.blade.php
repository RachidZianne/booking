@extends('layouts.simple')

@section('content')
    <div class="page-middle">

        <div class="col-md-6">
            <div class="card-group mb-0">
                <div class="card p-4">
                    <h3>{{ trans('messages.complete_account_info') }}</h3>
                    <form class="form-horizontal" role="form" method="POST" action="{{ route('invite.new',$token) }}">
                        {{ csrf_field() }}
                        <div class="card-block">
                        <p class="text-muted">{{ trans('messages.complete_account_info') }}</p>
                        <div class="input-box">
                            <input type="name" class="form-control" placeholder="{{ trans('common.name') }}" name="name" required autofocus>
                        </div>
                        <div class="input-box">
                            <input type="password" class="form-control" placeholder="{{ trans('common.new_password') }}" name="password" required>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-centered btn-primary px-4">{{ trans('common.continue') }}</button>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
