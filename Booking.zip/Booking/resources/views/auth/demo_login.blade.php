<div class="alert alert-warning demo-msg">
    <span>for <strong>Full Access</strong> demo user, use the following credentials:</span> <br> <br>
    <span><strong>Email:</strong> john@gometis.com</span> <br>
    <span><strong>Password:</strong> 123456 </span>
    <br>
    <br>
    <a href="#" id="morec" onclick="showclient()"><span class="text-primary">Other user types..</span></a> <br><br>
    <div id="client_hidden" class="hide">
        for <strong>Staff</strong>,use the following credentials : <br> <br>
        <span><strong>Email:</strong> dustin@gometis.com</span> <br>
        <span><strong>Password:</strong> 123456 </span> <br>
        To test a <strong>Client</strong> view , you can use the following credentials : <br> <br>
        <span><strong>Email:</strong> gibson@gometis.com</span> <br>
        <span><strong>Password:</strong> 123456 </span> <br>
        <hr>
    </div>
</div>
<div class="card">
    <form class="form-horizontal" role="form" method="POST" action="{{ route('login') }}">
        {{ csrf_field() }}
        <h1>Login</h1>
        <p class="text-muted">Sign In to your account</p>
        <div class="input-box">
            <input type="email" placeholder="Email Address" name="email" required  value="john@gometis.com">
        </div>
        <div class="input-box">
            <a class="smallbox" href="{{route("password.request")}}">
                Forgot?
            </a>
            <div class="input-inner-box">
                <input type="password" placeholder="Password" name="password" value="123456">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-centered">Login</button>
        <a type="button" href="{{route("password.request")}}" class="btn btn-secondary sm-mobile-only">Forgot?</a>
    </form>
</div>
<script type="text/javascript">
    function showclient(){
        var more = document.getElementById("morec");
        var client = document.getElementById("client_hidden");
        client.classList.remove('hide');
        more.parentNode.removeChild(more);
    }
</script>