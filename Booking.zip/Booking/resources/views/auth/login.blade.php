@extends('layouts.simple')

@section('content')

    <div class="page-middle">
            @if ($errors->has('email'))
                <div class="alert alert-danger">
                                        {{ $errors->first('email') }}
                </div>
            @endif
            @if ($errors->has('password'))
                    <div class="alert alert-danger">
                                        {{ $errors->first('password') }}
                    </div>
            @endif
                @if(Config::get("metis.demo") != 1)
                    <div class="card">
                        <form class="form-horizontal" role="form" method="POST" action="{{ route('login') }}">
                            {{ csrf_field() }}
                            <h1>{{ trans('common.login') }}</h1>
                            <p class="text-muted">{{ trans('messages.sign_in_account') }}</p>
                            <div class="input-box">
                                <input type="email" placeholder="{{ trans('common.email_address') }}" name="email" required autofocus >
                            </div>
                            <div class="input-box">
                                <a class="smallbox" href="{{route("password.request")}}" tabindex="-1">
                                    {{ trans('common.forgot') }}
                                </a>
                                <div class="input-inner-box">
                                    <input type="password" placeholder="{{ trans('common.password') }}" name="password" >
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-centered">{{ trans('common.login') }}</button>
                            <a type="button" href="{{route("password.request")}}" class="btn btn-secondary sm-mobile-only">{{ trans('common.forgot') }}</a>
                        </form>
                        {{--<div class="divider mt20 mb20">OR</div>--}}
                    </div>
                @else
                    @include("auth.demo_login")
                @endif



    </div>
@endsection
