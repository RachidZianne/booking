@extends('layouts.simple')

@section('content')

    <div class="page-middle">

            @if ($errors->has('email'))
                <div class="alert alert-danger">
                    {{ $errors->first('email') }}
                </div>
            @endif
            @if ($errors->has('password'))
                <div class="alert alert-danger">
                    {{ $errors->first('password') }}
                </div>
            @endif
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif
                <div class="card p-4">
                    <form class="form-horizontal" role="form" method="POST" action="{{ route('password.email') }}">
                        {{ csrf_field() }}
                        <div class="card-block">
                            <h1>{{ trans('common.reset_password') }}</h1>
                            <p class="text-muted">{{ trans('common.request_password_reset') }}</p>
                            <div class="input-box">
                                <input type="email" class="form-control" placeholder="{{ trans('common.email_address') }}" name="email"  value="{{ old('email') }}" required autofocus>
                            </div>
                            <button type="submit" class="btn btn-primary">{{ trans('common.request_password_reset') }}</button>
                        </div>
                    </form>
                </div>
</div>

@endsection
