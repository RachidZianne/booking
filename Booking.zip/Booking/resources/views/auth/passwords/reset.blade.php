@extends('layouts.simple')

@section('content')


    <div class="page-middle">
            @if ($errors->has('email'))
                <div class="alert alert-danger">
                    {{ $errors->first('email') }}
                </div>
            @endif
            @if ($errors->has('password'))
                <div class="alert alert-danger">
                    {{ $errors->first('password') }}
                </div>
            @endif
            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif
                <div class="card">
                    <form class="form-horizontal" role="form" method="POST" action="{{ route("password.change") }}">
                        {{ csrf_field() }}
                            <h1>{{ trans('common.reset_password') }}</h1>
                            <p class="text-muted">{{ trans('common.new_password') }}</p>

                            <div class="input-box">
                                <input id="email" type="email" class="form-control" placeholder="{{ trans('common.email_address') }}" name="email" value="{{ $email or old('email') }}" required autofocus>
                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <div class="input-box">
                                    <input id="password" type="password" class="form-control" placeholder="{{ trans('common.new_password') }}" name="password" required>
                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                                <div class="input-box">
                                    <input id="password-confirm" type="password" class="form-control" placeholder="{{ trans('common.password_confirm') }}" name="password_confirmation" required>
                                    @if ($errors->has('password_confirmation'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                                    <input type="hidden" name="token" value="{{ $token }}">
                                    <button type="submit" class="btn btn-primary">{{ trans('common.change_password') }}</button>
                    </form>
                </div>
            </div>

@endsection
