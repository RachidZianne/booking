@extends("master")
@section("breadcrumb")
    @include("menus.users")
@endsection
@section('content')
    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-users"></i> {{ trans('common.clients') }}
                </div>
                <div class="card-block">
                    <table class="table table-striped table-responsive">
                        <thead>
                        <tr>
                            <th>{{ trans('common.id') }}</th>
                            <th colspan="2">{{ trans('common.user') }}</th>
                            <th>{{ trans('common.email') }}</th>
                            <th>{{ trans('common.action') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $user)
                             <tr>
                                <td>{{ $user->id }}</td>
                                 <td class="">
                                     <div class="avatar">
                                         <img src="{{route('avatar',$user)}}" class="img-avatar" >
                                         @if(($user->last_login))
                                          @if($user->last_login->diffInMinutes() <= 5)
                                              <span class="avatar-status badge-success"></span>
                                          @elseif($user->last_login->diffInMinutes() <= 15)
                                              <span class="avatar-status badge-info"></span>
                                          @else
                                              <span class="avatar-status badge-danger"></span>
                                          @endif
                                          @else
                                             <span class="avatar-status badge-default"></span>
                                         @endif
                                     </div>
                                 </td>
                                 <td>
                                     <div> {{ $user->name }}
                                         @if($user->type == 'root')
                                             <span class="badge badge-danger">{{ trans('common.administrator') }}</span>
                                         @endif
                                     </div>
                                     <div class="small text-muted">
                                         Last login:
                                             @if(!empty($user->last_login))
                                                 {{ $user->last_login->diffForHumans() }}
                                             @else
                                                 Never
                                             @endif
                                     </div>
                                 </td>
                                <td>{{$user->email}}</td>
                                <td>
                                    <a  class="btn btn-sm btn-secondary" href="{{route("user.edit",$user)}}"><i class="fa fa-edit"></i> {{ trans('common.edit') }} </a>
                                    <form method="POST" action="{{ route("user.delete") }}" class="inline-form">
                                        <input type="hidden" name="model_id" value="{{$user->id}}"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> {{ trans('common.delete') }} </a>
                                        {{ csrf_field() }}
                                    </form>
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                    {{ $users->links() }}
                </div>
            </div>
        </div>

    </div>
@endsection