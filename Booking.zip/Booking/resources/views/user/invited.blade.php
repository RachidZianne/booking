@extends("master")
@section("breadcrumb")
    @include("menus.users")
@endsection
@section('content')
    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-users"></i> {{ trans('common.invited') }}
                </div>
                <div class="card-block">
                    <table class="table table-striped table-responsive">
                        <thead>
                        <tr>
                            <th>{{ trans('common.id') }}</th>
                            <th>{{ trans('common.since') }}</th>
                            <th>{{ trans('common.email') }}</th>
                            <th class="text-align-right">{{ trans('common.action') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $user)
                             <tr>
                                <td>{{ $user->id }}</td>
                                <td> {{ $user->created_at->diffForHumans()  }} </td>
                                 <td>
                                     {{ $user->email }}
                                 </td>
                                <td class="text-align-right">
                                    <form method="POST" action="{{route('user.resend_invite')}}" class="inline-form">
                                        <input type="hidden" name="model_id" value="{{$user->id}}"/>
                                        <a class="btn btn-sm btn-secondary confirm-submit" href="#"><i class="icon-reload"></i> {{ trans('common.resend_invite') }} </a>
                                        {{ csrf_field() }}
                                    </form>
                                    <a  class="btn btn-sm btn-secondary" href="{{route('user.edit',$user)}}"><i class="fa fa-edit"></i> {{ trans('common.edit') }} </a>
                                    <form method="POST" action="{{ route('user.delete') }}" class="inline-form">
                                        <input type="hidden" name="model_id" value="{{$user->id}}"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> {{ trans('common.delete') }} </a>
                                        {{ csrf_field() }}
                                    </form>
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                    {{ $users->links() }}
                </div>
            </div>
        </div>

    </div>
@endsection