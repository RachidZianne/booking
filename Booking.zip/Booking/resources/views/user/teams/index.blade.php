@extends("master")
@section("breadcrumb")
    @include("menus.users")
@endsection
@section('content')

    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-users"></i> {{ trans('common.teams') }}
                </div>
                <div class="card-block">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>{{ trans('common.id') }}</th>
                            <th colspan="2">{{ trans('common.team') }}</th>
                            <th>{{ trans('common.action') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach($teams as $team)
                             <tr>
                                <td width="80">{{ $team->id }}</td>
                                 <td colspan="2">
                                     {{$team->title}}
                                 </td>
                                <td width="200">
                                    <a  class="btn btn-sm btn-secondary" href="{{route("user.team.edit",$team)}}"><i class="fa fa-edit"></i> {{ trans('common.edit') }} </a>
                                    <form method="POST" action="{{ route("user.team.delete") }}" class="inline-form">
                                        <input type="hidden" name="model_id" value="{{$team->id}}"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> {{ trans('common.delete') }} </a>
                                        {{ csrf_field() }}
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{ $teams->links() }}
                </div>
            </div>
        </div>

    </div>
@endsection