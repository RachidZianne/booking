@extends("master")
@section("breadcrumb")
    @include("menus.users")
@endsection
@section('content')
    <form method="POST" enctype="multipart/form-data" action="{{route("user.team.store")}}">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> {{$team->title or trans("common.team") }}
                    </div>
                    <div class="card-block">
                        <div class="card-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.title') }}</label>
                                        <input type="text" class="form-control" name="title" placeholder="{{ trans('common.title') }}" value="{{$team->title or ''}}">
                                    </div>
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            @if($team)
                                <input type="hidden" name="team_id" value="{{$team->id}}" />
                            @endif
                            <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        {{ csrf_field() }}
    </form>
@endsection



