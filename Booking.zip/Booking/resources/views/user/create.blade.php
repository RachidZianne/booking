@extends("master")
@section("breadcrumb")
    @include("menus.users")
@endsection
@section('content')
        <div class="row">

            <div class="col-lg-6 col-md-6">
                <form method="POST" enctype="multipart/form-data" action="{{route("user.store")}}">

                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> {{$user->name or 'User'}}
                    </div>
                    <div class="card-block">
                        <div class="card-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.name') }}</label>
                                        <input type="text" class="form-control" name="name" placeholder="{{ trans('common.name') }}" value="{{$user->name or ''}}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.email') }}</label>
                                        <input type="email" class="form-control" name="email" placeholder="{{ trans('common.email_address') }}"  value="{{$user->email or ''}}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.new_password') }}</label>
                                        <input type="text" class="form-control" name="password" placeholder="{{ trans('common.new_password') }}" autocomplete="off">
                                        <span class="help-block text-muted text-smaller">{{ trans('common.field_visible') }}</span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.avatar') }}</label>
                                        <div class="row">
                                            <div class="col-md-3 col-lg-2">
                                              <img src="{{route('avatar',$user)}}" class="avatar avatar-lg">
                                            </div>
                                            <div class="col-md-9 col-lg-8">
                                            <input type="file" class="form-control col-md-9" name="avatar">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!--/.row-->
                            <div class="row">
                                <div class="col-md-12">
                                    <hr class="divider" />
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-sm-12">

                                    <div class="form-group">
                                        <label>{{ trans('common.user_type') }}</label>
                                        <select class="form-control" name="user_type" id="usertype">
                                            <option value="staff" @iseqsel($user->type,"staff")>{{ trans('common.staff') }}</option>
                                            <option value="client" @iseqsel($user->type,"client")>{{ trans('common.client') }}</option>
                                            <option value="root" @iseqsel($user->type,"root")>{{ trans('common.administrator') }}</option>
                                        </select>
                                    </div>
                                    <div id="utteams">
                                        <div class="form-group">
                                            <label>{{ trans('common.teams') }}</label>
                                            <input type="text" class="form-control" id="user_teams" name="teams" value="@if(isset($user->teams)){{$user->teams->pluck('id')->implode(',')}}@endif">
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <!--/.row-->


                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            @if($user)
                                <input type="hidden" name="user_id" value="{{$user->id}}" />
                            @endif
                            <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                        </div>
                    </div>
                </div>
                    {{ csrf_field() }}
                </form>

            </div>
            @if(!isset($user))
                <div class="col-lg-6 col-md-6">
                    <form method="POST" enctype="multipart/form-data" action="{{route('user.send_invite')}}">

                        <div class="card">
                            <div class="card-header">
                                <i class="fa fa-user-plus"></i> {{ trans('common.invite_user') }}
                            </div>
                            <div class="card-block">
                                <div class="card-block">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="name">{{ trans('common.email') }}</label>
                                                <input type="email" class="form-control" name="email" placeholder="{{ trans('common.email_address') }}"  value="">
                                                <p class="help-text">{{ trans('messages.pref_page_client_type') }} </p>
                                            </div>
                                        </div>
                                    </div>

                                    <!--/.row-->
                                </div>
                                <div class="form-actions">
                                    <button type="submit" class="btn btn-success">{{ trans('common.send_invite') }}</button>
                                </div>
                            </div>
                        </div>
                        {{ csrf_field() }}
                    </form>

                </div>
            @endif
        </div>
@endsection

@section("extra_js")
    <script type="text/javascript">
        var teams = {!! $teams->toJson() !!};

        $("#user_teams").selectize({
            plugins: ['remove_button'],
            delimiter: ',',
            persist: false,
            valueField: 'id',
            labelField: 'title',
            options:teams,
            create:false
        });
        $("#user_type").selectize();

        $(document).on("change","#usertype",function(e)
        {
            var type = $(this).val();
            if(type == 'staff')
            {
                $("#utteams").removeClass('hide');
            }
            else{
                $("#utteams").addClass('hide');
            }
        });

        $("#usertype").trigger("change");

    </script>
@append

