<!DOCTYPE html>
<html lang="en" @if((Cookie::get("nightmode") == 'on')) class="nightmode" @endif>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{Settings::gets("site_name")}}</title>
    @include("misc.common_css")
    @include("misc.common_js")
    @yield("extra_css")
    @includeWhen((Config::get("metis.demo") == 1),"fragments.demo_frag")
</head>

<body class="firecamp metis-custom app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden @yield("extra_body_class") @if(Settings::gets("fullscreen_mode") == 1) full-screen-aside @endif">
    <header class="app-header navbar">
        <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button"><i class="icon-menu"></i></button>
        <a class="navbar-brand" href="{{ route("overview") }}">
            <div class="fc-logo">
                <img src="{{route("logo")}}">
            </div>
        </a>
        <ul class="nav navbar-nav d-md-down-none" id="navbar_teams">
            <li class="nav-item">
                <a class="nav-link navbar-toggler sidebar-toggler" href="#"><i class="icon-menu"></i></a>
            </li>
            <li class="nav-item px-3">
                <a class="nav-link" href="{{route("overview")}}">{{trans("common.overview")}}</a>
            </li>
            @foreach(Auth::user()->getTeams() as $team)
            <li class="nav-item px-3">
                <a class="nav-link" href="{{route("team",$team->id)}}">{{$team->title}}</a>
            </li>
            @endforeach
        </ul>
        <ul class="nav navbar-nav ml-auto nav-user-action">
            <li class="nav-item desktop-only">
                <a class="nav-link nightmode-icon nightmode-toggle" href="#"><i class="fa fa-moon-o"></i></a>
            </li>
            <li class="nav-item dropdown notifications-nav">
                <a class="nav-link nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-globe fa-2x"></i><span class="badge badge-pill badge-danger notifications-count"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header text-center">
                        <strong>{{trans('common.notifications')}}</strong>
                    </div>
                    <div class="notification-items"></div>
                </div>
            </li>
            <li class="nav-item dropdown name-nav">
                <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <span class="d-md-down-none">{{Auth::user()->name}}</span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header text-center">
                        <strong>{{ trans('common.account') }}</strong>
                    </div>

                    <a class="dropdown-item" href="{{ route("profile") }}"><i class="fa fa-user"></i> {{ trans('common.profile') }}</a>
                    @if(Auth::user()->isStaff())
                    <a class="dropdown-item" href="{{ route("profile.templates") }}"><i class="fa fa-folder"></i> {{ trans('common.profile') }}</a>
                    @endif
                    <a class="dropdown-item mobile-only nightmode-toggle" href="#"><i class="fa fa-moon-o"></i>{{ trans('common.night_mode') }}</a>

                @if(Auth::user()->isAdmin())
                    <div class="dropdown-header text-center">
                        <strong>{{ trans('common.administrator') }}</strong>
                    </div>
                    <a class="dropdown-item" href="{{route("admin.insight.teams")}}"><i class="fa fa-bar-chart"></i> {{ trans('common.insights') }}</a>
                    <a class="dropdown-item" href="{{route("user.index")}}"><i class="fa fa-users"></i> {{ trans('common.users_and_teams') }}</a>
                    <a class="dropdown-item" href="{{ route("admin.history") }}"><i class="fa fa-file"></i> {{ trans('common.history') }}</a>
                    <a class="dropdown-item" href="{{ route("admin.general") }}"><i class="fa fa-cog"></i> {{ trans('common.metis_settings') }}</a>
                    <div class="divider"></div>
                    @endif
                    <a class="dropdown-item" href="{{route("logout")}}"><i class="fa fa-lock"></i> {{ trans('common.logout') }}</a>
                </div>
            </li>
            <li class="nav-item d-md-down-none">
            </li>
        </ul>
    </header>

    <div class="app-body">
        <div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
                    <li class="nav-title">
                        {{ trans('common.dashboard') }}
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{route("overview")}}"><i class="icon-home"></i> {{ trans('common.home') }}</a>
                    </li>
                    @if(Auth::user()->isStaff())
                    <li class="nav-item">
                        <a class="nav-link" href="{{route("selfassigned")}}"><i class="icon-notebook"></i> {{ trans('common.assigned_to_me') }}</a>
                    </li>
                    @endif
                    <li class="nav-item">
                        <a class="nav-link" href="{{route("calendar")}}"><i class="icon-calendar"></i> {{ trans('common.calendar') }}</a>
                    </li>
                    <li class="nav-title mobile-only-team">
                    {{ trans('common.teams') }}
                    </li>
                    @foreach(Auth::user()->getTeams() as $team)
                        <li class="nav-item mobile-only-team">
                            <a class="nav-link" href="{{route("team",$team->id)}}">{{$team->title}}</a>
                        </li>
                    @endforeach

                    <li class="nav-title">
                        @if(isset($view_type))
                            @if($view_type == 'team')
                            {{ trans('common.team_projects') }}
                            @elseif($view_type == 'project' || $view_type == 'overview')
                            {{ trans('common.recent_projects') }}
                            @else
                                {{ trans('common.recent_projects') }}
                            @endif
                        @else
                            {{ trans('common.recent_projects') }}
                        @endif
                            @if(Auth::user()->isStaff())
                                <a href="#" class="create-project"><i class="fa fa-plus-circle"></i></a>
                            @endif
                       </li>
                    @if(isset($projects) && !empty($projects))
                        @foreach($projects as $project)
                            @if($project != null)
                            <li class="nav-item project">
                                <a class="nav-link" href="{{route("project",$project->id)}}"><i class="icon-direction"></i> {{$project->title}}</a>
                            </li>
                            @endif
                        @endforeach
                    @endif

                </ul>
            </nav>
        </div>
        <!-- Main content -->
        <main class="main">
            <div class="container-fluid @if(Settings::gets("tweaks_stack") == 1) stack-view @endif {{$layout_type or ''}}@yield("view_type") @yield("extra_container_class")">
                <!-- Breadcrumb -->
                @yield("breadcrumb")
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif
                @if (session('error'))
                    <div class="alert alert-danger">
                        <div class="alert-heading">{{ trans('common.error') }}</div>
                        {{ session('error') }}
                    </div>
                @endif
                @yield("content")
            </div>
            <!-- /.conainer-fluid -->
        </main>
       @include('layouts.aside')

    </div>

    @yield("footer")
    @include('fragments.templates')
    @include('fragments.aside_templates')

</body>
<script type="text/javascript">
    var public_users = {!! $public_users->toJson() !!};
    var most_used_tags = {!!  App\TaskTag::mostUsed()->pluck('tag.title')->toJson()  !!};
    var public_teams = {!! $public_teams->toJson() !!};
    var is_user_admin = {{ (Auth::user()->isAdmin()) }};
</script>
<script type="text/javascript">
function airdatepicker_language(){
    @if(is_locale_supported("airpicker",App::getLocale()))
    var lang = "{{ App::getLocale() }}";
    @else
    var lang = "en";
    @endif
    return lang;
}

</script>

@yield("extra_js")
</html>