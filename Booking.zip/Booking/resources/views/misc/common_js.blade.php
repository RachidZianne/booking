<!-- Bootstrap and necessary plugins -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/mustache.js/2.3.0/mustache.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.polyfill.io/v2/polyfill.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.16.2/axios.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Plugins and scripts required by all views -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Sortable/1.6.0/Sortable.min.js"></script>
<script src="{{ asset("assets/js/jquery.fn.sortable.js") }}"></script>
<script src="{{ asset("assets/js/plugins.js") }}?ver={{Settings::gets("version")}}"></script>
<script src="{{ asset("assets/js/jquery.atwho.js") }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/i18n/datepicker.en.min.js"></script>
@if(is_locale_supported("airpicker",App::getLocale()))
    <script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/i18n/datepicker.{{App::getLocale()}}.min.js"></script>
@endif
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.4/js/standalone/selectize.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.1.1/min/dropzone.min.js"></script>
@if(Settings::gets("location_enabled")  == 1)
<script type="text/javascript" src='https://maps.google.com/maps/api/js?libraries=places&key={{Settings::gets("location_js_api")}}'></script>
<script src="{{ asset("assets/js/locationpicker.jquery.min.js") }}"></script>
@endif
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.1/moment.min.js"></script>
@if(is_locale_supported("momentjs",App::getLocale()))
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.1/locale/{{App::getLocale()}}.js"></script>
    <script type="text/javascript">moment.locale('{{App::getLocale()}}')</script>
@endif
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script src="{{ asset("js/laroute.js") }}"></script>
<script src="{{ asset("js/messages.js") }}"></script>
<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    laroute.set_root_url('{{url('/')}}');
    Lang.setLocale('{{App::getLocale()}}');
</script>
<script src="{{ asset("assets/js/app.js") }}"></script>
<script src="{{ asset("assets/js/firecamp.js") }}?ver={{Settings::gets("version")}}"></script>

{{--<!-- Plugins and scripts required by this views -->--}}

{{--<!-- Custom scripts required by this view -->--}}
{{--<script src="{{ asset("assets/js/views/main.js") }}"></script>--}}
