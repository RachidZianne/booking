@extends("master")
@section("breadcrumb")
    @include("menus.tasks")
@endsection
@section("content")
        <div id="calendar-container">
            <div id="tasks-calendar" class="tasks-calendar"></div>
        </div>
@endsection

@section("extra_js")
    @include("fragments.aside_js")
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.6.1/fullcalendar.min.js"></script>
    @if(is_locale_supported("fullcalendar",App::getLocale()))
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.6.1/locale/{{App::getLocale()}}.js"></script>
    @endif
    <script type="text/javascript">
        var archive = {{$with_archive}};
        $(document).ready(function() {

            // page is now ready, initialize the calendar...

            $('#tasks-calendar').fullCalendar({
                events: function(start, end, timezone, callback) {
                    axios({
                        method:'post',
                        url:'{{ route('tasks.loadtasks') }}',
                        data:{
                            start: start,
                            end:end,
                            with_archive: archive
                        }
                    }).then(function(response) {
                        var events = [];
                        var tasks = response.data.data;
                        tasks.forEach(function(element) {
                            if(element.due_date != null){
                                events.push({
                                    id: element.id,
                                    title: element.title,
                                    start: element.due_date,
                                    done: element.done
                                });
                            }
                        });
                        callback(events);
                    });
                },
                height:'parent',
                aspectRatio: 2,
                nowIndicator:false,
                contentHeight:'auto',
                displayEventTime : false,
                firstDay:{{Settings::gets("start_day")}},
                    header:{
                    left:   'month basicWeek listMonth',
                    center: 'title',
                    right:  'today prev,next'
                },

                eventRender: function(event, element , view) {
                    var checkbox = $('<span class="task-checkbox readonly"></span>');
                    if(event.done)
                        $(checkbox).addClass('done');


                    if(view.name == "listMonth"){
                        $(element).find(".fc-list-item-marker.fc-widget-content").html(checkbox);
                        $(element).attr("data-taskid",event.id);
                    }
                    else{
                    $(element).find(".fc-content").prepend(checkbox);
                    $(element).attr("data-taskid",event.id);
                    }
                }

            });

            // task event click

            $(document).on("click",".fc-event[data-taskid],.fc-list-item",function(e){
                var taskid = $(this).attr("data-taskid");
                loadTask(taskid);
            });

        });

    </script>
@append
@section("extra_css")
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.6.1/fullcalendar.min.css" />
    <link href="{{ asset("assets/css/firecamp_calendar.css") }}" rel="stylesheet">
@append