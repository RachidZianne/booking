<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{Settings::gets("site_name")}}</title>
    <link href="{{ asset("assets/css/simple-line-icons.css") }}" rel="stylesheet">
    <link href="{{ asset("assets/css/metis_login.css") }}" rel="stylesheet">
    <link href="{{ asset("custom.css") }}" rel="stylesheet">
    @includeWhen((Config::get("metis.demo") == 1),"fragments.demo_frag")
</head>

<body class="simple metis-custom metis-login">
<div class="container">
    @if (session('error'))
        <div class="alert alert-danger">
            <div class="alert-heading">{{ trans('common.error') }}</div>
            {{ session('error') }}
        </div>
    @endif
    @yield("content")
</div>
<!-- Bootstrap and necessary plugins -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>