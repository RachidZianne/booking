<aside class="aside aside-menu aside-main-task">
    <div class="task-parent" data-taskid="0">
        <div class="task-head">
            <a class="close-button"><i class="icon icon-arrow-right"></i></a>
            <div class="action-buttons">
                <input type="search" class="form-control hide aside-search" placeholder="{{ trans('common.search') }}"/>
                <button class="fc-btn fc-btn-m fc-white search-task-button"><i class="icon-magnifier"></i></button>
                <button class="fc-btn fc-btn-m fc-white add-subtask-button"><i class="fa fa-tasks"></i></button>
                <button class="fc-btn fc-btn-m fc-white copy-task-button"><i class="icon-link"></i></button>
                <button class="fc-btn fc-btn-m fc-white refresh-task-button"><i class="icon-refresh"></i></button>
                <button class="fc-btn fc-btn-m fc-white snooze-task-button"><i class="fa fa-bell-slash-o"></i></button>
                <button class="fc-btn fc-btn-m fc-white edit-task-button"><i class="icon-pencil"></i></button>
            </div>
        </div>
        <div class="task-details">
            <div class="task-checkbox-container">
                <span class="task-checkbox"></span>
            </div>
            <div class="task-title">
                <div class="head"><div class="tags"></div></div>
            </div>
        </div>
        <div class="detailed">
            <div class="task-details-more">
                <a href=""></a> – <a href=""></a>
            </div>
            <div class="task-details-assign">
                <a href=""></a> | <a href=""></a>
            </div>
            <div class="task-tags">
            </div>
            <div class="subtasks-toggle"><span class="toggleclass">{{ trans('common.show_subtasks') }}</span><span class="count"></span></div>
        </div>
        <div class="subtask-box hide"></div>
        <div class="comments-section">
            <ul class="comments-list">
            </ul>
        </div>
        <div class="task-comment-box">
            <div class="avatar-box">
                <img class="comment-avatar-img" src="{{route("avatar",Auth::id())}}" />
            </div>
            <div class="add-comment">
                <div contenteditable="true" class="add-comment-textarea" id="commenttextarea" spellcheck="true">
                </div>
                <ul id="comment-attachment-bar" class="dropzone-previews"></ul>
                <div class="comment-box-actions">
                    <ul class="comment-actions">
                        <li class="commentaction-mention">
                            <i class="fa fa-at"></i> {{ trans('common.mention') }}
                        </li>
                        @if(Settings::gets("location_enabled")  == 1)
                        <li class="commentaction-location">
                            <i class="icon-map"></i> {{ trans('common.location') }}
                        </li>
                        @endif
                        <li class="commentaction-vcard">
                            <i class="fa fa-address-card-o" data-toggle="popover" data-placement="top" data-content=""></i> {{ trans('common.vcard') }}
                        </li>
                        <li class="attach-button">
                            <i class="icon-paper-clip"></i> {{ trans('common.file') }}
                        </li>
                    </ul>
                </div>
            </div>
            <div class="sidecomment-box">
                <button type="button" class="fc-btn fc-btn-m float-right" id="post-comment-btn">{{ trans('common.post') }}</button>
                <span class="sendonenter">
                    <label for="sendonentercheckbox">{{ trans('common.send_on_enter') }}</label>
                    <input type="checkbox" class="checkbox" id="sendonentercheckbox" @if((Cookie::get("sendonenter") == 'on')) checked="checked" @endif>
                </span>
            </div>
            <input type="hidden" id="pm-vc-name">
            <input type="hidden" id="pm-vc-number">
            <input type="hidden" id="pm-vc-email">
            <textarea class="hide"  id="pm-vc-address"></textarea>
        </div>
    </div>
</aside>