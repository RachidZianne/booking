@extends('beautymail::templates.ark')

@section('content')

    @include('beautymail::templates.ark.heading', [
		'heading' => 'New mention!',
		'level' => 'h1'
	])

    @include('beautymail::templates.ark.contentStart')

    <h4 class="secondary"><strong>{{$name}},</strong></h4>
    <p>{{trans("emails.someone_mentioned_you")}}</p>

    @include('beautymail::templates.ark.contentEnd')

    @include('beautymail::templates.sunny.contentStart')

    @include('beautymail::templates.minty.button', ['text' => trans('emails.checkout_comment'), 'link' => route("notifications.task_comment",$model)])

    @include('beautymail::templates.ark.contentEnd')


@stop
