@extends('beautymail::templates.ark')

@section('content')

    @include('beautymail::templates.ark.heading', [
		'heading' => 'New Task Assigned!',
		'level' => 'h1'
	])

    @include('beautymail::templates.ark.contentStart')

    <h4 class="secondary"><strong>{{$name}},</strong></h4>
    <p>{{trans("emails.someone_assigned_you")}}</p>

    @include('beautymail::templates.ark.contentEnd')

    @include('beautymail::templates.sunny.contentStart')

    @include('beautymail::templates.minty.button', ['text' => trans("emails.checkout_task"), 'link' => route("notifications.task_view",$model)])

    @include('beautymail::templates.ark.contentEnd')


@stop
