@extends('beautymail::templates.ark')

@section('content')

    @include('beautymail::templates.ark.heading', [
		'heading' => 'Invitation!',
		'level' => 'h1'
	])

    @include('beautymail::templates.ark.contentStart')

    <p>{{ trans("emails.you_were_invited_to",['name' => Settings::gets("site_name")]) }}</p>

    @include('beautymail::templates.ark.contentEnd')

    @include('beautymail::templates.sunny.contentStart')

    @include('beautymail::templates.minty.button', ['text' => trans('common.continue'), 'link' => route("invite.new",$invite->token)])

    @include('beautymail::templates.ark.contentEnd')


@stop
