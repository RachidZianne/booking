@extends("master")
@section("breadcrumb")
    @include("menus.project_templates")
@endsection
@section('content')
    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-folder"></i> {{ trans('common.project_templates') }}
                </div>
                <div class="card-block">
                    <table class="table table-striped table-responsive">
                        <thead>
                        <tr>
                            <th colspan="2">{{ trans('common.template') }}</th>
                            <th class="text-align-right">{{ trans('common.action') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach($templates as $template)
                             <tr class="template">
                                 <td colspan="2">
                                     <div class="template-title"> {{ $template->title }}</div>
                                     <div class="small text-muted">
                                         {{ trans('common.saved') }} {{ $template->created_at->diffForHumans() }}
                                     </div>
                                 </td>
                                <td class="text-align-right">
                                    <a class="btn btn-sm btn-secondary template-rename" href="#" data-templateid="{{$template->id}}"><i class="icon-note"></i> {{ trans('common.rename') }} </a>
                                    <a class="btn btn-sm btn-secondary" href="{{route("profile.template_download",$template)}}"><i class="fa fa-download"></i> {{ trans('common.download') }} </a>
                                    <form method="POST" action="{{ route("profile.template_delete") }}" class="inline-form">
                                        <input type="hidden" name="model_id" value="{{$template->id}}"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> {{ trans('common.delete') }} </a>
                                        {{ csrf_field() }}
                                    </form>
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                    {{ $templates->links() }}
                </div>
            </div>
        </div>
    </div>


    <div id="project_template_import" class="hide">
        <div class="popover-body popover-tpl">
            <form action="{{ route("profile.template_import") }}" method="POST" enctype="multipart/form-data">
              <h6>{{ trans('common.import_project_template') }}</h6>
                <label class="strong-label">{{ trans('common.project_templates') }}</label>
                <input type="file" name="file" class="form-control" accept=".json" />
                <div class="row">
                    <div class="col-md-12 mt-3 text-align-right">
                        <button type="submit" class="btn btn-primary">{{ trans('common.import') }}</button>
                    </div>
                </div>
                {{ csrf_field() }}
            </form>
        </div>
    </div>
@endsection

@section("extra_js")
    <script type="text/javascript">
        $(function(){
            $("[data-toggle=popover]").popover({
                html : true,
                content: function() {
                    var content = $(this).attr("data-popover-content");
                    return $(content).html();
                }
            });
        });

        $(document).on("click",".template-rename",function(e){
            var template = $(this).parents(".template");
            var tpl_id = $(this).attr("data-templateid");
            var tpl_title = $(template).find(".template-title").text();

            swal({
                    title: "{{ trans("common.rename") }}",
                    text: tpl_title,
                    type: "input",
                    showCancelButton: true,
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true,
                    inputPlaceholder: "{{trans("common.template_title")}}"
                },
                function(inputValue){
                    if (inputValue === false) return false;
                    if (inputValue === "") {
                        swal.showInputError("{{trans("common.you_need_to_write_something")}}");
                        return false
                    }
                    axios({
                        method:'post',
                        url:'{{ route('profile.template_rename') }}',
                        data:{
                            title: inputValue,
                            model_id: tpl_id
                        }
                    }).then(function(response) {
                        $(template).find(".template-title").text(inputValue);
                        swal("{{ trans("common.completed") }}", Lang.get("messages.title_renamed",{title:tpl_title, newtitle:inputValue}), "success");
                    });
                });

        });
    </script>

@append