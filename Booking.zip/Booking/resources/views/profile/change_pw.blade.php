@extends("master")
@section("breadcrumb")
    @include("menus.profile")
@endsection
@section('content')
    <form method="POST" enctype="multipart/form-data" action="{{route("profile_savepw")}}">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> {{ trans('common.change_password') }}
                    </div>
                    <div class="card-block">
                        <div class="card-block">

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.current_password') }}</label>
                                        <input type="text" class="form-control" name="password" placeholder="{{ trans('common.current_password') }}" value="" autocomplete="off">
                                        <p class="text-muted pt-2"><i class="fa fa-eye"></i> {{ trans('common.field_visible') }} </p>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.new_password') }}</label>
                                        <input type="text" class="form-control" name="passwordnew" placeholder="{{ trans('common.new_password') }}" value="" autocomplete="off">
                                        <p class="text-muted pt-2"><i class="fa fa-eye"></i> {{ trans('common.field_visible') }} </p>
                                    </div>
                                </div>
                            </div>



                            <!--/.row-->


                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        {{ csrf_field() }}
    </form>
@endsection

