@extends("master")
@section("breadcrumb")
    @include("menus.profile")
@endsection
@section('content')
    <form method="POST" enctype="multipart/form-data" action="{{route("profile_save")}}">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> {{ trans('common.profile') }}
                    </div>
                    <div class="card-block">
                        <div class="card-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.name') }}</label>
                                        <input type="text" class="form-control" name="name" placeholder="{{ trans('common.name') }}" value="{{ Auth::user()->name }}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.email') }}</label>
                                        <input type="email" class="form-control" name="email" placeholder="{{ trans('common.email_address') }}"  value="{{ Auth::user()->email }}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.language') }}</label>
                                        <select name="language" class="form-control">
                                                <option value="0">Default</option>
                                                @foreach($languages as $language)
                                                <option value="{{ $language->code }}" @if($language->code == $language_selected) selected @endif>{{ $language->language }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">{{ trans('common.avatar') }}</label>
                                        <div class="row">
                                            <div class="col-md-3 col-lg-2">
                                              <img src="{{route('avatar',Auth::id())}}" class="avatar avatar-lg">
                                            </div>
                                            <div class="col-md-9 col-lg-8">
                                            <input type="file" class="form-control col-md-9" name="avatar">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--/.row-->


                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        {{ csrf_field() }}
    </form>
@endsection

