<ol class="breadcrumb responsive-menu">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> {{ trans('common.menu') }} </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="{{route("admin.general")}}"><i class="fa fa-cog"></i> {{ trans('common.site_settings') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.preferences")}}"><i class="icon-cup"></i> {{ trans('common.preferences') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.languages.index")}}"><i class="fa fa-language"></i> {{ trans('common.languages') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.themes")}}"><i class="fa fa-paint-brush"></i> {{ trans('common.themes') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.map")}}"><i class="fa fa-street-view"></i> {{ trans('common.location_sharing') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.mail")}}"><i class="fa fa-envelope-o"></i> {{ trans('common.mail_configuration') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.tweaks")}}"><i class="icon-equalizer"></i> {{ trans('common.tweaks') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.api")}}"><i class="fa fa-cloud"></i> {{ trans('common.api') }} </a>
            <a class="btn btn-secondary" href="{{route("admin.info")}}"><i class="fa fa-question-circle"></i> {{ trans('common.software_info') }} </a>
        </div>
    </li>
</ol>