<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> {{ trans('common.menu') }} </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            @if(Request::has('archive') && Request::input('archive') == 1)
            <a class="btn btn-secondary" href="{{ Request::fullUrlWithQuery(['archive' => 0]) }}"><i class="icon-arrow-up"></i> &nbsp;{{ trans('common.all_tasks') }}</a>
            @else
                <a class="btn btn-secondary" href="{{ Request::fullUrlWithQuery(['archive' => 1]) }}"><i class="icon-arrow-down"></i> &nbsp;{{ trans('common.active_tasks') }}</a>
            @endif
            {{--<a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>--}}
            @yield("extra_menu_buttons")
        </div>
    </li>
    @if($view_type == 'project')
        <li class="breadcrumb-menu right-side mobile project-navigation">
            <a class="btn btn-secondary btn-open" href="#"><i class="icon-list"></i> {{ trans('common.section') }} </a>
            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                <a class="btn btn-secondary @if(isset($subcat_active) && $subcat_active == 'board') active @endif" href="{{route("project",$project)}}">{{ trans('common.board') }}</a>
                <a class="btn btn-secondary @if(isset($subcat_active) && $subcat_active == 'files') active @endif" href="{{route("projects.files",$project)}}">{{ trans('common.files') }}</a>
                <a class="btn btn-secondary @if(isset($subcat_active) && $subcat_active == 'about') active @endif" href="{{route("projects.about",$project)}}">{{ trans('common.about') }}</a>

            </div>
        </li>
    @endif

</ol>