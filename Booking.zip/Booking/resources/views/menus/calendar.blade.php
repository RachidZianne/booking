<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> {{ trans('common.menu') }} </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            @if(Request::has('archive') && Request::input('archive') == 1)
            <a class="btn btn-secondary" href="{{ Request::fullUrlWithQuery(['archive' => 0]) }}"><i class="icon-arrow-right"></i> &nbsp;{{ trans('common.all_tasks') }}</a>
            @else
            <a class="btn btn-secondary" href="{{ Request::fullUrlWithQuery(['archive' => 1]) }}"><i class="icon-arrow-left"></i> &nbsp;{{ trans('common.active_tasks') }}</a>
            @endif
        </div>
    </li>
</ol>