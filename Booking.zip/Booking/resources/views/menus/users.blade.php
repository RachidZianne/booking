<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> {{ trans('common.menu') }} </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="{{route("user.index")}}"><i class="fa fa-users"></i> {{ trans('common.users') }}</a>
            <a class="btn btn-secondary" href="{{route("user.new")}}"><i class="fa fa-user-plus"></i> {{ trans('common.new_user') }}</a>
            <a class="btn btn-secondary" href="{{route("user.team.index")}}"><i class="fa fa-user-circle"></i> {{ trans('common.teams') }}</a>
            <a class="btn btn-secondary" href="{{route("user.team.new")}}"><i class="fa fa-user-circle-o"></i> {{ trans('common.new_team') }}</a>
            <a class="btn btn-secondary" href="{{route("user.clients")}}"><i class="icon-people"></i> {{ trans('common.clients') }}</a>
            <a class="btn btn-secondary" href="{{route("user.invited")}}"><i class="icon-envelope-letter"></i> {{ trans('common.invited') }}</a>
        </div>
    </li>
</ol>