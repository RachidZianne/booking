<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> {{ trans('common.menu') }} </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary dropdown-toggle project-export" href="#" data-popover-content="#project_template_import" data-toggle="popover" data-placement="bottom"><i class="fa fa-level-down"></i> &nbsp; {{ trans('common.import') }}</a>
        </div>
    </li>
</ol>