<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> {{ trans('common.menu') }} </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="{{route("profile")}}"><i class="fa fa-user"></i> {{ trans('common.profile') }}</a>
            <a class="btn btn-secondary" href="{{route("profile_changepw")}}"><i class="fa fa-lock"></i> {{ trans('common.change_password') }}</a>
        </div>
    </li>
</ol>