@extends("install.master")

@section("content")
<h3>Welcome to installation</h3>
<h4>Follow the easy steps below to complete your installation</h4>


<table class="ui celled table">
    <thead>
    <tr>
        <th>Name</th>
        <th>Test</th>
        <th>Status</th>
        <th>Notes</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>PHP Version</td>
        <td>{{PHP_VERSION}}</td>
        @if (version_compare(PHP_VERSION, '5.6.4') >= 0)
            <td class="positive">Approved</td>
            <td>-</td>
        @else
            <td class="negative">Not Approved</td>
            <td>PHP Version must be 5.6.4 or newer</td>
        @endif
    </tr>
    <tr>
        <td>PDO MySQL</td>
        <td>PDO</td>
        @if (class_exists('PDO'))
            <td class="positive">Approved</td>
            <td>-</td>
        @else
            <td class="negative">Not Approved</td>
            <td>PDO MySQL Is not installed</td>
        @endif
    </tr>
    <tr>
        <td>OpenSSL </td>
        <td>{{  defined('OPENSSL_VERSION_TEXT')? OPENSSL_VERSION_TEXT : "-"   }}</td>
        @if (extension_loaded('openssl'))
            @if(OPENSSL_VERSION_NUMBER < 0x1000009f)
                <td class="warning">Warning</td>
                <td class="warning">OpenSSL Must be of version v1.0.1 or greater to support TLS 1.2 <strong>required by PayPal</strong> </td>
            @else
                <td class="positive">Approved</td>
                <td>-</td>
            @endif
        @else
            <td class="negative">Not Approved</td>
            <td>You need to install OpenSSL extension</td>
        @endif
    </tr>
    <tr>
        <td>Mbstring </td>
        <td>Mbstring</td>
        @if (extension_loaded('mbstring'))
            <td class="positive">Approved</td>
            <td>-</td>
        @else
            <td class="negative">Not Approved</td>
            <td>You need to install PHP mbstring extension</td>
        @endif
    </tr>
    <tr>
        <td>Tokenizer </td>
        <td>Tokenizer</td>
        @if (extension_loaded('tokenizer'))
            <td class="positive">Approved</td>
            <td>-</td>
        @else
            <td class="negative">Not Approved</td>
            <td>You need to install PHP tokenizer extension</td>
        @endif
    </tr>
    <tr>
        <td>Writeable Folders</td>
        <td>
            <div class="ui list">
                <div class="item">
                    <?php $writeableflag = true; ?>
                    @if(is_writable(config_path()))
                        <i class="green fa fa-check"></i>
                    @else
                        <?php $writeableflag = false; ?>
                        <i class="red remove circle icon"></i>
                    @endif
                    <div class="content popup" data-content="{{config_path()}}">
                        Config
                    </div>
                </div>
                <div class="item">
                    @if(is_writable(storage_path("/")))
                        <i class="green fa fa-check"></i>
                    @else
                        <?php $writeableflag = false; ?>
                        <i class="red remove circle icon"></i>
                    @endif
                    <div class="content popup" data-content="{{storage_path("/")}}">
                        Storage
                    </div>
                </div>

            </div>
        </td>
        @if ($writeableflag)
            <td class="positive">Approved</td>
            <td>-</td>
        @else
            <td class="negative">Not Approved</td>
            <td>Change permissions to 755 or 77 on unwriteable folder</td>
        @endif
    </tr>

    <tr>
        <td>Public Folder</td>
        <td>-</td>
        @if ( (stripos(Request::server("REQUEST_URI"),"public")) === false)
            <td class="positive">Approved</td>
            <td>-</td>
        @else
            <td class="negative">Visible</td>
            <td>Public Folder should be a DocumentRoot. <a href="http://www.firecrown.io/s/public">Why?</a> </td>
        @endif
    </tr>

    </tbody>
</table>

<form method="get" action="{{route("inst1")}}">
    <button class="btn btn-success button" type="submit">
        Start
    </button>
</form>

@endsection

@section("extrajs")
    <script type="text/javascript">
        $( document ).ready(function() {




        });

    </script>
@append