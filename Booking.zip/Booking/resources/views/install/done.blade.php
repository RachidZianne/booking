@extends("install.master")

@section("content")
<h3>That's it!</h3>

<h4>You can find your Application at the following link</h4>
<a class="btn btn-primary" href="{{route("home")}}">{{route("overview")}}</a>


@endsection

@section("extrajs")

@append