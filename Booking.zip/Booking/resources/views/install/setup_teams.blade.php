@extends("install.master")


@section("content")
    <form class="cform form-horizontal" method="POST" action="{{ route("inst3Save") }}">
        <div class="row">
            <div class="col-sm-12">
                <h3>Setting you up</h3>
                <h4>Choose teams that will use the application</h4>
                <h4 class="text-muted">( Don't worry, you can add more later )</h4>
            </div>
        </div>

      <div class="mt1">

          <div class="checkbox">
              <label style="font-size: 2em">
                  <input type="checkbox" name="teamlist[]" value="Accounting">
                  <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                  Accounting
              </label>
          </div>
          <div class="checkbox">
              <label style="font-size: 2em">
                  <input type="checkbox" name="teamlist[]" value="HR">
                  <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                  HR
              </label>
          </div>
          <div class="checkbox">
              <label style="font-size: 2em">
                  <input type="checkbox" name="teamlist[]" value="Marketing">
                  <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                  Marketing
              </label>
          </div>
          <div class="checkbox">
              <label style="font-size: 2em">
                  <input type="checkbox" name="teamlist[]" value="IT">
                  <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                  IT
              </label>
          </div>
          <div class="checkbox">
              <label style="font-size: 2em">
                  <input type="checkbox" name="teamlist[]" value="Operations">
                  <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                  Operations
              </label>
          </div>
          <div class="checkbox">
              <label style="font-size: 2em">
                  <input type="checkbox" name="teamlist[]" value="Sales">
                  <span class="cr"><i class="cr-icon fa fa-check"></i></span>
                  Sales
              </label>
          </div>

      </div>
        <div class="mt3">
        <a class="btn btn-info" href="{{route('inst4')}}">Skip</a>
        <button class="btn btn-success" type="submit">Continue</button>
        </div>
    </form>
@endsection