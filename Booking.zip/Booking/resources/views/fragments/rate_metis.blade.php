<div class="row rate-metis">
    <div class="col-md-8 col-lg-8">
        <div class="card">
            <a href="https://codecanyon.net/downloads">
                <div class="card-block p-0 clearfix">
                    <span class="bg-warning p-4 font-2xl mr-3 float-left">
                        <span class="heart"><i class="icon-heart"></i></span>
                    </span>
                    <div class="h5 text-warning mb-0 pt-3">Please take few seconds to rate our product</div>
                    <div class="text-rate">Help support the development of this product</div>
                </div>
            </a>

        </div>
    </div>
</div>

