<script type="text/javascript">
    var dropzone;

    // Popover for sub-task actions
    var popoverSubTaskSettings = {
        animation:false,
        html:true,
        delay:50,
        placement:"auto left",
        template: '<div class="popover subtaskactions" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content popover-task"></div></div>',
        content: function(r){
            var action = $(this).attr("data-action");
            var html = '';
            if(action === 'user'){
                html = $("#task-action-user").html();
            }
            else if (action === 'calendar')
            {
                html = $("#task-action-calendar").html();
            }
            var $html = $('<div />',{html:html});
            $html.find('.action').val(action);
            return $html.html();

        }
    };
    var _bsPopover = null;

    function apply_popoversubtask()
    {
        // Popover for sub task options
        $('.subtask-actionable').popover(popoverSubTaskSettings).on('show.bs.popover', function() {
                if($(".subtask .popover").length > 0){
                    $(".subtask .popover").popover('hide');
                }
        }).on('hide.bs.popover', function() {

        });

    }

    function convertSubTaskDueDate() {
        $(".aside-main-task .subtask-box .subtask-duedate:not(.converted)").each(function() {
            var ddate =  $( this ).text();
            if(ddate != ''){
                var mdate = moment(ddate,"YYYY/MM/DD HH:mm:ss");
                if(mdate.isValid()){
                    var ddy = mdate.format("D MMM");
                    $(this).text(ddy).addClass('converted');
                }
            }
        });
    }

    function addTaskComments(comments)
    {
        var max_id = Math.max.apply(Math,comments.map(function(o){return o.id;}));
        if(!isFinite(max_id)){
            max_id = 0;
        }
        $(".aside-main-task .task-parent").attr("data-cursor",max_id);
        html = $("#template-aside-comments").html().replace('&gt;', ">");
        partial_like = $("#template-aside-comment-like").html();
        Mustache.parse(html);
        rendered = Mustache.render(html, {
            comments: comments,
            is_user_admin: is_user_admin
        },{
            partial_like: partial_like
        });
        $(".aside-main-task .comments-list .comment.pending").remove();
        $(".aside-main-task .comments-list").removeClass('spinner-big-center').append(rendered);
        $('.aside-main-task .comments-list .time').each(function() {
            var cre = $(this).attr('data-created');
            var now =  moment(cre).fromNow();
            $(this).html(now);
        });
        rescroll_comment_list();
        loadPreviewImages();
    }

    function loadTask(taskid,callback) {
        var result = checkTaskCommentDiscard();
        if(!result){ return false; }
        resetTaskCommentBox();
        closeTaskSearch();
        $('body').removeClass('aside-menu-hidden');
        $('body').trigger('aside:open');
        $(".task-item.open").removeClass('open');

        $(".aside-main-task .task-details .task-title .head").html('');
        $(".aside-main-task .detailed .task-details-more").html('');
        $(".aside-main-task .subtask-box").html('');
        $(".aside-main-task .subtasks-toggle .count").html('');
        $(".aside-main-task .task-details-assign").html('');
        $(".aside-main-task .snooze-task-button").removeAttr('data-snooze');
        $("#post-comment-btn").addClass('disabled');
        $(".aside-main-task .comments-list").html('').addClass('spinner-big-center');
        $(".aside-main-task .task-checkbox").removeClass('done').addClass('loading');
        $(".task-item[data-taskid="+taskid+"]").addClass('open');

        // Load comments & task info
        axios({
            method:'post',
            url:'{{ route('tasks.commentload') }}',
            data:{
                task_id: taskid
            }
        }).then(function(response) {
            if(response.data.status != 'ok')
            {
                // throw exception
            }
            $(".aside-main-task .task-parent").attr("data-taskid",taskid);

            var task = response.data.data;

            // Render title data

            var done = task.done;

            var snooze = task.snoozed_until;

            $(".aside-main-task .task-checkbox").removeClass('loading');
            if(done === 1)
            {
                $(".aside-main-task .task-checkbox").addClass('done');
            }

            if(!snooze)
            {
                $(".aside-main-task .snooze-task-button i").removeClass("fa-bell-o").addClass("fa-bell-slash-o")
                $(".aside-main-task .snooze-task-button").removeClass('snoozing');
            }
            else{
                $(".aside-main-task .snooze-task-button i").removeClass("fa-bell-slash-o").addClass("fa-bell-o")
                $(".aside-main-task .snooze-task-button").addClass('snoozing');
            }

            $(".aside-main-task .snooze-task-button").attr("data-snooze",snooze);


            var title = task.title;
            var taglist = task.tasktags.map(function(elem){
                return elem.tag.title;
            }).join(",");
            // Title
            html = $("#template-aside-title").html();
            Mustache.parse(html);
            rendered = Mustache.render(html, {
                title: title,
                tags:  task.tasktags,
                taglist: taglist
            });
            $(".aside-main-task .task-details .task-title .head").html(rendered);
            // ---

            // Render details data
            var section_title = task.task_section.title;
            var createdat = task.created_at;
            var dateago = moment(createdat).fromNow();

            html = $("#template-aside-details").html();
            Mustache.parse(html);
            rendered = Mustache.render(html, {
                sectionname: section_title,
                time:  dateago
            });
            $(".aside-main-task .detailed .task-details-more").html(rendered);
            // ---

            // Render details data
            var assigned = task.assigned_basic;
            var due_date_org = task.due_date;
            var due_date = due_date_org;
            if(due_date != null && due_date.length !== 0)
            {
                due_date = moment(due_date).fromNow();
            }

            html = $("#template-aside-assign").html();
            Mustache.parse(html);
            rendered = Mustache.render(html, {
                assigned: assigned,
                due:  due_date,
                due_org: due_date_org
            });
            hideSubtasks();
            $(".aside-main-task .detailed .task-details-assign").html(rendered);

            // ---- Sub-tasks
            if(task.subtasks.length > 0){

            html = $("#template-aside-subtasks").html().replace('&gt;', ">");
            partial_task_item = $("#template-subtask-item").html().replace('&gt;', ">");
            partial_avatar = $("#template-subtask-item-avatar").html().replace('&gt;', ">");
            Mustache.parse(html);
            rendered = Mustache.render(html, {
                subtasks: task.subtasks
            },{
                partial_task_item: partial_task_item,
                partial_avatar: partial_avatar
            });
            $(".aside-main-task .subtask-box").html(rendered);
                apply_popoversubtask();
                // duedates
                convertSubTaskDueDate();
                var curr_cookie = Cookies.get('subtask-'+taskid);
                if(curr_cookie == 'shown'){
                    showSubtasks();
                }else{
                    recountSubtasks();
                } // else already hidden
            }
            // ----

            // Render Comments
            var comments = task.comments;
            addTaskComments(comments);
            // ---

            $("#post-comment-btn").removeClass('disabled');
            @if(!Auth::user()->isStaff())
                $(".task-checkbox").addClass("readonly");
                $(".subtask-checkbox").addClass("readonly");
                $(".edit-task-button").remove()
                $(".add-subtask-button").remove()
            @endif

            if(typeof callback === "function"){
                callback();
            }
        }).catch(handleAxiosErrors);

    }

    function recountSubtasks()
    {
        var counted = $(".aside-main-task .subtasks .subtask").length;
        if(counted == 0){ counted = ''}
        $(".subtasks-toggle .count").html(counted);
    }

    function hideSubtasks() {
        if(!$(".subtask-box").hasClass('hide')) {
            toggleSubtasks();
        }
    }

    function showSubtasks() {
        if($(".subtask-box").hasClass('hide')) {
            toggleSubtasks();
        }
    }

    function toggleSubtasks()
    {
            var current_task = parseInt($(".aside-main-task .task-parent").attr("data-taskid"));



            if($(".subtask-box").hasClass('hide')) {
                $(".subtask-box").removeClass('hide');
                $(".subtasks-toggle .toggleclass").text('{{ trans('common.hide_subtasks') }}');
                $(".subtasks-toggle .count").html('');
                Cookies.set('subtask-'+current_task, 'shown',{ expires: 14 });
            }
            else{
                $(".subtask-box").addClass('hide');
                $(".subtasks-toggle .toggleclass").text('{{ trans('common.show_subtasks') }}');
                recountSubtasks();
                Cookies.set('subtask-'+current_task, 'hidden',{ expires: 14 });
            }
    }

    // Check if a comment is written
    function checkTaskCommentDiscard()
    {
        var content = $("#commenttextarea").html().trim();
        var content_text = $("#commenttextarea").text().trim(); // IE ..
        if(content_text != ''){
            return confirm('{{trans('messages.discard_confirm')}}');
        }
        else{
            return true;
        }
    }
    // Reset Textbox
    function resetTaskCommentBox()
    {
        $(".task-comment-box .add-comment").removeClass("error");
        var latitudeInput = $('#mp-lat').val('');
        var longitudeInput = $('#mp-long').val('');
        var locationNameInput = $('#mp-addr').val('');
        $(".commentaction-location").removeClass("active");
        $('#template-locationpick').modal('hide');
        var vcardName = $("#pm-vc-name").val('');
        var vcardEMail = $("#pm-vc-email").val('');
        var vcardNumber = $("#pm-vc-number").val('');
        var vcardAddr = $("#pm-vc-address").val('');
        $("#commenttextarea").html('');
        $("#comment-attachment-bar").html('');
        $(".commentaction-vcard").removeClass('active');
        $('.commentaction-vcard').popover('hide');
    }

    $(document).ready(function() {



        // Refresh task button
        $(document).on("click",".aside-main-task .refresh-task-button",function () {
            var taskid =  $(this).parents(".task-parent").attr('data-taskid');
            loadTask(taskid);
        });

        // Snooze button
        $(document).on("click",".snooze-task-button",function () {
            var snooze =  $(this).attr('data-snooze');
            var taskid =  $(this).parents(".task-parent").attr('data-taskid');

            if(snooze)
            {
                // unsnooze
                swal({
                        title: "{{trans('common.snooze_undo')}}",
                        text: snooze + " - {{trans('messages.snoozed_until_this_date')}}",
                        type: "info",
                        showCancelButton: true,
                        confirmButtonColor: "#2091c1",
                        confirmButtonText: "{{ trans('common.yes') }}",
                        cancelButtonText: "{{trans('common.cancel')}}",
                        closeOnConfirm: false,
                        closeOnCancel: false,
                        showLoaderOnConfirm:true
                    },
                    function(isConfirm){
                        if (isConfirm) {

                            axios({
                                method:'post',
                                url:'{{ route('tasks.unsnooze') }}',
                                data: {
                                    task_id: taskid
                                }
                            }).then(function(response) {
                                loadTask(taskid);
                                swal.close();
                            }).catch(handleAxiosErrors);

                        }
                        else{
                            swal.close();
                        }
                    });
            }
            else{
                var dateTomorrow = new Date;
                dateTomorrow.setDate(dateTomorrow.getDate() + 1)
                dateTomorrow.setHours(8);
                dateTomorrow.setMinutes(0);
                dateTomorrow.setMilliseconds(0);

                var dps = $("#snooze_task_modal .datepicker-snooze").datepicker({
                    startDate: dateTomorrow,
                    dateFormat:"yyyy-mm-dd",
                    timeFormat:"hh:ii",
                    minutesStep:5,
                    language:airdatepicker_language(),
                    onSelect: function onSelect(fd, date) {
                        $(".snooze-task .snoozedate").val(fd);
                    }
                });
                dps = $(dps).data("datepicker").selectDate(dateTomorrow);
                $("#snooze_task_modal").modal('show');
            }

        });
        // Snooze save

        $(document).on("click",".snooze-task .save",function () {
            $(this).addClass('disabled');
            var taskid = $(".aside-main-task .task-parent").attr("data-taskid");
            var selectedDate = $("#snooze_task_modal .snoozedate").val();
            $("#snooze_task_modal").modal('hide');

            axios({
                method:'post',
                url:'{{ route('tasks.snooze') }}',
                data:{
                    task_id: taskid,
                    date: selectedDate
                }
            }).then(function(response) {
                    loadTask(taskid);
            }).catch(function (error) {
                bootbox.alert("{{ trans('messages.error_connection') }}");
            });



        });

        // Creating new subtask
        $(document).on("click",".aside-main-task .createnewsubtask",function () {
            var SubTaskField = $(this).siblings('.addsubtask');
            var textValue = $(SubTaskField).val().trim();
            var button = $(".aside-main-task .createnewsubtask");

            if (textValue == '')
            {
                $(SubTaskField).addClass('error');
                return false;
            }
            else{
                $(SubTaskField).removeClass('error');
            }
            var taskid =  $(this).parents(".task-parent").attr('data-taskid');

            if($(".aside-main-task .subtasks").length == 0)
            {
                var template = $('#template-aside-subtasks').html();
                Mustache.parse(template);
                var rendered = Mustache.render(template, {
                    subtasks: []
                });
                $(".aside-main-task .subtask-box").prepend(rendered);
            }


            var template = $('#template-subtask-item').html();
            Mustache.parse(template);
            var rendered = Mustache.render(template, {
                id: 0,
                user_id: 0,
                done:0,
                title: textValue
            });

            var TheNewSubTask = $(rendered).appendTo(".aside-main-task .subtasks").addClass("spinner pending");
            $(button).prop('disabled', true).addClass("disabled");
            axios({
                method:'post',
                url:'{{ route('tasks.subtask.add') }}',
                data:{
                    title: textValue,
                    task_id: taskid
                }
            }).then(function(response) {
                var template = $('#template-subtask-item').html();
                Mustache.parse(template);
                var rendered = Mustache.render(template, {
                    id: response.data.id,
                    user_id: response.data.user_id,
                    done:0,
                    title: textValue
                });
                $(rendered).removeClass('spinner');
                $(TheNewSubTask).replaceWith(rendered);
                // Sync with main section
                if($(".sections-list .section .task-item-wrapper[data-taskid="+taskid+"]").hasClass('has-subtasks'))
                {
                    var template = $('#mainsection-subtask').html();
                    Mustache.parse(template);
                    var rendered = Mustache.render(template, {
                        id: response.data.id,
                        content: textValue
                    });
                    $(rendered).insertBefore($(".sections-list .section .task-item-wrapper[data-taskid="+taskid+"] .add-subtask-inline"));
                    reCountSubTasks(taskid);
                }
                // Remove
                $(SubTaskField).val('');
                $(SubTaskField).focus();
                $(button).prop('disabled', false).removeClass("disabled");
                apply_popoversubtask();


            }).catch(function (error) {
                $(TheNewSubTask).removeClass("pending spinner");
                $(TheNewSubTask).addClass("failed");
                $(button).prop('disabled', false).removeClass("disabled");
                bootbox.alert("{{ trans('messages.error_connection') }}");
            });

        });

        // Pressing ESC while writing new subtask
        $(document).on("keydown",".aside-main-task .addsubtask",function(e){
            if(e.which === 27){
               var child = $(this).parents(".subtask-add");
               if(child.length > 0){child.remove();}
            }
            if(e.which == 13){
                e.preventDefault();
                $(this).blur();
                $(".aside-main-task .createnewsubtask").trigger("click")
            }
        });

        $(document).on("click",".aside-main-task .subtasks-toggle",function(e){
            toggleSubtasks();
        });

        // Add subtask box
        $(document).on("click",".aside-main-task .add-subtask-button",function () {
                if($(".aside .subtask-add").length > 0)
                {
                    $(".aside .subtask-add .addsubtask").focus();
                    return false;
                }
                var html = $("#template-aside-subtask-add").html();


                showSubtasks();
                $(".subtask-box").append(html);
                $(".aside .subtask-add .addsubtask").focus();

        });

        // Remove subtask box
        $(document).on("focusout",".aside-main-task .addsubtask",function () {
            if($(this).val().trim() == ''){
                var child = $(this).parents(".subtask-add");
                if(child.length > 0){
                    $(child).remove();
                }
            }
        });

        // Copy task link
        new Clipboard('.copy-task-button', {
            text: function(trigger) {
                var taskid =  $(trigger).parents(".task-parent").attr('data-taskid');
                taskid = parseInt(taskid);
                var alpha_id = AlphabeticID.encode(taskid);
                var link = laroute.route("permalink.task",{alphaid:alpha_id});
                return link;
            }
        }).on('success', function(e) {
            toast("Copied");
            e.clearSelection();
        }).on('error', function(e) {
            // In case copy didn't work
            $('#input_readonly').find("input").val(e.text);
            $('#input_readonly').modal('show').on("shown.bs.modal",function(e){
                $('#input_readonly').find("input").select();
            });
            e.clearSelection();
        });

        // Search task
        $(document).on("click",".aside-main-task .search-task-button",function () {
            $(this).addClass('hide');
            $('.aside-search').removeClass('hide');
            $('.aside-search').focus();
        });
        // Search
        $(".aside-search").donetyping(function(){
               var keyword = $(this).val();
                $(".comments-list .text").each(function(index, element) {
                var text = $(this).text();
                if (text.toLowerCase().indexOf(keyword.toLowerCase()) === -1){
                    $(this).parents(".comment").addClass('hide searchidden');
                }
                else{
                    // In case of previous searches
                    $(this).parents(".comment").removeClass('hide searchidden');
                }
            });
        });

        $(document).on("keydown",".aside-search",function(e){
                       if(e.which == 27){
                           closeTaskSearch();
         }
        });

        // Edit task
        $(document).on("click",".aside-main-task .edit-task-button",function () {
            var html = $("#template-edit-aside").html();
            Mustache.parse(html);
            var aside = $(this).parents(".aside-menu");
            var title = $(aside).find(".task-head-title").text().trim();
            var taglist = $(aside).find(".tags").attr("data-taglist");
            var assigned = $(aside).find(".assigned-user").attr("data-assigneduser");
            var due = $(aside).find(".duedateat").attr("data-duedateat");
            var taskid = $(aside).find(".task-parent").attr('data-taskid');

            rendered = Mustache.render(html, {
                title: title,
                taglist: taglist,
                assigned:assigned,
                due: due,
                taskid: taskid
            });

            var result = $(rendered).insertAfter(".app-body main");

            $(result).find(".tags").selectize({
                plugins: ['remove_button'],
                delimiter: ',',
                persist: false,
                create: function(input) {
                    return {
                        value: input,
                        text: input
                    }
                }
            });

            $(result).find(".assigned").selectize({
                persist: false,
                create: false,
                valueField: 'id',
                labelField: 'name',
                options:public_users,
                maxItems: 1,

            });

           var datefield =  $(result).find(".dueat").datepicker({
                language:airdatepicker_language(),
                position:'left top',
                dateFormat:'yyyy-mm-dd',
            }).data('datepicker');
           if(due){
               $(result).find(".dueat").datepicker({
               language:airdatepicker_language(),
               position:'left top',
               dateFormat:'yyyy-mm-dd',
           }).data('datepicker').selectDate(moment(due).toDate());
           }



        });

        // Minimize edit task aside
        $(document).on("click",".aside-menu-edit .close-et-button",function(){
//            $('body').addClass('aside-menu-hidden');
            $(".aside-menu-edit").remove();
        });


        // ------------------------------------
        // Minimize aside
        $(document).on("click",".aside-main-task .close-button",function(){
            $(".aside-main-task .task-parent").attr('data-taskid',0).attr('data-cursor',0);
            $('body').addClass('aside-menu-hidden');
            $('body').trigger('aside:close');
        });

        // ASIDE MENTION
        $(document).on("click",".commentaction-mention",function(){
            $(".add-comment-textarea").append(' <span class="atwho-query">@</span>');
            placeCaretAtEnd($(".add-comment-textarea").get(0));
            $(".add-comment-textarea").click();

        });
        // ASIDE MENTION
        $('.add-comment-textarea').atwho({
            at: "@",
            data: public_users,
            displayTpl: "<li><img src='{{route('avatar')}}/${id}'>${name}</li>",
            insertTpl: "${atwho-at}${name}",
        });
        // ASIDE DROPZONE
        dropzone =  $(".aside-main-task").dropzone({
            url: "{{ route("tasks.commentattach") }}",
            previewsContainer: "#comment-attachment-bar",
            previewTemplate: $("#template-comment-attach").html(),
            headers:{
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr('content')
            },
            maxFiles:10,
            clickable: ".attach-button",
            timeout:0,
            init: function() {
                this.on('error', function(file, response) {

                    var errorMessage = '{{ trans('messages.error_connection') }}';
                    if(typeof errorMessage === 'string')
                    {
                        errorMessage = response;
                    }
                    else if(response.hasOwnProperty('errors'))
                    {
                        errorMessage = response.errors[0].detail;
                    }
                    else if(errorMessage === undefined)
                    {
                        errorMessage = "{{ trans('messages.error_up_file') }}";
                    }
                    $(file.previewElement).find('.dz-error-message').text(errorMessage);
                });
                this.on("success", function(file, response) {
                    file.previewElement.setAttribute("data-attachid", response.id);
                });
            }
        });

        // Add paste support , selected browsers
        document.onpaste = function(event){
            var items = (event.clipboardData || event.originalEvent.clipboardData).items;
            for (index in items) {
                var item = items[index];
                if (item.kind === 'file') {
                    // adds the file to your dropzone instance
//                    Dropzone.forelement
                    Dropzone.forElement(".aside-main-task").addFile(item.getAsFile());

                }
            }
        }

        // ASIDE REMOVE ATTACHMENT
        $(document).on("click","#comment-attachment-bar .remove-attachment",function(){
            $(this).parents(".cattachment").remove();
        });
        //ASIDE VCARD
        $('.commentaction-vcard').popover({
            animation:false,
            html:true,
            delay:50,
            placement:"auto",
            container:'body',
            template: '<div class="popover popover-commentaction" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content popover-ca"></div></div>',
            content: function(r){
                var vcardName = $("#pm-vc-name").val();
                var vcardEMail = $("#pm-vc-email").val();
                var vcardNumber = $("#pm-vc-number").val();
                var vcardAddr = $("#pm-vc-address").val();
                var html = $("#template-ca-vcard").html();
                Mustache.parse(html);
                rendered = Mustache.render(html, {
                    vcardName: vcardName,
                    vcardEMail: vcardEMail,
                    vcardNumber: vcardNumber,
                    vcardAddr: vcardAddr
                });
                return rendered;
            }
        });
        // ASIDE VCARD
        $(document).on("change",".vcard-comment input,.vcard-comment textarea",function(){
            var value = $('.vcard-comment input,.vcard-comment textarea').filter(function () {
                return this.value != '';
            });
            if(value.length > 0)
            {
                $(".commentaction-vcard").addClass('active');
            }
            else{
                $(".commentaction-vcard").removeClass('active');
            }
            var vcardName = $("#pm-vcv-name").val();
            var vcardEMail = $("#pm-vcv-email").val();
            var vcardNumber = $("#pm-vcv-number").val();
            var vcardAddr = $("#pm-vcv-address").val();
            // Clone to Real ones
            $("#pm-vc-name").val(vcardName);
            $("#pm-vc-email").val(vcardEMail);
            $("#pm-vc-number").val(vcardNumber);
            $("#pm-vc-address").val(vcardAddr);

        });

        // ASIDE VCARD
        $(document).on("click",".vcard-comment .reset",function(){
            var value = $('.vcard-comment input,.vcard-comment textarea').val('');
            $("#pm-vc-name").val('');
            $("#pm-vc-email").val('');
            $("#pm-vc-number").val('');
            $("#pm-vc-address").val('');

            $(".commentaction-vcard").removeClass('active');
            $('.commentaction-vcard').popover('hide');
        });
        // ASIDE VCARD
        $(document).on("click",".vcard-comment .hide-po",function(){
            $('.commentaction-vcard').popover('hide');
        });

        // ASIDE Location
        $(document).on("click",".commentaction-location",function(){

            $('#template-locationpick').modal('show');

            var latitudeInput = $('#mp-lat').val();
            var longitudeInput = $('#mp-long').val();
            var locationNameInput = $('#mp-addr').val();

            if((latitudeInput)  === '' || (longitudeInput)  === '' || (locationNameInput)  === '')
            {
                latitudeInput= 36.1337;
                longitudeInput= -119.1337;
            }

            $("#pickedmap").locationpicker({
                location: {
                    latitude:latitudeInput ,
                    longitude: longitudeInput
                },
                inputBinding: {
                    latitudeInput: $('#mp-lat'),
                    longitudeInput: $('#mp-long'),
                    locationNameInput: $('#mp-addr')
                },
                radius: 20,
                enableAutocomplete: true
            });

            if(navigator.geolocation){
                navigator.geolocation.getCurrentPosition(function (position) {
                    $("#pickedmap").locationpicker("location", {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    });
                })
            }

        });

        // task edits
        $(document).on("click",".save-edits-button",function(){
            var taskid = $(this).parents(".task-parent").attr("data-taskid");
            var inputs = $(this).parents(".task-parent").find("input.tedit");
            var data = inputs.serialize();
            var aside = $(this).parents(".aside-menu-edit");
            $(this).addClass("disabled");

            axios({
                method:'post',
                url:'{{ route('tasks.edit') }}',
                data: data
            }).then(function(response) {
                loadTask(taskid);
                $(aside).remove();
            }).catch(handleAxiosErrors);
        });

        $(document).on("change","#sendonentercheckbox",function(e){
            if($(this).is(':checked')){
                Cookies.set("sendonenter","on",{ expires: 365 });
            }
            else{
                Cookies.set("sendonenter","off",{ expires: 365 });
            }
        });

        $('.add-comment-textarea').keydown(function(e) {
            if (e.which == 13 && $('.sendonenter .checkbox:checked').length > 0) {
                $("#post-comment-btn").trigger("click");
                return false;
            }
            else if (e.keyCode === 13) {
                document.execCommand('insertHTML', false, '<br><br>');
                return false;
            }
        });

        $(document).on("click",".edit-this-comment",function(){
            var comment = $(this).parents(".comment");
            var text = $(comment).find(".text");
            $(text).prop("contenteditable",true);
            $(text).focus();
            $(text).addClass("editable");
        });

        // Subtasks actions

        // Clicking delete on task actions
        $(document).on("click",".subtask .task-action-label .delete",function(){

            var popover = $(this).parents('.popover-content');
            var subtask = $(this).parents('.subtask');
            var subtask_id=  $(subtask).attr('data-subtaskid');

            var action = $(popover).find('.action').val();
            $(popover).find('.task-action-label').html('');
            if(action === 'user')
            {
                axios({
                    method:'post',
                    url:'{{ route('tasks.subtask.reassign') }}',
                    data:{
                        model_id: subtask_id,
                        user_id: 0
                    }
                }).then(function(response){
                    $(subtask).removeClass('spinner processing');
                }).catch(handleAxiosErrors);
                $(subtask).find(".avatar").remove();
            }
            else if (action === 'calendar')
            {
                axios({
                    method:'post',
                    url:'{{ route('tasks.subtask.duedate') }}',
                    data:{
                        model_id: subtask_id,
                        due_date: 0
                    }
                }).then(function(response){
                    $(subtask).removeClass('spinner processing');
                }).catch(handleAxiosErrors);
                $(subtask).find(".subtask-duedate").removeClass('converted').html('');
            }
            $(subtask).find(".popover").popover('hide');
        });


        // Choosing User
        $(document).on("shown.bs.popover",".subtasks .subtask-actionable[data-action=user]",function(){
            var subtask = $(this).parents('.subtask');
            var user_id = $(subtask).attr('data-assigned');
            if(user_id != ''){
                var name = $('.choose-user [data-userid='+user_id+']').attr("data-name");
                var template = $('#task-action-top-label').html();
                Mustache.parse(template);
                var rendered = Mustache.render(template, {
                    content: name
                });
                $(subtask).find('.popover-content').find('.task-action-label').html(rendered);
            }
        });

        $(document).on("click",".subtask .choose-user-field ul li",function(){
            var subtask = $(this).parents('.subtask');
            var user_id = $(this).attr("data-userid");
            var name = $(this).text();
            $(subtask).attr('data-assigned',user_id);
            var name = $(this).attr('data-name').trim();
            $(subtask).attr('data-assigned_to',name);
            var subtask_id=  $(subtask).attr('data-subtaskid');
            var template = $('#task-action-top-label').html();
            Mustache.parse(template);
            var rendered = Mustache.render(template, {
                content: name
            });
            $(this).parents('.popover-content').find('.task-action-label').html(rendered);

            var avatar = $(subtask).find('.avatar');
            if(avatar.length == 0){

                var avatartpl = $('#template-subtask-item-avatar').html();
                Mustache.parse(avatartpl);
                var renderedavatar = Mustache.render(avatartpl, {
                    assigned_to: user_id
                });
                $(subtask).find(".head-details").append(renderedavatar).fadeIn(300);
            }
            avatar.fadeOut(500, function() {
                avatar.attr("src",laroute.route("avatar",{id:user_id}));
                avatar.fadeIn(500);
            });
            $(subtask).addClass('spinner processing');
            $('.subtaskactions').popover('hide')
            axios({
                method:'post',
                url:'{{ route('tasks.subtask.reassign') }}',
                data:{
                    model_id: subtask_id,
                    user_id: user_id
                }
            }).then(function(response){
                $(subtask).removeClass('spinner processing');
            }).catch(handleAxiosErrors);

        });

        // Choosing Calendar
        $(document).on("shown.bs.popover",".subtasks .subtask-actionable[data-action=calendar]",function(){
            var subtask = $(this).parents('.subtask');
            var subtask_id=  $(subtask).attr('data-subtaskid');
            $(subtask).find('.datechoose').datepicker({
                language:airdatepicker_language(),
                firstDay:{{Settings::gets("start_day",null,0)}},
                inline: true,
                position: 'bottom left',
                onSelect:function(formattedDate, date, inst){

                    var subtask = $(".subtaskactions").parents('.subtask');
                    $(subtask).attr('data-duedate',formattedDate);
                    var bo_duedate = moment(formattedDate,"MM/DD/YYYY").format("D MMM");
                    $(subtask).find('.subtask-duedate').text(bo_duedate);
                    var name = formattedDate;
                    var template = $('#task-action-top-label').html();
                    Mustache.parse(template);
                    var rendered = Mustache.render(template, {
                        content: name
                    });
                    $(this).parents('.popover-content').find('.task-action-label').html(rendered);
                    $('.task-action').popover('hide');

                    $(subtask).addClass('spinner processing');
                    $('.subtaskactions').popover('hide')
                    axios({
                        method:'post',
                        url:'{{ route('tasks.subtask.duedate') }}',
                        data:{
                            model_id: subtask_id,
                            due_date: formattedDate
                        }
                    }).then(function(response){
                        $(subtask).removeClass('spinner processing');
                    }).catch(handleAxiosErrors);


                }

            });
            var due_date = $(subtask).attr('data-duedate');
            if(due_date != ''){
                var template = $('#task-action-top-label').html();
                Mustache.parse(template);
                var rendered = Mustache.render(template, {
                    content: due_date
                });
                $(subtask).find('.subtaskactions').find('.task-action-label').html(rendered);
            }
            var popover = $('.subtaskactions');
            var sender = popover.prev();
            var adjustment = (sender.position().top - popover.height()) + 143;
            var adjustment2 = (sender.position().left) - 254;
            popover.css({ top: adjustment, left:adjustment2});

        });

        // Delete subtask
        $(document).on("click",".subtask-delete",function(e){
            var subtask = $(this).parents(".subtask");
            var subtask_id = $(subtask).attr("data-subtaskid");

            swal({
                    title: "{{ trans('common.are_you_sure') }}",
                    text: "{{ trans('messages.unable_to_restore_del') }}",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "{{ trans('common.yes') }}",
                    cancelButtonText: "{{ trans('common.cancel') }}",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function(isConfirm){
                    if (isConfirm) {
                        axios({
                            method:'post',
                            url:'{{ route('tasks.subtask.delete') }}',
                            data:{
                                model_id: subtask_id
                            }
                        }).then(function(response){
                            $(subtask).fadeOut().remove();
                            swal.close();
                        }).catch(handleAxiosErrors);
                    }
                    else{
                        swal.close();
                    }
                });



        });

        // rename subtask

        $(document).on("click",".subtask-rename",function(e){
            var subtask = $(this).parents(".subtask");
            var subtask_id = $(subtask).attr("data-subtaskid");
            var txtfieldvalue =  $(subtask).find(".head-text").text();
            var html_input = $('<input>').attr({
                type: 'text',
                class: 'form-control input-xs subtaskrenamefield',
                value: txtfieldvalue,
                'data-taskid' : subtask_id
            });
            $(subtask).find(".head-text").html(html_input);
            $(subtask).find("input").focus();

        });

        $(document).on("focusout",".subtaskrenamefield",function(e){
            var subtask = $(this).parents(".subtask");
            var subtask_id = $(subtask).attr("data-subtaskid");
            var textValue = $(this).val().trim();
            $(subtask).find(".head-text").html(textValue);
            $(subtask).addClass("spinner pending");
                     axios({
                            method:'post',
                            url:'{{ route('tasks.subtask.rename') }}',
                            data:{
                                model_id: subtask_id,
                                title: textValue
                            }
                        }).then(function(response){
                            $(subtask).removeClass('spinner pending');
                        }).catch(handleAxiosErrors);
        });

        $(document).on("keydown",".subtaskrenamefield",function(e){
            // submit on ESC or enter
            if(e.which === 27 || e.which == 13){
                e.preventDefault();
                $(this).blur();
                $(this).trigger('focusout');
            }
        });

        $(document).on("focusout",".aside-main-task .comment .text.editable",function(){
                var comment = $(this).parents(".comment");
                var taskcomment_id = $(comment).attr("data-taskcommentid");
                var content = $(this).html().trim();
                $(this).prop("contenteditable",false);
                $(this).removeClass("editable");
                $(comment).addClass("loading");

                axios({
                    method:'post',
                    url:'{{ route('tasks.editcomment') }}',
                    data:{
                        tc_id: taskcomment_id,
                        content: content
                    }
                }).then(function(response){
                    $(comment).removeClass('loading');
                }).catch(handleAxiosErrors);


        });

        // ASIDE LIKE
        $(document).on("click",".comment-like",function(){
            var html = $("#template-aside-comment-like").html();
            var counter = $(this).siblings('.likes-counter').html();
            var comment = $(this).parents(".comment");
            var taskcomment_id = $(comment).attr("data-taskcommentid");
            var can_edit = $(comment).attr("data-canedit");
            var is_comment_owner = new Boolean(can_edit);

            if(counter === undefined)
            {
                counter = 0;
            }
            else{
                counter = parseInt(counter);
            }

            counter = counter + 1;
            Mustache.parse(html);
            rendered = Mustache.render(html, {
                likes_count: counter,
                liked_by_auth_user:  true,
                is_comment_owner: is_comment_owner
            });
            var ck = $(this).parents('.like-action');
            $(ck).html(rendered);
            $(ck).addClass('animating');
            setTimeout(function(){
                $(ck).removeClass('animating')
                ; }, 1000, ck);

            axios({
                method:'post',
                url:'{{ route('tasks.commentlike') }}',
                data:{
                    tc_id: taskcomment_id
                }
            }).catch(handleAxiosErrors);;

        });
        // ASIDE COMMENT UNLIKE
        $(document).on("click",".comment-unlike",function(){
            var html = $("#template-aside-comment-like").html();
            var counter = $(this).siblings('.likes-counter').html();
            var comment = $(this).parents(".comment");
            var taskcomment_id = $(comment).attr("data-taskcommentid");
            var can_edit = $(comment).attr("data-canedit");
            var is_comment_owner = new Boolean(can_edit);

            if(counter === undefined)
            {
                counter = 0;
            }
            else{
                counter = parseInt(counter) -1;
            }
            Mustache.parse(html);
            rendered = Mustache.render(html, {
                likes_count: counter,
                liked_by_auth_user:  false,
                is_comment_owner: is_comment_owner
            });
            var ck = $(this).parents('.like-action');
            $(ck).html(rendered);
            $(ck).addClass('animating');
            setTimeout(function(){
                $(ck).removeClass('animating')
                ; }, 1000, ck);
            axios({
                method:'post',
                url:'{{ route('tasks.commentunlike') }}',
                data:{
                    tc_id: taskcomment_id
                }
            }).catch(handleAxiosErrors);
        });
        // ASIDE DOWNLOAD ATTACHMENT
        $(document).on("click",".download-attachment",function(){
            var attachment_id = $(this).attr("data-attchid");
            var link = "{{route("tasks.downloadattachment")}}" + "/" + attachment_id;
            window.open(link, "_blank");



        });

        // SAVE LOCATION PICKER
        $(document).on("click","#mp-save",function(){

            var latitudeInput = $('#mp-lat').val();
            var longitudeInput = $('#mp-long').val();
            var locationNameInput = $('#mp-addr').val();
            if((latitudeInput)  === '' || (longitudeInput)  === '' || (locationNameInput)  === '')
            {
                return false;
            }
            else
            {
                $(".commentaction-location").addClass("active");
                $('#template-locationpick').modal('hide');

            }
        });


        // Check task ( aside + normal )
        $(document).on("click",".task-checkbox:not(.done,.loading,.readonly)",function(e){
            var taskid = $(this).parents("[data-taskid]").attr("data-taskid");
            if(taskid == 0 || taskid == 'undefined'){return false;}
            $(".task-item[data-taskid="+taskid+"]").find(".task-checkbox").addClass('done');
            $(".task-parent[data-taskid="+taskid+"]").find(".task-checkbox").addClass('done');
            $(".fc-event[data-taskid="+taskid+"]").find(".task-checkbox").addClass('done');
            $(this).addClass('animating');
            var ck = $(this);
            setTimeout(function(){
                $(ck).removeClass('animating')
                ; }, 1000, ck);
            e.stopPropagation();

            axios({
                method:'post',
                url:'{{ route('tasks.check') }}',
                data:{
                    task_id: taskid
                }
            }).catch(handleAxiosErrors);

        });

        // Uncheck task ( aside + normal )
        $(document).on("click",".task-checkbox.done:not(.readonly)",function(e){
            var taskid = $(this).parents("[data-taskid]").attr("data-taskid");
            if(taskid == 0 || taskid == 'undefined'){return false;}
            $(".task-item[data-taskid="+taskid+"]").find(".task-checkbox").removeClass('done');
            $(".task-parent[data-taskid="+taskid+"]").find(".task-checkbox").removeClass('done');
            $(".fc-event[data-taskid="+taskid+"]").find(".task-checkbox").removeClass('done');

            $(this).removeClass('animating');
            e.stopPropagation();

            axios({
                method:'post',
                url:'{{ route('tasks.uncheck') }}',
                data:{
                    task_id: taskid
                }
            }).catch(handleAxiosErrors);;
        });

        // Subtasks checkboxes

        // Check task ( aside + normal )
        $(document).on("click",".subtask-checkbox:not(.done,.loading,.readonly)",function(e){
            var taskid = $(this).parents("[data-subtaskid]").attr("data-subtaskid");
            if(taskid == 0 || taskid == 'undefined'){return false;}
            $(".subtask[data-subtaskid="+taskid+"]").find(".subtask-checkbox").addClass('done');
            $(this).addClass('animating');
            var ck = $(this);
            setTimeout(function(){
                $(ck).removeClass('animating')
                ; }, 1000, ck);
            e.stopPropagation();

            axios({
                method:'post',
                url:'{{ route('tasks.subtask.check') }}',
                data:{
                    subtask_id: taskid
                }
            }).catch(handleAxiosErrors);

        });

        // Uncheck task ( aside + normal )
        $(document).on("click",".subtask-checkbox.done:not(.readonly)",function(e){
            var taskid = $(this).parents("[data-subtaskid]").attr("data-subtaskid");
            if(taskid == 0 || taskid == 'undefined'){return false;}
            $(".subtask[data-subtaskid="+taskid+"]").find(".subtask-checkbox").removeClass('done');

            $(this).removeClass('animating');
            e.stopPropagation();

            axios({
                method:'post',
                url:'{{ route('tasks.subtask.uncheck') }}',
                data:{
                    subtask_id: taskid
                }
            }).catch(handleAxiosErrors);;
        });

        // RESET LOCATION
        $(document).on("click","#mp-reset",function(){
            var latitudeInput = $('#mp-lat').val('');
            var longitudeInput = $('#mp-long').val('');
            var locationNameInput = $('#mp-addr').val('');
            $(".commentaction-location").removeClass("active");
            $('#template-locationpick').modal('hide');
        });
        // LOCATION
        $('#template-locationpick').on('shown.bs.modal', function () {
            $('#pickedmap').locationpicker('autosize');
        });

        // remove comment
        $(document).on("click",".remove-comment.deleteable",function() {
            var comment =$(this).parents(".comment");
            var comment_id = $(comment).attr("data-taskcommentid");
            swal({
                    title: "{{ trans('common.are_you_sure') }}",
                    text: "{{ trans('messages.unable_to_restore_del') }}",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "{{ trans('common.yes') }}",
                    cancelButtonText: "{{ trans('common.cancel') }}",
                    closeOnConfirm: true,
                    closeOnCancel: false
                },
                function(isConfirm){

                if(isConfirm)
                {
                    $(comment).addClass('deleting');
                    axios({
                        method:'post',
                        url:'{{ route('tasks.deleteComment') }}',
                        data:{
                            comment_id: comment_id,
                        }
                    }).then(function(response) {
                        $(comment).slideUp();
                    }).catch(handleAxiosErrors);
                }
                    swal.close();
                });


        });

        // Add task comment & attachments
        $(document).on("click","#post-comment-btn:not(.disabled)",function(){
            $(".task-comment-box .add-comment").removeClass("error");
            var content = $("#commenttextarea").html().trim();
            var task_id = $(this).parents('.task-parent').attr("data-taskid");
            // Is location here?
            var latitudeInput = $('#mp-lat').val();
            var longitudeInput = $('#mp-long').val();
            var locationNameInput = $('#mp-addr').val();

            // vCard
            var vcardName = $("#pm-vc-name").val();
            var vcardEMail = $("#pm-vc-email").val();
            var vcardNumber = $("#pm-vc-number").val();
            var vcardAddr = $("#pm-vc-address").val();


            // Files
            var fileslist =   $("#comment-attachment-bar").find('li.dz-success').map(function(e,d) {
                return $(d).attr("data-attachid");
            }).get();
            if(!(content) && !(latitudeInput) && !(longitudeInput) && !(locationNameInput)
                && (fileslist.length == 0) && !(vcardNumber)
             ){
                $(".task-comment-box .add-comment").addClass("error");
                return false;
            }
                $("#post-comment-btn").addClass('disabled');
                $("#post-comment-btn").addClass('commenting');


            // reset form

            axios({
                method:'post',
                url:'{{ route('tasks.addcomment') }}',
                data:{
                    task_id: task_id,
                    content: content,
                    latitude: latitudeInput,
                    longitude: longitudeInput,
                    locationName: locationNameInput,
                    vcardName: vcardName,
                    vcardEMail: vcardEMail,
                    vcardNumber: vcardNumber,
                    vcardAddr: vcardAddr,
                    files: fileslist
                }
            }).then(function(response) {
                resetTaskCommentBox();
                html = $("#template-aside-fake-comment").html();
                Mustache.parse(html);
                rendered = Mustache.render(html, {
                    text: content
                });
                $(".aside-main-task .comments-list").append(rendered);
                rescroll_comment_list();
                $("#post-comment-btn").removeClass('disabled');
                $("#post-comment-btn").removeClass('commenting');
            }).catch(handleAxiosErrors);
        });

    });
    function closeTaskSearch()
    {
        $(".aside-search").val('');
        $(".aside-search").addClass('hide');
        $(".search-task-button").removeClass('hide');
        $(".comments-list .comment.hide.searchidden").removeClass('hide searchidden')
    }
    function rescroll_comment_list()
    {
        $('.comments-list').scrollTop($('.comments-list').prop('scrollHeight'));
    }

    function start_live_comments() {
        Poll.start({
            name: "live_comments",
            interval: 3000,
            action: function(){
                var taskid = $(".aside-main-task .task-parent").attr("data-taskid");
                var cursor = $(".aside-main-task .task-parent").attr("data-cursor");
                if(taskid > 0 && cursor >= 0 && !($("#post-comment-btn").hasClass("commenting")))
                {
                    axios({
                        method:'post',
                        url:'{{ route('tasks.commentloadlive') }}',
                        data:{
                            task_id: taskid,
                            cursor: cursor
                        }
                    }).then(function(response) {
                        $(".aside-main-task .comments-list .comment.pending").remove();
                        if(response.data.data.length > 0)
                        {
                            addTaskComments(response.data.data);
                        }
                    }).catch(handleAxiosErrors);
                }
            }
        });

    }


    start_live_comments();
    //start_live_tasks();

    // IDLE STUFF
    $(function() {

        $( document ).idleTimer(30000);
        // Sleeping
        $( document ).on( "idle.idleTimer", function(event, elem, obj){
            Poll.stop("live_comments");
//            Poll.stop("live_tasks");
        });
        // Waking Up
        $( document ).on( "active.idleTimer", function(event, elem, obj, triggerevent){
            start_live_comments();
//            start_live_tasks();
        });


    });

    // From session

    @if(Session::has("view_task"))
        loadTask({{Session::get("view_task")}});
    @endif
    @if(Session::has("view_task_comment"))
        loadTask({{Session::get("task_id")}},function(){
        $(".aside-main-task li.comment[data-taskcommentid='{{Session::get("view_task_comment")}}']").addClass("highlighted");
    });
    @endif

</script>

