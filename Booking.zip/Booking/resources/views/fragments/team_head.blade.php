<div class="row project-head">
    <div class="col-md-7">
        <div class="project-detail">
            <h4 class="title">{{$team->title}}</h4>
        </div>
    </div>
</div>



@section("extra_js")
    <script type="text/javascript">

    </script>
@append