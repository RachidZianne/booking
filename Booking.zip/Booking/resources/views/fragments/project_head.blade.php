<div class="row project-head">
    <div class="col-md-7">
        <div class="project-detail" data-projectid="{{$project->id}}">
            <h4 class="title">{{$project->title}}</h4>
            <h6 class="subtitle">{{ trans('common.shared_with') }}
                @if($project->privacy == "teams")
                    @foreach($project->sharedteams as $steam)
                    <span class="shared">{{$steam->team->title}}</span>@if (!$loop->last), @endif
                    @endforeach
                @elseif($project->privacy == "users")
                    @foreach($project->sharedusers as $susers)
                        <span class="project-user">
                            <img src="{{route("avatar",$susers->user)}}" class="avatar avatar-sm avatar-circle"> <span class="shared">{{$susers->user->name}} </span> @if($susers->user->type == 'invited') <i class="fa fa-clock-o invited"></i> @endif
                        </span>
                    @endforeach
                @elseif($project->privacy == "public")
                    <span class="shared">{{ trans('common.privacy_everyone') }}</span>
                @elseif($project->privacy == "me")
                    <span class="shared">{{ trans('common.privacy_me') }}</span>
                @endif
                @if(Auth::id() == $project->user_id || Auth::user()->isAdmin())– <a href="#" data-privacy="{{$project->privacy}}" class="update-privacy" data-projectid="{{$project->id}}" data-sharedwith="@if(!($project->sharedteams->isEmpty())){{$project->sharedteams->pluck('team_id')->toJson()}}@elseif(!($project->sharedusers->isEmpty())){{$project->sharedusers->pluck('user_id')->toJson()}}@else{{'[]'}}@endif">{{ trans('common.edit_privacy') }}</a>  @endif

            </h6>
        </div>

    </div>

</div>

@section("extra_js")
    <script type="text/javascript">



    </script>
@append