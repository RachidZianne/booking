@section("extra_menu_buttons")
    @if(Auth::id() == $project->user_id || Auth::user()->isAdmin())
        <a class="btn btn-secondary project-rename" href="#"><i class="icon-note"></i> &nbsp;<span class="btn-title">{{ trans('common.rename') }}</span> </a>
        <a class="btn btn-secondary dropdown-toggle project-export" data-projectid="{{$project->id}}" href="#" data-toggle="popover" data-placement="bottom" title="Export Project"><i class="fa fa-level-up"></i> <span class="btn-title">{{ trans('common.templates') }}</span> </a>
        <form class="inline-form" action="{{ route("projects.archive") }}" method="POST">
            @if($project->archived == 1)
                <a class="btn btn-secondary confirm-submit text-warning" href="#"><i class="icon-arrow-up-circle"></i> &nbsp; <span class="btn-title">{{ trans('common.restore') }}</span> </a>
            @else
                <a class="btn btn-secondary confirm-submit" href="#"><i class="icon-arrow-down-circle"></i> <span class="btn-title">{{ trans('common.archive') }}</span> </a>
            @endif
            {{ csrf_field() }}
            <input type="hidden" name="model_id" value="{{$project->id}}" />
        </form>
        <form class="inline-form" action="{{ route("projects.delete") }}" method="POST">
            <a class="btn btn-secondary delete-submit" href="#"><i class="icon-trash"></i> &nbsp;<span class="btn-title">{{ trans('common.delete') }}</span> </a>
            {{ csrf_field() }}
            <input type="hidden" name="model_id" value="{{$project->id}}" />
        </form>

    @endif

@append