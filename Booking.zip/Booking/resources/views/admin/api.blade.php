@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')


            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('common.api') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">

                                <div class="form-group row">
                                    <div class="col-md-4 form-control-label">{{ trans('admin.reset_api_token') }}
                                    </div>

                                    @if(!empty(Settings::gets("api_key")))
                                        <div class="col-md-8">
                                        <input type='text' class="form-control apikey" name="api" value="{{Settings::gets("api_key")}}" readonly="readonly"/>
                                        <p class="help-text"><i class="fa fa-lock"></i> {{ trans('admin.token_privacy') }}</p>

                                            <div class="col-md-4 form-control-label">
                                            </div>
                                            <div class="col-md-8">
                                                <div class="pt-3">
                                                    <form action="{{route("admin.api_regen")}}" method="POST" class="inline-form">
                                                        <button type="button" class="confirm-submit btn btn-secondary" id="regen_token">{{ trans('admin.regenerate_token') }}</button>
                                                        {{csrf_field()}}
                                                    </form>
                                                    <form action="{{route("admin.api_delete")}}" method="POST" class="inline-form">
                                                        <button type="button" class="delete-submit btn btn-outline-danger">{{ trans('common.disable') }}</button>
                                                        {{csrf_field()}}
                                                    </form>
                                                </div>

                                            </div>

                                        </div>
                                              </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <div class="form-group row">
                                                    <div class="col-md-8 form-control-label">{{ trans('admin.enable_oauth') }}
                                                        <p class="help-text">{{ trans('admin.enable_oauth_msg') }}</p>
                                                    </div>
                                                    <div class="col-md-3">

                                                        <form action="{{route("admin.oauth_toggle")}}" method="POST" class="inline-form">
                                                            @if(Settings::gets("enable_oauth"))
                                                                <button type="submit" class="btn-outline-warning btn">{{ trans('common.disable') }}</button>
                                                            @else
                                                                <button type="button" class="confirm-submit btn btn-primary">{{ trans('common.enable') }}</button>
                                                            @endif
                                                            {{csrf_field()}}
                                                        </form>

                                                    </div>
                                                    <div class="col-md-1">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    @else
                                        @section("enable_api")
                                        <div class="col-md-8">
                                              <form action="{{route("admin.api_regen")}}" method="POST" class="inline-form">
                                                <button type="button" class="confirm-submit btn btn-primary">{{ trans('common.enable') }}</button>
                                                {{csrf_field()}}
                                            </form>
                                        </div>
                                    </div>
                            @append
                                    @endif
                            @yield("enable_api")

                                </div>








                                <!--/.row-->
                            </div>
                        </div>
                    </div>

                </div>

            </div>

@endsection

@section("extra_js")
    <script type="text/javascript">
        $(document).ready(function() {

            $(document).on("key")

        });
    </script>

@append