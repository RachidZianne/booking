@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

        <form method="POST" enctype="multipart/form-data" action="{{ route("admin.preferences_save") }}" data-spy="scroll" data-target="#myScrollspy" data-offset="20">
            <div class="row settings-page">

                <div class="col-lg-2 col-md-2">
                    <div class="card sticky-subnav">
                        <div class="card-header">
                            {{ trans('common.menu') }}
                        </div>

                        <div class="card-block no-padding">
                            <nav class="col-sm-12 col-md-12 scroll-pref">
                                <ul class="subnav">
                                    <li><a href="#pref_views"><i class="fa fa-paint-brush"></i> {{ trans('common.views') }}</a></li>
                                    <li><a href="#pref_users"><i class="icon-user"></i> {{ trans('common.users') }}</a></li>
                                    <li><a href="#pref_projects"><i class="icon-folder"></i> {{ trans('common.projects') }}</a></li>
                                </ul>
                            </nav>

                        </div>
                    </div>
                </div>

                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('common.preferences') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">

                                <h5 id="pref_views"><i class="fa fa-paint-brush"></i> {{ trans('common.views') }}</h5>

                                <div class="form-group row">
                                    <div class="col-sm-3 control-label col-md-3">{{ trans('messages.stack_view_spacing') }}
                                        <p class="help-text">{{ trans('messages.spacing_between_stacked_view') }}</p>
                                    </div>
                                    <div class="col-sm-9 col-md-9">
                                        @include("admin.preference_options",["name" => 'pref_view_stackgutter', 'items' =>  ['0' => trans('common.compact'),
                                        '15' => trans('common.normal'),
                                        '45' => trans('common.relaxed'),
                                        '80' => trans('common.very_relaxed')]
                                        ])
                                    </div>
                                </div>

                                <h5 id="pref_users"><i class="icon-user"></i> {{ trans('common.users') }}</h5>

                                <div class="form-group row">
                                    <div class="col-sm-3 control-label col-md-3">{{ trans('messages.invite_default_type') }}
                                        <p class="help-text">{{ trans('messages.invite_default_type_msg') }}</p>
                                    </div>
                                    <div class="col-sm-9 col-md-9">
                                        @include("admin.preference_options",["name" => 'pref_user_invited', 'items' => ['client' => trans("common.client"),'staff' => trans("common.staff") ] ])
                                    </div>
                                </div>

                                <h5 id="pref_users"><i class="icon-folder"></i> {{ trans('common.projects') }}</h5>

                                <div class="form-group row">
                                    <div class="col-sm-3 control-label col-md-3">{{ trans('messages.archived_projects_access') }}
                                        <p class="help-text">{{ trans('messages.archived_projects_access_msg') }}</p>
                                    </div>
                                    <div class="col-sm-9 col-md-9">
                                        @include("admin.preference_options",["name" => 'pref_project_archiveaccess', 'items' => ['0' => trans('common.no'),'1' => trans('common.yes')] ,'is_bool' => true])
                                    </div>
                                </div>

                                <!--/.row-->
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-2 col-md-2">
                    <div class="card sticky-subnav">
                        <div class="card-header">
                            {{ trans('common.action') }}
                        </div>
                        <div class="card-block">
                                {{ csrf_field() }}
                                <div class="form-actions">
                                    <button type="submit" class="btn btn-primary btn-block">{{ trans('common.save') }}</button>
                                </div>

                                <!--/.row-->
                        </div>
                    </div>

                </div>

            </div>

        </form>

@endsection

@section("extra_js")

<script type="text/javascript">
    $( document ).ready(function() {
//        $('body').scrollspy({ target: '.scroll-pref' })
    });


</script>
@append