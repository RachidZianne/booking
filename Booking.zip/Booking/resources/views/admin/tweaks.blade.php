@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

        <form method="POST" enctype="multipart/form-data" action="{{ route("admin.tweaks_save") }}" class="form-horizontal">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('common.tweaks') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">
                                <div class="mb-5"><h6><i class="icon-chemistry"></i> {{ trans('common.experimental') }}</h6>
                                    <p class="help-text">{{ trans('messages.some_expert') }}</p>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-8 form-control-label">{{ trans('messages.dd_disable') }}
                                    <p class="help-text">{{ trans('messages.dd_disable_msg') }}</p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="switch switch-text switch-primary">
                                            <input type="checkbox" name="tweaks_ddm" class="switch-input" @if(Settings::gets("tweaks_ddm")  == 1) checked @endif>
                                            <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                            <span class="switch-handle"></span>
                                        </label>
                                    </div>
                                </div>



                                <div class="form-group row">
                                    <div class="col-md-8 form-control-label">{{ trans('messages.stack_sec_view') }}
                                    <p class="help-text">{{ trans('messages.alt_sec_view') }}</p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="switch switch-text switch-primary">
                                            <input type="checkbox" name="tweaks_stack" class="switch-input" @if(Settings::gets("tweaks_stack")  == 1) checked @endif>
                                            <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                            <span class="switch-handle"></span>
                                        </label>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <div class="col-md-8 form-control-label">{{ trans('messages.fullscreen_mode') }}
                                        <p class="help-text">{{ trans('messages.fullscreen_mode_msg') }}</p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="switch switch-text switch-primary">
                                            <input type="checkbox" name="fullscreen_mode" class="switch-input" @if(Settings::gets("fullscreen_mode")  == 1) checked @endif>
                                            <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                            <span class="switch-handle"></span>
                                        </label>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            {{ csrf_field() }}
        </form>

@endsection

@section("extra_js")
    <script type="text/javascript">
        $(document).ready(function() {


        });
    </script>

@append