@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')
    {{$logs->links()}}

    <div class="row">
            <div class="col-lg-10 col-md-10">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> {{ trans('common.history') }}
                    </div>

                    <table class="table table-responsive table-hover table-outline mb-0">
                        <thead class="thead-default">
                        <tr>
                            <th class="text-center"><i class="icon-people"></i>
                            </th>
                            <th>{{ trans('common.user') }}</th>
                            <th class="text-center">{{ trans('common.action') }}</th>
                            <th>{{ trans('common.timestamp') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($logs as $log)
                        <tr>
                            <td class="text-center">
                                <div class="avatar">
                                    <img src="{{route("avatar",$log->user_id)}}" class="img-avatar">
                                </div>
                            </td>
                            <td>
                                <div>{{$log->user->name or trans("common.deleted")}}</div>
                                <div class="small text-muted">
                                    <span>{{ trans('common.id') }}:</span> {{$log->user_id}}
                                </div>
                            </td>
                            <td>
                             {{$log->action}}
                            </td>
                            <td>
                                <strong>{{$log->created_at}}</strong>
                            </td>
                        </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
        {{$logs->links()}}

@endsection
