@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')
            @if(Session::has("rate"))
                @include("fragments.rate_metis")
            @endif
            <div class="row">
                <div class="col-md-2 col-lg-2"></div>
                <div class="col-lg-8 col-md-8">

                    <form method="POST" enctype="multipart/form-data" action="{{route("update.check")}}">

                        <div class="card">
                            <div class="card-header">
                                <i class="fa fa-leaf"></i> Verify Purchase
                            </div>
                            <div class="card-block">
                                <div class="card-block">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="name">Purchase Code</label>
                                                <input type="text" class="form-control" name="code" placeholder="e.g: 9ad2ff5d-b854-3jd4-73a0-0bd1e5701337" autocomplete="off">
                                                @if(!Config::get("hide_metis_label"))
                                                 <p class="help-text">This will attempt to send your purchase code to Metis Server for verification using Envato API</p>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <!--/.row-->
                                </div>
                                <div class="form-actions">
                                    <button type="submit" class="btn btn-success">Verify</button>
                                </div>
                            </div>
                        </div>
                        {{ csrf_field() }}
                    </form>

                </div>

            </div>


@endsection

@section("extra_js")

@append