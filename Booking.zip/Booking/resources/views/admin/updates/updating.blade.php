<html><head>
    <meta charset="utf-8">
    <title>Metis Update</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <!--[if lte IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <style>
        .full-height,body,html{height:100vh}body,html{background-color:#fff;color:#3f4649;font-family:Raleway,sans-serif;font-weight:100;margin:0}.flex-center{align-items:center;display:flex;justify-content:center}.position-ref{position:relative}.top-right{position:absolute;right:10px;top:18px}.content{text-align:center}.title{font-size:84px}.subtitle{font-size:54px}.links>a{color:#3f4649;padding:0 25px;font-size:12px;font-weight:600;letter-spacing:.1rem;text-decoration:none;text-transform:uppercase}.m-b-md{margin-bottom:30px}
    </style>

</head>
<body class="home language-horizon">
<div class="flex-center position-ref full-height">
    <div class="content">
        <div class="title m-b-md">Updating..</div>
        <div class="subtitle" style="
    color: #9E9E9E;
">Set back and wait</div>
    </div>
</div>

</body>
</html>