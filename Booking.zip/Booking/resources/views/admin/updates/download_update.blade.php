@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')
            @if(Session::has("rate"))
                @include("fragments.rate_metis")
            @endif
            <div class="row">
                <div class="col-md-2 col-lg-2"></div>
                <div class="col-lg-8 col-md-8">

                    <form method="POST" enctype="multipart/form-data" action="{{route("update.download-updates")}}">

                        <div class="card">
                            <div class="card-header">
                                <i class="icon-rocket"></i> <strong>Update Available</strong>
                            </div>
                            <div class="card-block">
                                <div class="card-block">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <p >An update <strong class="text-success">(v{{version_format($to)}})</strong> is available, Do you want to download and install the update?</p>
                                                <p>Update size: <strong class="text-success">{{human_filesize($filesize)}}</strong>.</p>
                                                <p class="text-align-center"><button id="update-btn" type="submit" class="btn btn-success">Update</button></p>
                                                <p class="text-danger">Do NOT close this window while updating.</p>

                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="from" value="{{$from}}">
                                    <input type="hidden" name="to" value="{{$to}}">
                                    <input type="hidden" name="checksum" value="{{$checksum}}">
                                    <!--/.row-->
                                </div>
                                <div class="form-actions">
                                </div>
                            </div>
                        </div>
                        {{ csrf_field() }}
                    </form>

                </div>

            </div>


@endsection

@section("extra_js")
    <script type="text/javascript">
        $(document).on("click","#update-btn",function(e){
                $(this).attr("disabled","disabled").text("Downloading Update.. Please wait").unbind('click');
                $(this).parents("form").submit();
        });
    </script>
@append