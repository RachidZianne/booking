@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

        <form method="POST" enctype="multipart/form-data" action="{{ route("admin.mail_save") }}">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('admin.mail_settings') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">


                                <div class="form-group">
                                    <label class="col-sm-3 control-label">{{ trans('admin.mail_driver') }}</label>
                                    <div class="col-sm-9">
                                        <select class="form-control" name="driver" id="driver">
                                            <option value="sendmail" @if(Config::get("mail.driver") == "sendmail")  selected @endif >PHP Sendmail</option>
                                            <option value="mail" @if(Config::get("mail.driver") == "mail")  selected @endif >PHP Mail</option>
                                            <option value="smtp" @if(Config::get("mail.driver") == "smtp") selected @endif >SMTP</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">{{ trans('admin.default_sender') }}</label>
                                    <div class="col-sm-9">
                                        <input type="email" name="defaultmail" class="form-control" placeholder="{{ trans('admin.default_sender') }}" value="{{Config::get("mail.from.address")}}">
                                    </div>
                                </div>

                                <div id="smtp_sett">
                                    <div class="form-group">
                                        <div class="p-3 text-muted">{{ trans('admin.smtp_settings') }} </div>
                                        <label class="col-sm-3 control-label">{{ trans('admin.mail_host') }}</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="host" class="form-control" placeholder="{{ trans('admin.mail_host') }}" value="{{Config::get("mail.host")}}">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">{{ trans('admin.mail_username') }}</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="username" class="form-control" placeholder="{{ trans('admin.mail_username') }}" value="{{Config::get("mail.username")}}">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">{{ trans('admin.mail_password') }}</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="password" class="form-control" placeholder="{{ trans('admin.mail_password') }}" value="{{Config::get("mail.password")}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">{{ trans('admin.mail_port') }}</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="port" class="form-control" placeholder="{{ trans('admin.mail_port') }}" value="{{Config::get("mail.port")}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">{{ trans('admin.host_encryption') }}</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="encryption" id="encryption">
                                                <option value="" @if(Config::get("mail.encryption") == "tls" || Config::get("mail.encryption") == "")  selected @endif >TLS/No encryption</option>
                                                <option value="ssl" @if(Config::get("mail.encryption") == "ssl")  selected @endif >SSL</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            {{ csrf_field() }}
        </form>

@endsection

@section("extra_js")
    <script type="text/javascript">
        $(document).ready(function() {
            $("#driver").on("change",function(e){
               if($(this).val() == 'smtp'){
                   $("#smtp_sett").show();
               }
               else{
                   $("#smtp_sett").hide();
               }
            });
            $("#driver").trigger("change");
        });
    </script>

@append