<select name="{{$name}}" class="form-control">
    @if(is_assoc($items) || (isset($is_bool) && $is_bool))
        @foreach($items as $option => $optitle)
            <option value="{{$option}}" @if(Settings::gets($name) == $option) selected @endif>{{$optitle}}</option>
        @endforeach
    @else
        @foreach($items as $option)
            <option value="{{$option}}" @if(Settings::gets($name) == $option) selected @endif>{{$option}}</option>
        @endforeach
    @endif
</select>