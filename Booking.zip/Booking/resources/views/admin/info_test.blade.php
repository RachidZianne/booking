<div class="clearfix">
    <div class="float-left">
        @if($test)
            <button type="button" class="btn btn-success">{{ trans('admin.Passed') }}</button>
        @else
            <button type="button" class="btn btn-danger">{{ trans('admin.failed') }}</button>
        @endif
    </div>
    <div class="float-right software-info">
        @if($test)
        <small class="text-muted">{{$success}}</small>
        @else
        <small class="text-danger">{{$fail}}</small>
        @endif
    </div>
</div>