@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

        <form method="POST" enctype="multipart/form-data" action="{{ route('admin.general_save') }}">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('admin.general_settings') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('admin.site_name') }}</label>
                                            <input type="text" class="form-control" name="site_name" placeholder="{{ trans('admin.site_name') }}" value="{{Settings::gets("site_name")}}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('admin.site_url') }}</label>
                                            <input type="text" class="form-control" name="site_url" placeholder="{{ trans('admin.site_url') }}" value="{{Config::get("app.url")}}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('admin.timezone') }}</label>
                                           {!!  Timezone::selectForm(Settings::gets("timezone"),trans('admin.timezone'),['class' => 'form-control','name' => 'timezone'])  !!}
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('admin.start_of_week') }}</label>
                                            <select name="firstday" class="form-control">
                                                <option value="0"  @if(Settings::gets("start_day") == "0") selected @endif >Sunday</option>
                                                <option value="1"  @if(Settings::gets("start_day") == "1") selected @endif>Monday</option>
                                                <option value="2"  @if(Settings::gets("start_day") == "2") selected @endif>Tuesday</option>
                                                <option value="3"  @if(Settings::gets("start_day") == "3") selected @endif>Wednesday</option>
                                                <option value="4"  @if(Settings::gets("start_day") == "4") selected @endif>Thursday</option>
                                                <option value="5"  @if(Settings::gets("start_day") == "5") selected @endif>Friday</option>
                                                <option value="6"  @if(Settings::gets("start_day") == "6") selected @endif>Saturday</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">Logo</label>
                                            <div class="admin-logo-container">
                                                <img src="{{route("logo")}}" class="logo-admin"/>
                                            </div>
                                            <input type="file" class="form-control" name="logo">
                                            <p class="text-muted">{{ trans('admin.rec_logo_size') }}: 440x100</p>
                                        </div>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            {{ csrf_field() }}
        </form>

@endsection