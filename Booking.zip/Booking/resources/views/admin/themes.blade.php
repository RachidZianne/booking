@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

        <form method="POST" enctype="multipart/form-data" action="{{ route('admin.themes_save') }}" id="cssform">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('common.themes') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">

                                <div class="row">
                                    <div class="col-sm-1">
                                        <label for="name">Custom CSS</label>

                                    </div>
                                    <div class="col-sm-11">
                                        <div class="form-group">
                                            <div>
                                                <textarea class="hide" data-lang="css" id="cssdata" name="cssdata">{{\App\Hardsetting::gets("customcss")}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="button" id="css_savechanges" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            {{ csrf_field() }}
        </form>

@endsection

@section("extra_js")
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/addon/runmode/colorize.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/mode/css/css.min.js"></script>
    <script type="text/javascript">
        myTextArea = document.getElementById("csseditor");
        myHiddenTxt = document.getElementById("cssdata");
        var myCodeMirror = CodeMirror.fromTextArea(myHiddenTxt,{
            theme:'hopscotch',
            lineNumbers:true
        });
        $(document).ready(function(){

            $(document).on("click","#css_savechanges",function(e){
                 $("#cssdata").html(myCodeMirror.getValue());
                 $("#cssform").submit();
            });


        });

    </script>
@append
@section("extra_css")
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/codemirror.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/theme/hopscotch.min.css" />
@append