@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')
            @if(Session::has("rate"))
            @include("fragments.rate_metis")
            @endif
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <table class="table table-responsive table-hover table-outline mb-0">
                        <thead class="thead-default">
                        <tr>
                            <th colspan="2">{{ trans('common.software_info') }}</th>
                        </tr>
                        </thead>
                        <tbody>

                        <tr>
                            <td>
                                <div>{{ trans('admin.version') }}</div>
                            </td>
                            <td>
                                <div class="float-left">
                                </div>
                                <div class="float-right">
                                    @if(Settings::gets("purchase_code"))
                                        @if(!Config::get("hide_metis_label"))
                                            <form action="{{ route("update.check-updates") }}" class="inline-form" method="POST">
                                                <button type="submit" class="btn btn-secondary check-updates">{{ trans('admin.check_updates') }}</button>
                                                {{ csrf_field() }}
                                            </form>
                                        @endif
                                    @endif
                                    {{ version_format(Settings::gets("version")) }}
                                    @if(!Config::get("hide_metis_label"))
                                            @if(!Settings::gets("purchase_code")) <a href="{{route("update.link")}}"> @endif
                                        <span class="fa fa-stack @if(Settings::gets("purchase_code")) version-verified @else version-not-verified @endif">
                                        <i class="fa fa-certificate fa-stack-2x"></i>
                                        <i class="fa fa-check fa-stack-1x fa-inverse"></i>
                                        </span>
                                    @if(!Settings::gets("purchase_code")) </a> @endif
                                    @endif
                                </div>
                            </td>
                        </tr>

                        </tbody>
                    </table>

                </div>

            </div>

                <div class="row">
                <div class="col-lg-8 col-md-8">
                    <table class="table table-responsive table-hover table-outline mb-0">
                        <thead class="thead-default">
                        <tr>
                            <th class="text-align-middle">{{ trans('admin.more_info') }}</th>
                            <th class="text-align-right"><a href="#" class="moreinfobtn btn btn-secondary btn-xxsmall"><i class="icon-arrow-down"></i> </a></th>
                        </tr>
                        </thead>
                        <tbody class="hide" id="more_info">
                        <tr>
                            <td>
                                <div>Config Folder</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">{{config_path()}}</span>
                                </div>
                            </td>
                            <td>
                                @include("admin.info_test",['test' => is_writable(config_path()) , 'success' => 'Writeable' , 'fail' => 'Config folder is not writeable'])
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>Storage Folder</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">{{storage_path()}}</span>
                                </div>
                            </td>
                            <td>
                                @include("admin.info_test",['test' => is_writable(storage_path()) , 'success' => 'Writeable' , 'fail' => 'Storage folder is not writeable'])
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>Resources Folder</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">{{resource_path()}}</span>
                                </div>
                            </td>
                            <td>
                                @include("admin.info_test",['test' => is_writable(resource_path()) , 'success' => 'Writeable' , 'fail' => 'Resource folder is not writeable'])
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>Image Driver</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">GD or Imagick must be installed</span>
                                </div>
                            </td>
                            <td>
                                @include("admin.info_test",['test' => (extension_loaded('gd') || extension_loaded('imagick')) , 'success' => Config::get("image.driver") , 'fail' => 'Image driver not installed or not configured'])
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>Zip Module</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">Zip Module , mainly used for Auto Updater</span>
                                </div>
                            </td>
                            <td>
                                @include("admin.info_test",['test' => (extension_loaded('zip')) , 'success' => 'Zip Module Installed' , 'fail' => 'PHP Zip Library missing or disabled'])
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>Software Path</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">{{base_path()}}</span>
                                </div>
                            </td>
                            <td>
                                @include("admin.info_test",['test' => is_writable(base_path()) , 'success' => 'Writeable' , 'fail' => 'App path is not writeable, you might not be able to update'])
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>{{ trans('admin.log') }}</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">{{ trans('admin.log_daily') }} {{storage_path('logs')}}</span>
                                </div>
                            </td>
                            <td>
                                <div class="float-left">
                                    <button type="button" class="btn btn-primary" id="showlog">{{ trans('common.show') }}</button>
                                </div>
                                <div class="float-right hide" id="logdetails">
                                    <form action="{{route("admin.log")}}" method="POST" enctype="multipart/form-data">
                                     <select name="day" class="form-control">
                                         @for($i=0;$i<7;$i++)
                                         <option>{{Carbon::now()->subDays($i)->toDateString()}}</option>
                                         @endfor
                                     </select>
                                        <br />
                                        <button type="submit" class="btn btn-success">{{ trans('common.download') }}</button>
                                    {{ csrf_field() }}
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div>{{ trans('admin.cache') }}</div>
                                <div class="small text-muted software-info-desc">
                                    <span class="path">{{ trans('admin.cache') }}</span>
                                </div>
                            </td>
                            <td>
                                <div class="float-right">
                                    <form action="{{route("admin.flushcache")}}" method="POST" enctype="multipart/form-data">
                                        <button type="submit" class="btn btn-outline-warning">{{ trans('admin.flush') }}</button>
                                    {{ csrf_field() }}
                                    </form>
                                </div>
                            </td>
                        </tr>

                        </tbody>
                    </table>

                </div>

            </div>

@endsection

@section("extra_js")
    <script type="text/javascript">
        $(document).on("click","#showlog",function(){
           $("#logdetails").removeClass("hide")
        });
        $(document).on("click",".moreinfobtn",function(){
           $(this).remove();
           $("#more_info").removeClass("hide")
        });
    </script>
@append