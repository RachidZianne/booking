@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

        <form method="POST" enctype="multipart/form-data" action="{{ route("admin.map_save") }}">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('common.location_sharing_settings') }}
                        </div>
                        <div class="card-block">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('common.location_sharing') }}</label> <br />
                                            <label class="switch switch-text switch-primary">
                                                <input type="checkbox" name="location_enabled" class="switch-input" @if(Settings::gets("location_enabled")  == 1) checked @endif>
                                                <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                                <span class="switch-handle"></span>
                                            </label>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('admin.gmaps_api_key') }} <a class="btn btn-xxsmall btn-secondary" href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">{{ trans('common.get_key') }}</a> </label>
                                            <input type="text" class="form-control" name="location_js_api" placeholder="{{ trans('admin.gmaps_api_key') }}" value="{{Settings::gets("location_js_api")}}">
                                            <p class="help-block text-danger">{{ trans('common.required') }}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">{{ trans('admin.gmaps_embed_key') }} <a class="btn btn-xxsmall btn-secondary" href="https://developers.google.com/maps/documentation/embed/get-api-key" target="_blank">{{ trans('common.get_key') }}</a> </label>
                                            <input type="text" class="form-control" name="location_embed_api" placeholder="{{ trans('admin.gmaps_embed_key') }}" value="{{Settings::gets("location_embed_api")}}">
                                            <p class="help-block">{{ trans('admin.gmaps_embed_key_msg') }}</p>
                                        </div>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">{{ trans('common.save_changes') }}</button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            {{ csrf_field() }}
        </form>

@endsection