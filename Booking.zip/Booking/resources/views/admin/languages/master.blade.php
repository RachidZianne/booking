@extends("master")
@section("breadcrumb")
    @include("menus.admin")
@endsection
@section('content')

    <div class="row settings-page">

        <div class="col-lg-12 col-md-12">
            @yield("language_form")
        </div>


    </div>


@endsection

