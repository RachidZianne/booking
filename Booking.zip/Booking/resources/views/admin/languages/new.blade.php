@extends("admin.languages.master")

@section('language_form')

    <form action="{{ route('admin.languages.create') }}" method="POST"  class="form-horizontal" enctype="multipart/form-data">

        <div class="col-md-10 col-md-offset-2 col-md-pull-2">
            <h3>{{trans("admin.new_language")}}</h3>
            <div class="panel panel-default">
                <div class="panel-body">

                    <label for="language" class="text-grey pt-3">{{trans("messages.uploadlangxml")}}</label> <br />
                    <input type="file" name="language" id="language">
                    <button type="submit" class="btn btn-success push-down"> {{trans("common.install")}} </button>
                    {{csrf_field()}}
                </div>
            </div>
        </div>



    </form>


@endsection

