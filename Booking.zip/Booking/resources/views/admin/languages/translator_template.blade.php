<language version="1.0">
    <meta>
    <name>{{$title}}</name>
    <langCode>{{$locale}}</langCode>
    <author>{{ $author or 'Metis EasyTranslator' }}</author>
    <authorUrl>{{$link or metis_site_link()}}</authorUrl>
    </meta>
    <details>
        @foreach($language as $section => $phrases)
        <{{$section}}>
            @if(is_array($phrases))
                @foreach($phrases as $phrase=>$phraseval)
                    <phrase name="{{$phrase}}">{!! addslashes(htmlspecialchars($phraseval, ENT_XML1,'UTF-8'));  !!}</phrase>
                @endforeach
            @endif
        </{{$section}}>
        @endforeach
    </details>
</language>