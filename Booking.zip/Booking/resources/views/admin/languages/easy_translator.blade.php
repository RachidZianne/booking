@extends("admin.languages.master")

@section('language_form')

    <div class="card">
        <form action="{{ route("admin.languages.saveTranslator") }}" method="POST">
        <div class="card-header">
            {{ trans('common.languages') }}
        </div>
        <div class="card-block">
            <table class="table table-responsive easy-translator">
                    <tr>
                        <td>{{ trans('common.title') }}</td>
                        <td><input type="text" class="form-control" placeholder="{{trans('common.title')}}" name="title" value="{{ old('title') }}" /> </td>
                    </tr>
                    <tr>
                        <td>{{ trans('common.locale') }}</td>
                        <td><input type="text" class="form-control" placeholder="{{trans('common.locale')}}" name="locale" maxlength="3" value="{{ old('locale') }}" /> </td>
                    </tr>
                    <tr>
                        <td>{{ trans('common.author') }}</td>
                        <td><input type="text" class="form-control" placeholder="{{trans('common.author')}}" name="author" value="{{ old('author') }}" /> </td>
                    </tr>
                    <tr>
                        <td>{{ trans('common.link') }}</td>
                        <td><input type="text" class="form-control" placeholder="{{trans('common.link')}}" name="link" value="{{ old('link') }}" /> </td>
                    </tr>
            </table>
            <div class="row mobile-hidden language-stats">
                <div class="col-sm-4">
                    <div class="callout callout-info">
                        <small>{{ trans("common.translation") }}</small>
                        <br>
                        <strong class="h4"><span class="lang-done"></span>/<span class="lang-total"></span></strong>
                    </div>
                </div>
                <!--/.col-->
                <div class="col-sm-4">
                    <div class="callout callout-danger">
                        <small>{{ trans("common.progress") }}</small>
                        <br>
                        <strong class="h4"><span class="lang-progress"></span>%</strong>
                    </div>
                </div>
                <!--/.col-->
            </div>
            <table class="table table-responsive easy-translator">
                <tr>
                    <th>{{trans("common.translation")}}</th>

            @foreach($sections as $section_title => $section)
                    <tr class="section-title">
                        <td colspan="3"><i class="fa fa-globe"></i> {{ucfirst($section_title)}}
                        </td>
                    </tr>
                    @foreach($section as $k=>$v)
                    <tr class="transentence">
                        <td>

                             <div class="translate"><span class="title">{!! highlight_word_vars($v) !!}</span> <span class="help-id">({{trans("common.id")}}: {{$k}})</span><i class="icon-trans-done fa-2x text-blue fa fa-check-circle float-right"></i></div>
                            <input type="text" name="language[{{$section_title}}][{{$k}}]" class="form-control translatedword" value="{{ old('language.'.$section_title.'.'.$k) }}">
                        </td>
                    </tr>
                        @endforeach
                @endforeach
            </table>
            <div class="row">
                <div class="col-md-12">
                    {{ csrf_field() }}
                    <button type="submit" class="btn btn-success">{{trans("common.save")}} | <span class="lang-progress"></span>%</button>
                </div>
            </div>
        </div>
        </form>
    </div>


@endsection

@section("extra_js")
<script type="text/javascript">

    function refreshProgress()
    {
        var empty = $('.translatedword').filter(function() { return $(this).val() == ""; }).length;
        var total = $('.translatedword').length;
        var done = parseInt(total) - parseInt(empty);
        var progress = (done/total)*100;
        progress = progress.toFixed(2);
        $(".lang-done").text(done);
        $(".lang-total").text(total);
        $(".lang-progress").text(progress);

    }

    function refreshEmpty()
    {
        $('.translatedword').filter(function() { return $(this).val() == ""; }).parents('.transentence').removeClass('done');
    }
    setInterval(refreshEmpty, 3000);
    setInterval(refreshProgress, 2500);
    $(document).ready(function() {
        refreshProgress();

        $(document).on("click",".transentence",function(e){
                    $(this).find(".translatedword").focus();
        });

        $(document).on("focus",".translatedword",function(e){
                    $(this).parents(".transentence").addClass('active');
        });

        $(document).on("focusout",".translatedword",function(e){
                    $(this).parents(".transentence").removeClass('active');
        });

        $(document).on("click",".language-stats",function(e){
                var twd = $('.translatedword').filter(function() { return $(this).val() == ""; }).first();
                $(twd).focus();
        });

        $(".translatedword").donetyping(function(){
                    var word = $(this).val();
                    if(word)
                    {
                        $(this).parents('.transentence').addClass('done');
                    }
                    else{
                        $(this).parents('.transentence').removeClass('done');
                    }
                    refreshProgress();

        });

    });

</script>

@append
