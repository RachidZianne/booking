@extends("admin.languages.master")

@section('language_form')

    <div class="card">
        <div class="card-header">
            {{ trans('common.languages') }}
        </div>
        <div class="card-block">
            <a href="{{ route("admin.languages.add") }}" class="btn btn-primary mb-3">{{ trans('admin.new_language') }}</a>
            <a href="{{ route("admin.languages.translator") }}" class="btn btn-success mb-3">{{ trans('admin.easy_translator') }}</a>

            <table class="table table-responsive">
                <tr>
                    <th>{{ trans('common.id') }}</th>
                    <th>{{trans("common.title")}}</th>
                    <th>{{ trans('common.locale') }}</th>
                    <th>{{trans("common.author")}}</th>
                    <th class="center-text">{{trans("common.active")}}</th>
                    <th class="center-text">{{trans("common.default")}}</th>
                    <th class="center-text"></th>
                </tr>
                @foreach($languages as $language)
                    <tr>
                        <td class="title">{{ $language->id }}</td>
                        <td>{{ $language->language }}</td>
                        <td>{{ $language->code }}</td>
                        <td>@if(isset($language->author_url))<a href="{{$language->author_url}}" target="_blank">{{ $language->author }}</a>@else{{ $language->author }}@endif</td>
                        <td class="center-text">@if($language->active == 1) <i class="text-green fa fa-check-circle fa-2x"></i> @else <i class="text-grey fa fa-power-off fa-2x"></i>  @endif</td>
                        <td class="center-text">@if((Config::get("app.locale") == $language->code)) <i class="text-green fa fa-check-circle fa-2x  @if($language->code == 'en') readonlytrans @endif"></i> @endif</td>
                        <td class="td-fit" align="right">
                            @if((Config::get("app.locale") != $language->code))
                                <form method="POST" action="{{ route("admin.languages.default") }}" class="inline-form">
                                    <input type="hidden" name="model_id" value="{{$language->id}}"/>
                                    <a class="btn btn-sm btn-success confirm-submit" href="#"><i class="fa fa-home"></i> {{ trans('common.make_default') }} </a>
                                    {{ csrf_field() }}
                                </form>

                            @endif
                            <a class="btn btn-sm btn-secondary" href="{{route("admin.languages.update",$language)}}"><i class="fa fa-refresh"></i> {{ trans('common.update') }} </a>
                            <a class="btn btn-sm btn-secondary" href="{{route("admin.languages.export",$language)}}"><i class="fa fa-level-up"></i> {{ trans('common.export') }} </a>
                            <form method="POST" action="{{ route("admin.languages.delete") }}" class="inline-form">
                                <input type="hidden" name="model_id" value="{{$language->id}}"/>
                                <a class="btn btn-sm btn-outline-danger delete-submit @if($language->code == 'en' || (Config::get("app.locale") == $language->code) ) disabled @endif" href="#" ><i class="fa fa-remove"></i> {{ trans('common.delete') }} </a>
                                {{ csrf_field() }}
                            </form>
                        </td>
                    </tr>
                @endforeach
            </table>

        </div>
    </div>


@endsection

