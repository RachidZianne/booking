@extends("master")
@section("breadcrumb")
    @include("menus.insight")
@endsection
@section('content')

            <div class="row">
                @foreach($teams as $team)
                <div class="col-sm-6 col-lg-3">
                    <div class="social-box metis-box">
                        <h1 class="stat-box-title">{{$team->title}}</h1>
                        <div class="chart-wrapper"><iframe class="chartjs-hidden-iframe" tabindex="-1" style="display: block; overflow: hidden; border: 0px; margin: 0px; top: 0px; left: 0px; bottom: 0px; right: 0px; height: 100%; width: 100%; position: absolute; pointer-events: none; z-index: -1;"></iframe>
                            <canvas id="team_stats_{{$team->id}}" height="90" width="386"></canvas>
                        </div>
                        <ul>
                            <li>
                                <strong class="stat text-green">{{$team->tasks->filter(function($item) { return ($item->done == 1); })->count()}}</strong>
                                <span>{{ trans('common.tasks_completed') }}</span>
                            </li>
                            <li>
                                <strong class="stat text-red">{{$team->tasks->filter(function($item) { return ($item->done == 0); })->count()}}</strong>
                                <span>{{ trans('common.tasks_pending') }}</span>
                            </li>
                            <li>
                                <strong class="stat text-red">{{$team->tasks->filter(function($item) {
                                            if($item->done == 0 && !empty($item->due_date)){
                                             return ($item->due_date->lt(Carbon::now()));
                                            }
                                            else{ return false; }
                                            })->count()}}</strong>
                                <span>{{ trans('common.overdue') }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                @endforeach

            </div>

@endsection

@section("extra_js")
<script type="text/javascript">
    var team_data = {!! $team_data !!}

    $(".stat").filter(function () {
        return $(this).text() == 0;
    }).addClass("text-grey");
            @foreach($teams as $team)
    var labels = Object.keys(team_data[{{$team->id}}]);

    var data1 = {
        labels: labels,
        datasets: [{
            backgroundColor: 'rgba(255,255,255,.1)',
            borderColor: 'rgba(255,255,255,.55)',
            pointHoverBackgroundColor: '#fff',
            borderWidth: 2,
            data:Object.values(team_data[{{$team->id}}])
        }]
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
            display: false,
        },
        scales: {
            xAxes: [{
                display:false,
            }],
            yAxes: [{
                display:false,
            }]
        },
        elements: {
            point: {
                radius: 0,
                hitRadius: 10,
                hoverRadius: 4,
                hoverBorderWidth: 3,
            }
        }
    };
    var ctx = document.getElementById("team_stats_{{$team->id}}");
    var socialBoxChart1 = new Chart(ctx, {
        type: 'line',
        data: data1,
        options: options
    });

    @endforeach

    var bg_colors = ["#63c2de","#f86c6b","#747AE4","#FFB76D","#F86A8B","#5FDFCA","#7575E5"];

    $(".stat-box-title").each(function(){
            var bgcolor = bg_colors.shift();
            $(this).css("background-color",bgcolor);
            bg_colors.push(bgcolor)

    });


</script>
@append