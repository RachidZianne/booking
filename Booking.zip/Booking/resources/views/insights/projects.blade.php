@extends("master")
@section("breadcrumb")
    @include("menus.insight")
@endsection
@section('content')

            <div class="row">

            @foreach($allprojects as $project)
                        <div class="col-sm-6 col-lg-3">

                        <div class="card">
                <div class="card-header card-header-inverse  card-header-primary stat-header">
                    <div class="font-weight-bold pb-2 pt-2">
                        <span>{{$project->title}}</span>
                        <span class="float-right"><strong class="stat text-light-grey">{{$project->tasks->filter(function($item) { return ($item->done == 0); })->count()}}</strong> {{ trans('common.remaining') }}</span>
                    </div>
                    <div class="pb-3">
                                        <span>
                                            <small>{{ trans('common.today') }}: {{$project->tasks->filter(function($item) { return ($item->done == 1 && $item->done_at->isToday()); })->count()}} {{ trans('common.tasks_completed') }}</small>
                                        </span>
                        <span class="float-right">
                           <small>{{ trans('common.total') }}: {{$project->tasks->filter(function($item) { return ($item->done == 1); })->count()}}</small>
                           </span>
                    </div>
                    <div class="pb-3">
                                        <span>
                                            <small>{{ trans('common.overdue') }}: {{$project->tasks->filter(function($item) {
                                            if($item->done == 0 && !empty($item->due_date)){
                                             return ($item->due_date->lt(Carbon::now()));
                                            }
                                            else{ return false; }
                                            })->count()}} {{ trans('common.tasks') }}</small>
                                        </span>
                    </div>
                    <div class="chart-wrapper px-3" style="height:70px;">
                        <canvas id="team_stats_{{$project->id}}" class="chart chart-line" height="70"></canvas>
                    </div>
                   </div>
                   </div>
                   </div>

                        @endforeach


                </div>
            {{ $allprojects->links() }}
    @endsection

    @section("extra_js")
    <script type="text/javascript">
        var project_data = {!! $project_data !!};

        $(".stat").filter(function () {
            return $(this).text() == 0;
        }).addClass("text-white");
                @foreach($allprojects as $project)
        var labels = Object.keys(project_data[{{$project->id}}]);

    var data1 = {
        labels: labels,
        datasets: [{
            backgroundColor: 'rgba(255,255,255,.1)',
            borderColor: 'rgba(255,255,255,.55)',
            pointHoverBackgroundColor: '#fff',
            borderWidth: 1,
            data:Object.values(project_data[{{$project->id}}])
        }]
    };
    var options = {
        maintainAspectRatio: false,
        legend: {
            display: false
        },
        scales: {
            xAxes: [{
                gridLines: {
                    color: 'transparent',
                    zeroLineColor: 'transparent'
                },
                ticks: {
                    fontSize: 2,
                    fontColor: 'transparent',
                }

            }],
            yAxes: [{
                display: false,
                ticks: {
                    display: false,
                    min: 0,
                    max: Math.max.apply(Math, Object.values(project_data[{{$project->id}}]))+1,
                }
            }],
        },
        elements: {
            line: {
                borderWidth: 1
            },
            point: {
                radius: 4,
                hitRadius: 10,
                hoverRadius: 4,
            },
        }
    };
    var ctx = document.getElementById("team_stats_{{$project->id}}");
    var socialBoxChart1 = new Chart(ctx, {
        type: 'line',
        data: data1,
        options: options
    });

    @endforeach

    var bg_colors = ["#63c2de","#f86c6b","#747AE4","#FFB76D","#F86A8B","#5FDFCA","#7575E5"];

    var time = 0;
    $(".stat-header").each(function(){
            var bgcolor = bg_colors.shift();
            var bg = $(this);
        setTimeout( function(){
            $(bg).css("background-color",bgcolor);
        }, time);
        bg_colors.push(bgcolor);
        time+= 10;
    });


</script>
@append