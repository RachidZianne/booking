@extends("master")

@section("breadcrumb")
    @include("menus.tasks")
@endsection

@section("content")
    <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="row">
                    @forelse($attachments as $attachment)
                        @if($attachment->task_comment_attachment_type != "location")
                        <div class="col-md-3 mb-3">
                            <div class="mcard np"> {{$attachment->type}}
                                <div class="attachment-body">
                                    @if(is_valid_image_type($attachment->ext))
                                        <div class="mb-attachment-preview" style="background-image:url('{{route("tasks.previewattachmentmed",$attachment)}}')">
                                        </div>
                                    @else
                                        @if($attachment->task_comment_attachment_type != "vcard")
                                            <span class="attachment-file">
                                                   <span class="fa-stack fa-lg">
                                                      <i class="fa fa-circle fa-stack-2x"></i>
                                                      <i class="fa fa-{{fa_file($attachment->ext)}} fa-stack-1x fa-inverse"></i>
                                                    </span>
                                            </span>

                                        @else
                                            <span class="attachment-file">
                                                   <span class="fa-stack fa-lg">
                                                      <i class="fa fa-circle fa-stack-2x"></i>
                                                      <i class="fa fa-vcard-o fa-stack-1x fa-inverse"></i>
                                                    </span>
                                            </span>
                                        @endif
                                    @endif
                                </div>

                                <a class="attachment-link" href="{{ route("tasks.downloadattachment",$attachment) }}">
                                    <img class="avatar-responsive-height avatar-circle" src="{{route("avatar",$attachment->taskComment->user_id)}}"> <span class="attachment-title" title="{{$attachment->name}}">{{str_limit($attachment->name,16)}}</span>
                                    <span class="btn btn-outline-primary float-right"><i class="fa fa-download"></i></span>
                                </a>
                            </div>
                        </div>
                        @endif
                    @empty
                        <div class="col-md-3"></div>
                        <div class="col-md-6 mb-3">
                            <div class="mcard">
                                <h5>{{trans("common.no_files")}}</h5>
                                <p class="help-text">{{trans("messages.no_files_found")}}</p>
                            </div>
                        </div>
                    @endforelse
                </div>
            </div>
    </div>


@append

@section("extra_js")
<script type="text/javascript">

</script>
@append
