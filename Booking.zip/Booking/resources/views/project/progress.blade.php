@extends("master")

@section("breadcrumb")
    @include("menus.tasks")
@endsection

@section("content")
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="mcard mb-5">
                    <h6>{{ trans('common.about_project') }}</h6>
                    <p class="help-text">{{ trans('common.created_by') }} {{$project->user->name or trans('common.system') }}</p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="mcard mb-5">
                    <h6 class="mb-3">{{ trans('common.progress') }}</h6>
                    <div class="task-count text-blue">
                        <span class="number">{{$project->tasks->filter(function($item) { return ($item->done == 0); })->count()}}</span>
                        <span class="label">{{ trans('common.tasks_remaining') }}</span>
                    </div>
                    <div class="task-count text-redish">
                        <span class="number">{{$project->tasks->filter(function($item) {
                                            if($item->done == 0 && !empty($item->due_date)){
                                             return ($item->due_date->lt(Carbon::now()));
                                            }
                                            else{ return false; }
                                            })->count()}}</span>
                        <span class="label">{{ trans('common.tasks_overdue') }}</span>
                    </div>
                    <div class="task-count text-greenish">
                        <span class="number">{{$project->tasks->filter(function($item) { return ($item->done == 1); })->count()}}</span>
                        <span class="label">{{ trans('common.tasks_completed') }}</span>
                    </div>
                <div class="chart-wrapper px-3" style="height:175px;">
                    <canvas id="project_stats" class="chart chart-line" height="175"></canvas>
                </div>

            </div>

        </div>
    </div>

@append

@section("extra_js")
<script type="text/javascript">

    var project_data = {!! $pt_data !!}
    var labels = Object.keys(project_data);
    var lineChartData = {
        labels : labels,
        datasets : [
            {
                label: 'Tasks Completed',
                backgroundColor : 'rgba(0,191,160,0.2)',
                borderColor : 'rgba(0,191,160,1)',
                pointBackgroundColor : 'rgba(0,191,160,1)',
                pointBorderColor : '#fff',
                spanGaps:true,
                data:Object.values(project_data)
            }
        ]
    }

    var ctx = document.getElementById('project_stats');
    var chart = new Chart(ctx, {
        type: 'line',
        data: lineChartData,
        options: {
            responsive: true,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true,
                        stepSize:1
                    }
                }]
            }
        }

    });


</script>
@append
