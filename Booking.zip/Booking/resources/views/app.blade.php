@extends("master")
@includeWhen($view_type == 'project','fragments.project_buttons')
@section("breadcrumb")
    @include("menus.tasks")
@endsection
@section("extra_body_class")metis @endsection
@section("extra_container_class")metis @endsection
@section("content")

@if($view_type == 'project')
@section("view_type")project @endsection
    @include('fragments.project_head')
@elseif($view_type == 'team')
@section("view_type")team @endsection
    @include('fragments.team_head')
@endif
    <div class="sections-list {{$layout_type or ''}}">
        @foreach($sections as $section)
            <div class="section kanban-view" data-sectionId="{{$section->id}}" data-sectiontitle="{{$section->title}}">
            <div class="task-section-title"><span class="section-title">{{ $section->title }}</span>  @if(Auth::user()->isStaff())<i class="icon-arrow-down section-options" data-toggle="popover" data-placement="bottom"></i>@endif </div>
            <div class="task-section">
            <div class="task-body">
                    <ul class="task-list">@foreach($section->tasks as $task)
                        <li class="task-item-wrapper @if(count($task->subtasks)) has-subtasks @endif" data-taskid="{{$task->id}}">
                          <a class="task-item @if(!empty($task->snoozed_until)) snoozing @endif" data-taskid="{{$task->id}}" data-tdone="{{$task->done}}" data-tassigned="{{$task->assigned_to}}" data-tdue="{{$task->due_at}}"><span class="task-checkbox {{$task->done ? 'done' : ''}}"></span> {{$task->title}}</a>
                            @if(count($task->subtasks))
                            <span class="subtask-items"><i class="fa fa-angle-right subtask-toggle-icon"></i> <span class="toggle-subtask-text">{{ trans('common.show') }} <span class="subtask-count">{{$task->subtasks->count()}}</span> {{ trans('common.subtasks') }}</span>
                            <ul class="subtask-item-wrap hide">
                                @foreach($task->subtasks as $subtask)
                                     <li class="subtask" data-subtaskid="{{$subtask->id}}"><span class="subtask-checkbox {{$subtask->done ? 'done' : ''}}"></span>{{$subtask->title}}</li>
                                @endforeach
                                    <li class="add-subtask-inline"><i class="fa fa-plus"></i> {{ trans("common.add_subtask") }}</li>
                            </ul>
                            </span>
                            @endif
                        </li>@endforeach</ul>
                </div>
            </div>
                <div class="task-section-newtask">
                    @if(Auth::user()->isStaff())
                    <div class="new-task-label">
                        <i class="fa fa-plus"></i> {{ trans('common.new_task') }}
                    </div>
                    @endif
                    <div class="quick-task hide">
                        <textarea maxlength="191" class="comment-text mousetrap" placeholder="{{ trans('common.new_task') }}"></textarea>
                        <input type="hidden" class="assigned_to" name="assigned_to">
                        <input type="hidden" class="due_date" name="due_date">
                        <input type="hidden" class="tags" name="tags">
                        <ul class="quick-task-actions">
                            <li class="task-action" data-action="user" data-toggle="popover" data-placement="top" data-content=""><i class="icon-user"></i></li>
                            <li class="task-action" data-action="calendar" data-toggle="popover" data-placement="top" data-content=""><i class="icon-calendar"></i></li>
                            <li class="task-action" data-action="tag" data-toggle="popover" data-placement="top" data-content=""><i class="icon-tag"></i></li>
                            <li class="save-button"> <button class="save task-save">{{ trans('common.save') }}</button> </li>
                        </ul>
                    </div>
                </div>
                <input type="hidden" class="order" value="{{$section->sort}}">
            </div>
        @endforeach

        @if( ($view_type == 'team' || $view_type == 'project') && Auth::user()->isStaff() )
        <div class="fake-section new-section"  data-sectionId="-1">
            <span class="big"> <i class="fa fa-plus"></i> {{ trans('common.add_section') }}</span>
            <span class="small">{{ trans('common.click_to_add_tasks') }}</span>
            <ul class="task-list task-list-fake">
            </ul>
        </div>
        @endif
    </div>



<input type="hidden" id="view_type" value="{{$view_type}}">
<input type="hidden" id="view_id" value="@if($view_type == 'team'){{$team->id}}@elseif($view_type == 'project'){{$project->id}}@else{{'0'}}@endif" />
@endsection

@section("extra_js")

@if(Settings::gets("tweaks_stack") == 1)
    <script src="https://cdnjs.cloudflare.com/ajax/libs/masonry/4.2.0/masonry.pkgd.min.js"></script>
@endif

<script type="text/javascript">
    var $gridlayout = null;
    // Task list sortable
    var taskListSortableSettings = {
        animation: 180,
        dataIdAttr: 'data-taskid',
        group: 'task',
        store: {
            get: function (sortable) {
                var order = $(sortable.el).parents(".section").find(".order").val();
                return order ? order.split('|') : [];
            },
            set: function (sortable) {
                var order = sortable.toArray();
                var new_order = order.join('|');
                var section_id = $(sortable.el).parents(".section").attr("data-sectionId");
                var view_type = getViewType();
                if(view_type !== 'assigned'){
                    axios({
                        method:'post',
                        url:'{{ route('sections.resorttasks') }}',
                        data:{
                            new_order: new_order,
                            section_id: section_id
                        }
                    }).catch(handleAxiosErrors);
                }
            }
        },
        onAdd: function (evt) {
            var from_section = $(evt.from).parents('.section').attr("data-sectionId");
            var to_section = $(evt.to).parents('.section').attr("data-sectionId");
            var task_id = $(evt.item).attr("data-taskid");
            axios({
                method:'post',
                url:'{{ route('tasks.move') }}',
                data:{
                    task_id: task_id,
                    from_section: from_section,
                    to_section: to_section
                }
            }).catch(handleAxiosErrors);
        },
        onMove: function (evt) {
            if( $(evt.dragged).attr("data-taskid") == 0 ){
                return false;
            }
        }

    };



    // Section list sortable
    var sectionListSortableSettings = {
        animation: 100,
        dataIdAttr: 'data-sectionId',
        group: 'section',
        filter:".fake-section",
        chosenClass:"nothing",
        store: {
            get: function (sortable) {
                var order = localStorage.getItem("group");
                if(order){
                    var neworder = order.split('|');
                    neworder.push("-1");
                }

                return order ? neworder : [];
            },
            set: function (sortable) {
                var order = sortable.toArray();
                localStorage.setItem("group", order.join('|'));
            }
        },
        onMove: function (evt) {
            return evt.related.className.indexOf('fake-section') === -1;
        }
    };

    $( document ).ready(function() {

        @if(Auth::user()->isStaff())
            @if(Settings::gets("tweaks_ddm") == 1)
                if ($(window).width() > 991) {
                    $(".task-list").sortable(taskListSortableSettings);
                }
            @else
            $(".task-list").sortable(taskListSortableSettings);
            @endif

            if ($(window).width() > 991) {
                $(".sections-list").sortable(sectionListSortableSettings);
            }
        @endif

    });

    $(document).ready(function() {
        autosize($('textarea.comment-text'));
    });

    @if(Settings::gets("tweaks_stack") == 1)
    // Alternative Stack view
    $(document).ready(function() {
      $gridlayout =  $('.container-fluid:not(.linear) .sections-list').masonry({
            itemSelector: '.section,.new-section',
            gutter: {{ Settings::gets("pref_view_stackgutter",null,45) }}
      });
         // Delay
        $("body").on("aside:open task:new section:new aside:close",function (e) {
            setTimeout(function(){
                $gridlayout.masonry();
            },250)
        });
        // Immediate
        $("body").on("aside:close",function (e) {
            $gridlayout.masonry();
        });
        // Immediate & Reload
        $("body").on("section:new",function (e) {
            $gridlayout.masonry('reloadItems');
            $gridlayout.masonry();
        });
    });
    @endif

    // Project options
    $(document).on("click",".project-rename",function(e){
        var popover = $(this).parents('.popover');
        var project = $(".project-detail");
        var project_id = $(project).attr("data-projectid");
        var project_title = $(project).find(".title").text();
        $(popover).popover('hide');
        swal({
                title: "{{ trans('common.rename') }}",
                text: '{{ trans('common.project') }}: "'+ project_title + '"',
                type: "input",
                showCancelButton: true,
                confirmButtonText: Lang.get("common.ok"),
                cancelButtonText: Lang.get("common.cancel"),

                closeOnConfirm: false,
                showLoaderOnConfirm: true,
                inputPlaceholder: "{{ trans('common.new_project_title') }}"
            },
            function(inputValue){
                if (inputValue === false) return false;
                if (inputValue === "") {
                    swal.showInputError("{{ trans('common.you_need_to_write_something') }}!");
                    return false
                }
                axios({
                    method:'post',
                    url:'{{ route('projects.rename') }}',
                    data:{
                        title: inputValue,
                        model_id: project_id
                    }
                }).then(function(response) {
                    $(project).find(".title").text(inputValue);
                    swal("{{ trans('common.completed') }}", Lang.get('messages.project_renamed', { title: project_title , newtitle: inputValue}), "success");
                }).catch(handleAxiosErrors);
            });
    });

    // Section options
    $(document).on("click",".section-action-choose .rename",function(e){
            var popover = $(this).parents('.popover');
            var section = $(this).parents(".section");
            var section_id = $(section).attr("data-sectionId");
            var section_title = $(section).attr("data-sectiontitle");
            $(popover).popover('hide');
            swal({
                    title: "{{ trans('common.rename_section') }}",
                    text:  section_title,
                    type: "input",
                    showCancelButton: true,
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true,
                    inputPlaceholder: "{{ trans('common.section_title') }}"
                },
                function(inputValue){
                    if (inputValue === false) return false;
                    if (inputValue === "") {
                        swal.showInputError("{{ trans('common.you_need_to_write_something') }}");
                        return false
                    }

                    axios({
                        method:'post',
                        url:'{{ route('sections.rename') }}',
                        data:{
                            title: inputValue,
                            section_id: section_id
                        }
                    }).then(function(response) {
                        $(section).find(".section-title").html(inputValue);
                        $(section).find(".section-title").attr("data-sectiontitle",inputValue);
                        swal("{{ trans('common.completed') }}",Lang.get('messages.section_renamed', { title: section_title , newtitle: inputValue}), "success");
                    }).catch(handleAxiosErrors);
                });
    });

    $(document).on("click",".section-action-choose .delete",function(e){
            var popover = $(this).parents('.popover');
            var section = $(this).parents(".section");
            var section_id = $(section).attr("data-sectionId");
            var section_title = $(section).attr("data-sectiontitle");

            $(popover).popover('hide');
            swal({
                title: "{{ trans('common.are_you_sure') }}",
                text: "{{ trans('messages.unable_to_restore_del') }}",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "{{ trans('common.yes') }}",
                cancelButtonText: "{{ trans('common.cancel') }}",
                closeOnConfirm: false,
                closeOnCancel: true,
                showLoaderOnConfirm: true
            },
            function(isConfirm){
                if (isConfirm) {
                    axios({
                        method:'post',
                        url:'{{ route('sections.delete') }}',
                        data:{
                            section_id: section_id
                        }
                    }).then(function(response) {
                        $(section).remove();
                        swal("{{ trans('common.completed') }}", Lang.get('messages.section_deleted', { title: section_title }), "success");
                    }).catch(handleAxiosErrors);
                }
            });
    });

    $(document).on("click",".section .subtask-items",function(e){
            e.stopPropagation();
            var subtask_list = $(this).find(".subtask-item-wrap");
            var subtask_icon = $(this).find(".subtask-toggle-icon");
            if($(subtask_list).hasClass('hide')){
                $(subtask_list).removeClass('hide');
                $(subtask_icon).removeClass('fa-angle-right').addClass('fa-angle-down');
            }
            else{
                $(subtask_list).addClass('hide');
                $(subtask_icon).removeClass('fa-angle-down').addClass('fa-angle-right');
            }
    });

    // Add subtask
    $(document).on("click",".add-subtask-inline",function(e){
        e.stopPropagation();
        html = $("#add-task-input").html();
        $(this).before(html);
        $(this).parents(".subtask-item-wrap").find(".subtask-input").focus();
    });

    $(document).on("keydown",".subtask-input",function(e){
        if(e.keyCode == 13){
            e.preventDefault();
            $(this).blur();
        }
    });

    $(document).on("focusout",".subtask-input",function(e){
        e.stopPropagation();
        var subtask_text = $(this).val();
        var parent = $(this).parents(".add-subtask-input");
        var task_id = $(this).parents(".task-item-wrapper").attr("data-taskid");
        if(subtask_text == '')
        {
            $(this).parents(".add-subtask-input").remove();
        }
        else{
            var rep = $(this).replaceWith(subtask_text);
            parent.addClass('spinner faded');
            axios({
                method:'post',
                url:'{{ route('tasks.subtask.add') }}',
                data:{
                    task_id: task_id,
                    title: subtask_text
                }
            }).then(function(response) {
                var subtaskid = response.data.id;
                $(parent).removeClass('spinner faded add-subtask-input').addClass('subtask');
                $(parent).attr('data-subtaskid',subtaskid);
                $(parent).find('.subtask-checkbox').removeClass('readonly');
                reCountSubTasks(task_id);
            }).catch(handleAxiosErrors);

        }


    });

    $(document).on("click",".section-action-choose .archive",function(e){
            var popover = $(this).parents('.popover');
            var section = $(this).parents(".section");
            var section_id = $(section).attr("data-sectionId");
            var section_title = $(section).attr("data-sectiontitle");
            $(popover).popover('hide');
            swal({
                    title: "{{ trans('common.are_you_sure') }}",
                    text: "{{ trans('messages.archive_done_tasks_confirm') }}",
                    type: "info",
                    showCancelButton: true,
                    confirmButtonColor: "#2ab2f1",
                    confirmButtonText: "{{ trans('common.archive') }}",
                    cancelButtonText: "{{ trans('common.cancel') }}",
                    closeOnConfirm: false,
                    closeOnCancel: true,
                    showLoaderOnConfirm: true
                },
                function(isConfirm){
                    if (isConfirm) {
                        axios({
                            method:'post',
                            url:'{{ route('sections.archive') }}',
                            data:{
                                section_id: section_id
                            }
                        }).then(function(response) {
                            $(section).find(".task-checkbox.done").parents(".task-item-wrapper").remove();
                            swal("{{ trans('common.completed') }}", "{{ trans('messages.completed_tasks_archived') }}", "success");
                        }).catch(handleAxiosErrors);
                    }
                    else{

                    }
                });

    });


    // Loading comments
    $(document).on("click",".task-item",function(){
        var taskid = $(this).parents(".task-item-wrapper").attr("data-taskid");
        loadTask(taskid);

    });

    // Popover for Section actions
    var popoverSectionSettings = {
        animation:false,
        html:true,
        delay:50,
        template: '<div class="popover popover-sectionaction" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content popover-section"></div></div>',
        content: function(r){
            var html = $("#template-section-options").html();
            return html;
        }
    };

    // Popover for task actions
    var popoverSettings = {
        animation:false,
        html:true,
        delay:50,
        template: '<div class="popover popover-taskaction" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content popover-task"></div></div>',
        content: function(r){
            var action = $(this).attr("data-action");
            var html = '';
            if(action === 'user'){
                html = $("#task-action-user").html();
            }
            else if (action === 'calendar')
            {
                html = $("#task-action-calendar").html();
            }
            else if (action === 'tag')
            {
                html = $("#task-action-tag").html();
                Mustache.parse(html);
                html = Mustache.render(html, {
                    mostusedtags:  most_used_tags
                });
            }
            var $html = $('<div />',{html:html});
            $html.find('.action').val(action);
            return $html.html();

        }
    };

    function apply_popover(){

        // Popover for section options
        $('.section-options').popover(popoverSectionSettings).on('show.bs.popover', function() {
            if (window._bsbPopover) {
                $(window._bsbPopover).popover('hide')
            }
            window._bsbPopover= this;
        }).on('hide.bs.popover', function() {
            window._bsbPopover= null;
        });

            // -------------------
            // Popover for task options
        $('.task-action').popover(popoverSettings).on('show.bs.popover', function() {
            if (window._bsPopover) {
                $(window._bsPopover).popover('hide')
            }
            window._bsPopover= this;
        }).on('hide.bs.popover', function() {
                window._bsPopover= null;
            });
    }

    // Once on load
    apply_popover();

    // Choosing User
    $(document).on("shown.bs.popover",".section .task-action[data-action=user]",function(){
        var section = $(this).parents('.section');
        var user_id = $(section).find('.assigned_to').val();
        if(user_id != ''){
        var name = $(section).find('.assigned_to').attr("data-name");
        var template = $('#task-action-top-label').html();
        Mustache.parse(template);
        var rendered = Mustache.render(template, {
            content: name
        });
        $(section).find('.popover-taskaction .popover-content').find('.task-action-label').html(rendered);
    }
    });

    // Choosing Calendar
    $(document).on("shown.bs.popover",".task-action[data-action=calendar]",function(e){
        var section = $(this).parents('.section');
        $(section).find('.datechoose').datepicker({
            language:airdatepicker_language(),
            firstDay:{{Settings::gets("start_day",null,0)}},
            inline: true,
            position: 'bottom right',
            onSelect:function(formattedDate, date, inst){

                var section = $(".popover-taskaction").parents('.section');
                $(section).find('.due_date').val(formattedDate);
                var name = formattedDate;
                $(section).find('.due_date').attr("data-date",date);
                var template = $('#task-action-top-label').html();
                Mustache.parse(template);
                var rendered = Mustache.render(template, {
                    content: name
                });
                $(this).parents('.popover-content').find('.task-action-label').html(rendered);
                $(section).find('.task-action[data-action=calendar]').addClass('active');
                $('.task-action').popover('hide');
            }

        });
        var due_date = $(section).find('.due_date').val();
        if(due_date != ''){
        var template = $('#task-action-top-label').html();
        Mustache.parse(template);
        var rendered = Mustache.render(template, {
            content: due_date
        });
           $(section).find('.popover-taskaction .popover-content').find('.task-action-label').html(rendered);
          }
        var popover = $('.popover-taskaction');
        var sender = popover.prev();
        var adjustment = (sender.position().top - popover.height()) - 5;
        var adjustment2 = (sender.position().left) - 113;
        popover.css({ top: adjustment, left:adjustment2 });


    });

    // Choosing Tags
    $(document).on("shown.bs.popover",".task-action[data-action=tag]",function(){
        var section = $(this).parents('.section');
        var tagfield_value = $(section).find('.tags').val();
        var controlfield = $(section).find('.popover-taskaction .popover-content').find('.task-action-control');
        $(controlfield).val(tagfield_value);
        $(controlfield).selectize({
            plugins: ['remove_button'],
            delimiter: ',',
            persist: false,
            create: function(input) {
                return {
                    value: input,
                    text: input
                }
            }
        }).on('change',function(){
            var new_value = $(this)[0].selectize.getValue();
            var tags = '';
            if(new_value != '')
            {
                tags = $(section).find('.tags').val(new_value);
                $(section).find('.task-action[data-action=tag]').addClass('active');
            }
            else
            {
                tags = $(section).find('.tags').val(new_value);
                $(section).find('.task-action[data-action=tag]').removeClass('active');
            }

        });

    });

    // On clicking user on task actions
    $(document).on("click",".section .choose-user-field ul li",function(){
        var section = $(this).parents('.section');
        $(section).find('.assigned_to').val($(this).attr("data-userid"));
        var name = $(this).attr('data-name').trim();
        $(section).find('.assigned_to').attr("data-name",name);
        var template = $('#task-action-top-label').html();
        Mustache.parse(template);
        var rendered = Mustache.render(template, {
            content: name
        });
        $(this).parents('.popover-content').find('.task-action-label').html(rendered);
        $(section).find('.task-action[data-action=user]').addClass('active');
        $('.task-action').popover('hide')
    });

    // Clicking tag on task actions

    $(document).on("click",".choose-tag-field ul li",function(){
        var section = $(this).parents('.section');
        var selectize = $(section).find('.task-action-control')[0].selectize;
        var tag = $(this).attr("data-tag");
        selectize.createItem(tag);
        selectize.addItem(tag);
        selectize.refreshItems();
    });


    // Clicking delete on task actions
    $(document).on("click",".section .task-action-label .delete",function(){

        var popover = $(this).parents('.popover-content');
        var action = $(popover).find('.action').val();
        var qt = $(this).parents('.quick-task');
        $(popover).find('.task-action-label').html('');
        if(action === 'user')
        {
            $(qt).find(".assigned_to").attr('value','');
            $(qt).find('.task-action[data-action=user]').removeClass('active');
        }
        else if (action === 'calendar')
        {
            $(qt).find(".due_date").attr('value','');
            $(qt).find('.task-action[data-action=calendar]').removeClass('active');
        }
        $('.task-action').popover('hide');
    });

    // Clicking "New task" label
    $(document).on("click",".new-task-label",function(e){

                // Reset other quick-tasks
                $(".new-task-label").removeClass('hide');
                $(".quick-task").addClass('hide');
                $(this).addClass('hide');
                var sibling = $(this).next('.quick-task');
                $(sibling).removeClass('hide');
                $(sibling).find('textarea').focus();
                $('body').trigger('task:new');

    });
    // Pressing ESC while writing task
    $(document).on("keydown","textarea.comment-text",function(e){
                if(e.which === 27){
                    $(this).parents('.task-section-newtask').find('.new-task-label').removeClass('hide');
                    $(this).closest(".quick-task").addClass('hide');
                    $(this).closest(".quick-task").removeClass('error');
                }
    });

    // Creating new section : finished typing
    $(document).on("focusout",".section.pending .task-section-title",function(){
        var textValue = $(this).html().trim();
        textValue = textValue.replace(/<br\s*\/?>/gi,"");
        if(textValue == ""){
            $(this).parent(".section.pending").remove();
            return true;
        }
        var TheOldSection = $(this).parents(".section");
        var view_type = $('#view_type').val().trim();
        var view_id = $('#view_id').val().trim();

        $(this).addClass("spinner");
        axios({
            method:'post',
            url:'{{ route('sections.add') }}',
            data:{
                title: textValue,
                view_type: view_type,
                view_id: view_id
            }
        }).then(function(response) {
            var section_id = response.data.id;
            var template = $('#template-section').html();
            Mustache.parse(template);
            var rendered = Mustache.render(template, {
                sectionid: response.data.id,
                sectiontitle: response.data.title
            });
           $(TheOldSection).removeClass('spinner');
           $(TheOldSection).replaceWith(rendered);
           $("[data-sectionid="+section_id+"]").find(".task-list").sortable(taskListSortableSettings);
            apply_popover();
            autosize($('textarea.comment-text'));
            $('body').trigger('section:new');
        }).catch(handleAxiosErrors);

    });

    $(document).on("keydown",".section.pending .task-section-title",function(e){
        if(e.keyCode == 13){
           e.preventDefault();
          $(this).blur();
        }
    });

    $(document).on("click",".new-section",function(e){
        var template = $('#template-new-section').html();
        Mustache.parse(template);
        var rendered = Mustache.render(template, {
            sectionid: 0,
            sectiontitle: ""
        });
        $(rendered).insertBefore(".fake-section").find(".task-section-title").focus();
        $('body').trigger('section:new');
    });

    $(document).on("click",".task-save",function(e){
        var btn = $(this);
        var section = $(btn).parents(".section");
        var sectionId = $(section).attr("data-sectionId");
        addTask(sectionId);
    });

    $(document).on("keydown",".comment-text",function(e){
        if(e.keyCode == 13){
            e.preventDefault();
            $(this).blur();
            $(this).siblings('.quick-task-actions').children('.save-button').find(".task-save").trigger("click");
        }
    });

    function reCountSubTasks(taskid)
    {
            var task = $(".task-item-wrapper[data-taskid="+taskid+"]");
            var subtasks = $(task).find(".subtask-item-wrap .subtask").length;
            $(task).find(".subtask-count").text(subtasks);
    }
    function hideEmptyFilteredSections()
    {
        $('.sections-list .section:not(:has(.task-item-wrapper:not(.filter-hidden)))').addClass('filter-hidden');
    }

    function filter_tasks(filter)
    {
        // Remove currently filtered
        $(".filter-hidden").removeClass('filter-hidden');

        if(filter == 'done')
        {
            $(".sections-list .task-item[data-tdone!=1]").parent(".task-item-wrapper").addClass('filter-hidden');

        }
        else if (filter == 'undone')
        {
            $(".sections-list .task-item[data-tdone=1]").parent(".task-item-wrapper").addClass('filter-hidden');
        }
        else if (filter == 'unassigned')
        {
            $(".sections-list .task-item[data-tassigned!='']").parent(".task-item-wrapper").addClass('filter-hidden');
        }
        else if (filter == 'assigned')
        {
            $(".sections-list .task-item[data-tassigned='']").parent(".task-item-wrapper").addClass('filter-hidden');
        }
        else if (filter == 'nodue')
        {
            $(".sections-list .task-item[data-tassigned!='']").parent(".task-item-wrapper").addClass('filter-hidden');
        }
        else{
            // all , already removed
        }


        if(filter != 'all')
        {
            hideEmptyFilteredSections();
        }


    }


    function getViewType() {
        return $("#view_type").val();
    }

    function resetTaskBox(section)
    {
        // Reset all
        $(section).find('.assigned_to,.due_date,.tags,.comment-text').val('');
        // Remove
        $(section).find("[data-action].active").removeClass("active")
    }

    // add new task
    function addTask(section_id) {

        var section = $(".section[data-sectionid='"+section_id+"']");
        var sectionId = $(section).attr("data-sectionId");
        var textField = $(section).find('.comment-text');

        var assigned_to = $(section).find('.assigned_to').val();
        var due_date = $(section).find(".due_date").val();
        var tags = $(section).find(".tags").val();

        var textValue = textField.val();
        if(textValue.trim() == ''){
            $(section).find(".quick-task").addClass('error');
            return false;
        }
        $(section).find(".quick-task").removeClass('error');
        var template = $('#template-task-item').html();
        Mustache.parse(template);
        var rendered = Mustache.render(template, {
            taskid: 0,
            tasktitle: textField.val()
        });
        var taskButton = $(section).find(".save-button .save");
        var tasklist =  $(section).find(".task-list");
        var TheNewTask = $(rendered).appendTo(tasklist).addClass("spinner pending");

        var ts = $(section).find(".task-section");
        $(ts).scrollTop($(ts).prop('scrollHeight'));
        $(taskButton).prop('disabled', true).addClass("disabled");
        axios({
            method:'post',
            url:'{{ route('tasks.add') }}',
            data:{
                title: textValue,
                section_id: sectionId,
                assigned_to: assigned_to,
                due_date: due_date,
                tags: tags
            }
        }).then(function(response) {
                var template = $('#template-task-item').html();
                Mustache.parse(template);
                var rendered = Mustache.render(template, {
                    taskid: response.data.id,
                    tasktitle: textValue
                });
                $(rendered).removeClass('spinner');
                $(TheNewTask).replaceWith(rendered);
                $(taskButton).prop('disabled', false).removeClass("disabled");
        }).catch(function (error) {
            $(TheNewTask).removeClass("pending spinner");
            $(TheNewTask).addClass("failed");
            $(taskButton).prop('disabled', false).removeClass("disabled");
            bootbox.alert("{{ trans('messages.error_connection') }}");
        });

        // Allow user to add another one before ajax response

        resetTaskBox(section);
        $(taskButton).prop('disabled', false).removeClass("disabled");
        $(textField).focus();

    }

    // Fixes for popover and automatic close
    $('body').on('hidden.bs.popover', function (e) {
        $(e.target).data("bs.popover").inState.click = false;
    }).on('click', function (e) {
        //did not click a popover toggle, or icon in popover toggle, or popover
        if ($(e.target).data('toggle') !== 'popover'
            && $(e.target).parents('[data-toggle="popover"]').length === 0
            && $(e.target).parents('[data-original-title]').length === 0
            && $(e.target).parents('.datepicker--nav-action').length === 0
            && $(e.target).parents('.datepicker--nav-title').length === 0
            && !$(e.target).hasClass('datepicker--nav-title')
            && !$(e.target).hasClass('remove')
            && $(e.target).parents('.popover-task').length === 0
            && $(e.target).parents('.popover-section').length === 0
        ){
            $('[data-toggle="popover"]').popover('hide');
        }
    });

    var stage = document.getElementsByClassName('app metis');

    // Project Export

    var popoverPExport = {
        animation:false,
        html:true,
        delay:50,
        template: '<div class="popover popover-sectionaction" role="tooltip"><div class="arrow"></div><div class="popover-content popover-section"></div></div>',
        content: function(r){
            var proj = $(this).attr("data-projectid");
            var html = $("#project-export-template").html();

            var $html = $('<div />',{html:html});
            $html.find('.projectid').val(proj);
            return $html.html();
        }
    };
    // Popover for section options
    $('.project-export').popover(popoverPExport).on('show.bs.popover', function() {
        if (window._bsbPopover) {
            $(window._bsbPopover).popover('hide')
        }
        window._bsbPopover= this;
    }).on('hide.bs.popover', function() {
        window._bsbPopover= null;
    });

    $(document).on("click",".filter-menu li",function(e){
        var filter = $(this).attr("data-filter");
        var filter_text = $(this).text();
        $(".filter-menu").attr("data-current",filter);
        filter_tasks(filter);
        $(".metis-current-filter").text(filter_text);
    });

    $(document).on("change",".project-export-format",function(e){
       var val = $(this).val();
       if(val == 'file' || val == 'template')
       {
           $(".tpl-export-actions").removeClass('hide');
           $(".tpl-import-actions").addClass('hide');
       }
       else
       {
           $(".tpl-export-actions").addClass('hide');
           $(".tpl-import-actions").removeClass('hide');
       }

       if(val == 'template')
       {
           $("#project_export_title").removeClass('hide');
       }
       else{
           $("#project_export_title").addClass('hide');
       }

       if(val == 'importtemplatefile')
       {
           $(".project-import-tpl-file").removeClass('hide');
           $(".project-import-tpl-db").addClass('hide');

       }
       else if(val == 'importtemplate')
       {
           $(".project-import-tpl-file").addClass('hide');
           $(".project-import-tpl-db").removeClass('hide');
       }

    });

    $(".container-fluid.metis").scroll(function(){
        $(".breadcrumb").css("left",$(this).scrollLeft());
    });

    // Mouse wheel

//    $(document).mousewheel(function(event, delta) {
//        this.scrollLeft -= (delta * 30);
//        event.preventDefault();
//    });
//    $(".task-list").mousewheel(function(event, delta) {
//        $(this).parents('.task-section').scrollTop(   $(this).parents('.task-section').scrollTop() -  ( delta * 30 ) );
//        event.preventDefault();
//    });


    // Client Read only
    @if(!Auth::user()->isStaff())
    $( document ).ready(function() {
        $(".task-checkbox").addClass("readonly");
        $(".subtask-checkbox").addClass("readonly");
    });
    @endif

</script>

@include("fragments.aside_js")

@append


@section("footer")
    <footer class="app-footer metis-footer dropup">
        <button class="btn btn-link btn-sm dropdown-toggle" type="button" data-toggle="dropdown"  aria-haspopup="true" aria-expanded="false" >
            <i class="fa fa-filter"></i> {{ trans('common.view') }}: <span class="metis-current-filter">{{ trans('common.all_tasks') }}</span> <span class="caret"></span>
        </button>
        <ul class="dropdown-menu filter-menu" aria-labelledby="dropdownMenu2" data-current="all">
            <li data-filter="done">{{ trans('common.completed_tasks') }}</li>
            <li data-filter="undone">{{ trans('common.uncompleted_tasks') }}</li>
            <li data-filter="nodue">{{ trans('common.nodue_dates') }}</li>
            <li data-filter="unassigned">{{ trans('common.unassigned') }}</li>
            <li data-filter="assigned">{{ trans('common.assigned') }}</li>
            <li role="separator" class="dividerm"></li>
            <li data-filter="all">{{ trans('common.all_tasks') }}</li>
        </ul>

        <button class="btn btn-link btn-sm float-right openkeyboardsc"><i class="fa fa-keyboard-o"></i> {{ trans('common.shortcuts') }}</button>
    </footer>
@endsection