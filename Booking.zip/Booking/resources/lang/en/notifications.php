<?php

return [


    'new_task_assigned' => 'New task was assigned to you.',
    'new_comment_task' => '<strong>:name</strong> commented on your task.',
    'new_comment_mention' => '<strong>:name</strong> mentioned you in a comment.',

];
