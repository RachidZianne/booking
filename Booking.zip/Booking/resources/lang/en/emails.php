<?php

return [

	'you_were_invited_to' => 'You were invited to: ',
	'someone_mentioned_you' => 'Someone mentioned you in a comment',
	'someone_assigned_you' => 'Someone assigned you a task',
	'checkout_comment' => 'Checkout Comment',
	'checkout_task' => 'Checkout Task',
	'you_invited_participate' => 'You were invited to participate in :name, to continue please click on the link below. Invitation will expire in 48 hours',

];
