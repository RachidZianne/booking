var REGEX_EMAIL = '([a-z0-9!#$%&\'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&\'*+/=?^_`{|}~-]+)*@' +
                  '(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)';
// Notifications
var _project_title = "";
var _project_privacy = "";
var _project_list = "";
var _project_type = "";

;(function($){
    $.fn.extend({
        donetyping: function(callback,timeout){
            timeout = timeout || 1e3;
            var timeoutReference,
                doneTyping = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                $el.is(':input') && $el.on('keyup keypress',function(e){
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        doneTyping(el);
                    }, timeout);
                }).on('blur',function(){
                    doneTyping(el);
                });
            });
        }
    });
})(jQuery);

/**
 *  Javascript AlphabeticID class
 *  (based on a script by Kevin van Zonneveld <kevin@vanzonneveld.net>)
 *  Author: Even Simon <even.simon@gmail.com>
 **/

var AlphabeticID = {
    index:'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    encode:function(_number){
        if('undefined' == typeof _number){
            return null;
        }
        else if('number' != typeof(_number)){
            throw new Error('Wrong parameter type');
        }

        var ret = '';

        for(var i=Math.floor(Math.log(parseInt(_number))/Math.log(AlphabeticID.index.length));i>=0;i--){
            ret = ret + AlphabeticID.index.substr((Math.floor(parseInt(_number) / AlphabeticID.bcpow(AlphabeticID.index.length, i)) % AlphabeticID.index.length),1);
        }

        return ret.reverse();
    },
    decode:function(_string){
        if('undefined' == typeof _string){
            return null;
        }
        else if('string' != typeof _string){
            throw new Error('Wrong parameter type');
        }

        var str = _string.reverse();
        var ret = 0;

        for(var i=0;i<=(str.length - 1);i++){
            ret = ret + AlphabeticID.index.indexOf(str.substr(i,1)) * (AlphabeticID.bcpow(AlphabeticID.index.length, (str.length - 1) - i));
        }

        return ret;
    },

    bcpow:function(_a, _b){
        return Math.floor(Math.pow(parseFloat(_a), parseInt(_b)));
    }
};


String.prototype.reverse = function(){
    return this.split('').reverse().join('');
};

function handleAxiosErrors(error)
{
    var code = error.response.status;
    if(code == 500)
    {
        swal("Oops", "Something went wrong, please try again in a minute", "error");
    }
    else if(code == 403)
    {
        swal("Oops", "You don't have access to perform this action", "error");
    }
    else if(code == 404)
    {
        swal("Oops", Lang.get('messages.page_not_found'), "error");
    }
    else if(code == 401)
    {
        swal("Oops", "You have been idle for a while and you were logged out, please re-login to continue", "error");
        window.location.href = laroute.route("overview");
    }
}
function addNotification(notification){
    var html = $("#template-notification-item").html();
    Mustache.parse(html);
    var params = {};

    if (notification.related == null){
        notification.related = {};
    }

    if(notification.related.hasOwnProperty('name'))
    {
        params.name = notification.related.name;
    }

    rendered = Mustache.render(html, {
        uri: laroute.route(notification.route,{id:notification.model_id}),
        text:  Lang.get(notification.action,params),
        time: moment(notification.created_at).fromNow(),
        notification_id: notification.id
    });
    if(notification.read == 0){
        rendered = $(rendered).addClass('unread');
    }
    $(".notification-items").prepend(rendered);
    recountUnreadNotifications();
    $(".notification-items").attr("data-cursor",notification.id);
}

function loadPreviewImages() {
    $(".attachment.download-attachment").each(function(ind,value){
        var ext = $(this).attr('data-ext').toLowerCase();
        if(ext == 'png' || ext =='gif' || ext == 'jpg'){
            var attachid = $(this).attr("data-attchid");
            var img = $('<img />',
                {
                    src: laroute.route("tasks.previewattachment",{id:attachid}),
                    class:'attachment-preview'
                })
            var img_hover = $('<img />',
                {
                    src: laroute.route("tasks.previewattachmentmed",{id:attachid}),
                    class:'attachment-preview-medium'
                });
            $(this).html(img).popover({
                html: true,
                trigger: 'hover',
                placement: 'left',
                content: img_hover,
                container:'.aside',
                animation:false
            }).on('hide.bs.popover', function () {
                $(this).find(".popover").remove();
            });

        }
    });
}

function recountUnreadNotifications() {
    var items = $(".notification-items .dropdown-item.unread");
    var length = items.length;
    if (length == 0){length = null;}
    $(".notifications-count").html(length);
}

function mark_notifications_read(){
        var items = $(".notification-items .dropdown-item.unread");
        var list =  $(items).map(function() { return this.getAttribute('data-notid'); }).get();
        if(list.length > 0)
        {
            axios({
                method:'post',
                url:laroute.route("notifications.mark_read"),
                data:{
                    list: list
                }
            }).then(function(response) {
                setTimeout(function(){
                    $(items).removeClass('unread');
                    recountUnreadNotifications();
                }, 3000);
            });
        }
}

$(document).on("click",".notifications-nav:not(.open) .nav-link",function(){
    mark_notifications_read();
});

$(document).on("click",".tags .tag",function(){
    var tag = $(this).text();
    tag = tag.slice(1);
    window.location.href = laroute.route("tag",{tag: tag});

});

// Once off
axios({
    method:'get',
    url:laroute.route("notifications.get"),
}).then(function(response) {
    var nots = response.data;
    nots = nots.reverse();
    $(".notification-items").attr("data-cursor",0);
    $.each(nots, function(i, item) {
        addNotification(item);
    });
});

function toast(text)
{
        var toast_elm =document.createElement("div");
        $(toast_elm).addClass('metis-snackbar show');
        $(toast_elm).text(text);
        $("body").append($(toast_elm));
        setTimeout(function(){ $(toast_elm).remove(); }, 3000);
}

function mtoast(text)
{
        var toast_elm =document.createElement("div");
        $(toast_elm).addClass('metis-snackbar-big show');
        $(toast_elm).text(text);
        $("body").append($(toast_elm));
        setTimeout(function(){ $(toast_elm).remove(); }, 3000);
}

function start_live_notifications() {
    Poll.start({
        name: "live_notifications",
        start:5000,
        interval: 3000,
        action: function(){
            var cursor = $(".notification-items").attr("data-cursor");
            if(cursor !== 'undefined' && cursor >= 0)
            {
                axios({
                    method:'get',
                    url:laroute.route("notifications.get",{cursor:cursor})
                }).then(function(response) {
                    var nots = response.data;
                    nots = nots.reverse();
                    $.each(nots, function(i, item) {
                        addNotification(item);
                    });
                });
            }
        }
    });
}
start_live_notifications();

// IDLE STUFF
$(function() {
    $( document ).idleTimer(30000);
    // Sleeping
    $( document ).on( "idle.idleTimer", function(event, elem, obj){
        Poll.stop("live_notifications");
    });
    // Waking Up
    $( document ).on( "active.idleTimer", function(event, elem, obj, triggerevent){
        start_live_notifications();
    });


});

$(document).on("click",".delete-submit",function(){
    var form = $(this).parents("form");
    swal({
            title: Lang.get("common.are_you_sure"),
            text: Lang.get("messages.unable_to_restore_del"),
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: Lang.get("common.yes"),
            cancelButtonText: Lang.get("common.cancel"),
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm){
            if (isConfirm) {
                $(form).submit();
            }
            else{
                swal.close();
            }
        });
});

$(document).on("click",".confirm-submit",function(){
    var form = $(this).parents("form");
    swal({
            title: Lang.get("common.are_you_sure"),
            text: Lang.get("messages.are_you_sure_confirm"),
            type: "info",
            showCancelButton: true,
            confirmButtonColor: "#2091c1",
            confirmButtonText: Lang.get("common.yes"),
            cancelButtonText: Lang.get("common.cancel"),
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm){
            if (isConfirm) {
                $(form).submit();
            }
            else{
                swal.close();
            }
        });
});

$(document).on("click",".nightmode-toggle",function(){
    if($("html").hasClass("nightmode"))
    {
        Cookies.set('nightmode', 'off',{ expires: 365 });
        $("html").removeClass("nightmode");
    }
    else{
        Cookies.set('nightmode', 'on',{ expires: 365 });
        $("html").addClass("nightmode");
    }


});

$(document).on("click",".update-privacy",function(){
        var projectid = $(this).attr("data-projectid");
        var list = JSON.parse($(this).attr("data-sharedwith"));
        list = list.join();
        var previous_privacy = $(this).attr("data-privacy");

        choosePrivacy(false,projectid,list,previous_privacy);
});

$(document).on("click",".show-template-file-upload",function(){
    $(this).parents(".sweet-alert").find(".template-file-outer").removeClass('hide');
    $(this).remove()
});

$(document).on("click",".breadcrumb-menu.mobile .btn-open",function(){
    $(this).parent().toggleClass("open");
});

$(document).on("click",".create-project",function(){

    swal({
        title: Lang.get("common.create_project"),
        text: $("#project-choose-type").html(),
        html: true,
        confirmButtonText: Lang.get("common.next"),
        cancelButtonText: Lang.get("common.cancel"),
        showCancelButton: true,
        closeOnConfirm: false,
        animation: "slide-from-top",
        customClass:'privacy-choose'
    },function (e) {
        if(!e){return false;}
        var selected = $(".sweet-alert.visible .project-type-choose .radio:checked");
        if (selected.length == 0) {
            swal.showInputError(Lang.get("messages.choose_project_type"));
            return false
        }

        var project_type = $(selected).val();
        _project_type = project_type;
        if(_project_type == 'template'){
            newTemplateProject();
        }
        else{
            newProject();
        }
    });


});

function newTemplateProject() {
    swal.disableButtons();
    axios({
        method:'post',
        url:laroute.route("projects.loadTemplates"),
    }).then(function(response) {

        var jsondata = response.data;

        var template = $("#project-create-from-tpl").html();
        var html =  document.createElement('div');
        $(html).html(template);
        $.each(jsondata, function (i, value) {
            $(html).find(".select-templates").append($('<option>').text(value).attr('value', i));
        });
        $(html).find(".template-file").addClass("jsFileTpl");
        var tpl = $(html).html();
        swal({
            title: Lang.get("common.are_you_sure"),
            text: tpl,
            html: true,
            confirmButtonText: Lang.get("common.save"),
            cancelButtonText: Lang.get("common.cancel"),
            showCancelButton: true,
            closeOnConfirm: false,
            animation: "slide-from-top",
            customClass: 'privacy-choose'
        }, function (e) {
            if(!e)
            {
                swal.close();
            }
            var selected_template = $(".sweet-alert.visible .select-templates").val();
            var formData = new FormData();
            var hfile = document.querySelector('.jsFileTpl');

            if(hfile.files[0] != undefined)
            {
                var filename = hfile.files[0].name;
                var extension =  filename.split('.').pop();

                if(extension.toLowerCase() != "json")
                {
                        swal.showInputError(Lang.get("messages.invalid_json_file"));
                        return false
                }
                formData.append("file", hfile.files[0]);
                axios.post(laroute.route("projects.createFromTemplate"), formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }).then(function(resp){
                    var project_id = response.data.id;
                    swal(Lang.get("common.completed"), Lang.get("messages.project_was_done"), "success");
                    window.location.href = laroute.route("project",{id: project_id});
                });
            }
            else{
                if(selected_template == "")
                {
                    swal.showInputError(Lang.get("messages.must_sel_tpl"));
                    return false;
                }
                axios({
                    method:'post',
                    url:laroute.route("projects.createFromTemplate"),
                    data: {
                        tpl: selected_template,
                    }
                }).then(function(response) {
                    var project_id = response.data.id;
                    swal(Lang.get("common.completed"), Lang.get("messages.project_was_done"), "success");
                    window.location.href = laroute.route("project",{id: project_id});
                }).catch(function(error)
                {
                });


            }

        });
    }).catch(function (error) {

    });
}

function newProject() {
    swal({
            title: Lang.get("common.new_project"),
            text: Lang.get("common.new_project_title"),
            type: "input",
            confirmButtonText: Lang.get("common.ok"),
            cancelButtonText: Lang.get("common.cancel"),
            showCancelButton: true,
            closeOnConfirm: false,
            animation: "slide-from-top",
            inputPlaceholder: Lang.get("common.new_project_title")
        },
        function(inputValue){
            if (inputValue === false) return false;
            if (inputValue === "") {
                swal.showInputError(Lang.get("messages.req_fields_missing"));
                return false
            }
            _project_title = inputValue;
            choosePrivacy(true);

        });
}

function choosePrivacy(fresh,projectid,list,previous_privacy)
{

    swal({
        title: Lang.get("common.project_privacy"),
        text: $("#project-choose-privacy").html(),
        html: true,
        confirmButtonText: Lang.get("common.next"),
        cancelButtonText: Lang.get("common.cancel"),
        showCancelButton: true,
        closeOnConfirm: false,
        animation: "slide-from-top",
        customClass:'privacy-choose'
    },function (e) {
        if(!e){return false;}
        var selected = $(".sweet-alert.visible .project-privacy-choose .radio:checked");
        if (selected.length == 0) {
            swal.showInputError(Lang.get("messages.choose_project_privacy"));
            return false
        }

        var privacy = $(selected).val();
        _project_privacy = privacy;

        if(privacy == "teams")
        {
            // Choose Teams Swal
            swal({
                title: Lang.get("common.teams"),
                text: $("#project-choose-teams").html(),
                html: true,
                confirmButtonText: Lang.get("common.next"),
                cancelButtonText: Lang.get("common.cancel"),
                showCancelButton: true,
                closeOnConfirm: false,
                customClass:'team-choose',
                animation:false
            },function (e) {
                if(!e){return false;}
                _project_list =  $(".team-choose").find(".sct-select").val();
                if(fresh){
                    createProject(_project_title,_project_privacy,_project_list);
                }
                else{
                    updatePrivacy(projectid,_project_privacy,_project_list)
                }
            });

            var selectbox = $(".team-choose").find(".sct-select");
            if(!fresh && privacy == previous_privacy && list)
            {
                $(selectbox).val(list);
            }
            $(selectbox).selectize({
                plugins: ['remove_button'],
                delimiter: ',',
                persist: false,
                create: false,
                valueField: 'id',
                labelField: 'title',
                options:public_teams,
            });

        }
        else if (privacy == 'users'){
            // Choose users Swal
            swal({
                title: Lang.get("common.users"),
                text: $("#project-choose-teams").html(),
                html: true,
                confirmButtonText: Lang.get("common.next"),
                cancelButtonText: Lang.get("common.cancel"),
                showCancelButton: true,
                closeOnConfirm: false,
                customClass:'team-choose',
                animation:false,
                showLoaderOnConfirm: true
            },function (e) {
                if(!e){return false;}
                _project_list =  $(".team-choose").find(".sct-select").val();
                if(fresh) {
                        createProject(_project_title, _project_privacy, _project_list);
                }else{
                        updatePrivacy(projectid,_project_privacy,_project_list)
                }
            });
            var selectbox = $(".team-choose").find(".sct-select");
            if(!fresh && privacy == previous_privacy && list)
            {
                $(selectbox).val(list);
            }
            $(selectbox).selectize({
                plugins: ['remove_button'],
                delimiter: ',',
                persist: true,
                create: true,
                valueField: 'id',
                labelField: 'name',
                options:public_users,
                searchField: "name",
                render: {
                    item: function(item, escape) {
                        var member =  '<div>' + escape(item.name) ;
                        if(item.hasOwnProperty("type")){
                            member += "<span class='user-type'>" + Lang.get("common.client") + "</span>";
                        }
                        if(item.hasOwnProperty("invite")){
                            member += "<span class='email-type'>" +  Lang.get("common.invite") + "</span>";
                        }
                        member = member + '</div>';
                        return member;
                    },
                    option_create: function(data, escape) {
                        return '<div class="create">Invite <strong>' + escape(data.input) + '</strong>&hellip;</div>';
                    },
                    option: function(item, escape) {
                        var member =  '<div>' + escape(item.name) ;
                        if(item.hasOwnProperty("type")){
                            member += "<span class='user-type-list'>"+ Lang.get("common.client") +"</span>";
                        }
                        member = member + '</div>';
                        return member;
                    }
                },
                load: function(query, callback) {
                if (!query.length) return callback();

                    axios({
                        method:'post',
                        url:laroute.route("client.search"),
                        data: {
                            query: query,
                    }
                    }).then(function(response) {
                        callback(response.data);
                    }).catch(function(error)
                    {
                      callback();
                    });
            },createFilter: function(input) {
                    var match, regex;
                    regex = new RegExp('^' + REGEX_EMAIL + '$', 'i');
                    match = input.match(regex);
                    if (match) return !this.options.hasOwnProperty(match[0]);

                    // name <email@address.com>
                    regex = new RegExp('^([^<]*)\<' + REGEX_EMAIL + '\>$', 'i');
                    match = input.match(regex);
                    if (match) return !this.options.hasOwnProperty(match[2]);

                    return false;
                },
                create: function(input) {
                    if ((new RegExp('^' + REGEX_EMAIL + '$', 'i')).test(input)) {
                        return {id:input, name: input,invite:true};
                }

                    var match = input.match(new RegExp('^([^<]*)\<' + REGEX_EMAIL + '\>$', 'i'));
                    if (match) {
                        return {
                            id : match[2],
                            name  : $.trim(match[1]),
                            invite:true
                        };
                    }
                    return false;
                }
            });
        }
        else{
            if(fresh)
            {
                createProject(_project_title,_project_privacy);
            }
            else{
                updatePrivacy(projectid,_project_privacy,_project_list)
            }
        }


    });
}

function createProject(title,privacy,list)
{
    swal.disableButtons();
    axios({
            method:'post',
            url:laroute.route("projects.create"),
            data: {
                title: title,
                privacy: privacy,
                list: list
            }
        }).then(function(response) {
           var project_id = response.data.id;
            swal(Lang.get("common.completed"), Lang.get("messages.project_was_done"), "success");
            window.location.href = laroute.route("project",{id: project_id});
        }).catch(function(error)
        {
        });
}

function updatePrivacy(project,privacy,list)
{
    swal.disableButtons();
    axios({
        method:'post',
        url:laroute.route("projects.updateprivacy"),
        data: {
            project: project,
            privacy: privacy,
            list: list
    }
    }).then(function(response) {
        var project_id = response.data.id;
        swal(Lang.get("common.completed"), Lang.get("messages.modelupdated"), "success");
        window.location.href = laroute.route("project",{id: project_id});
    }).catch(function(error)
    {
    });
}

function krEncodeEntities(s){
    return $j("<div/>").text(s).html();
}
function krDencodeEntities(s){
    return $j("<div/>").html(s).text();
}

function shortcut_newproject(){
    $(".create-project").trigger("click");
}

function shortcut_newsection() {
    $(".new-section").trigger("click")
    return false;
}

function listOfFilters() {
    var filtervals = [];
    $('.filter-menu li').map(function(){
        var filter = $(this).attr('data-filter');
        if(filter != undefined){
            filtervals.push(filter);
        }
    });
    return filtervals;
}

function shortcut_nextfilter() {
    var filters = listOfFilters();
    var current_filter = $(".filter-menu").attr("data-current");
    var nextP = filters.indexOf(current_filter) + 1 ;
    if(filters[nextP] == undefined)
    {   // Rotate
        nextP = 0;
    }
    var next_filter = filters[nextP];
    var the_next =  $(".filter-menu [data-filter='"+next_filter+"']");
    mtoast($(the_next).text());
    the_next.trigger("click");
}


function shortcut_composenextsection_right(){
    shortcut_composenextsection('right');
}

function shortcut_composenextsection_left(){
    shortcut_composenextsection('left');
}

function shortcut_composenextsection(direction) {
        var current = $(".quick-task:not(.hide)");
        if(current.length == 0) { return false; }
        var section =  $(current).parents(".section");
        if(direction == 'right'){
            var nextSection = $(section).next(".section")
        }
        else{
            var nextSection = $(section).prev(".section")
        }
        if(nextSection.length == 0)
        {
            return false;
        }
        var current_qt = $(section).find(".task-section-newtask");
        var future_qt = $(nextSection).find(".task-section-newtask");
        $(future_qt).replaceWith(current_qt.clone());
        resetTaskBox(section);
        $(current_qt).find('.new-task-label').removeClass('hide');
        $(current_qt).find(".quick-task").addClass('hide');
        $(current_qt).find(".quick-task").removeClass('error');
        $(nextSection).find('.comment-text').focus();
        apply_popover();

}

function shortcut_togglenightmode() {
    $(".nightmode-toggle").first().trigger("click");
}

function shortcut_aside_ticktask() {
    $(":not(.aside-menu-hidden) .aside .task-checkbox").first().trigger("click");
}

function shortcut_aside_close() {
    $(":not(.aside-menu-hidden) .aside .close-button").first().trigger("click");
}

function shortcut_aside_refresh() {
    $(":not(.aside-menu-hidden) .aside .refresh-task-button").first().trigger("click");
}

function shortcut_aside_search() {
    $(":not(.aside-menu-hidden) .aside .search-task-button").first().trigger("click");
}

Mousetrap.bind(['option+shift+s'], shortcut_newsection);
Mousetrap.bind(['option+shift+f'], shortcut_nextfilter);
Mousetrap.bind(['option+shift+]'], shortcut_composenextsection_right);
Mousetrap.bind(['option+shift+['], shortcut_composenextsection_left);
Mousetrap.bind(['option+shift+t'], shortcut_newproject);
Mousetrap.bind(['option+shift+n'], shortcut_togglenightmode);

Mousetrap.bind(['option+shift+d'], shortcut_aside_ticktask);
Mousetrap.bind(['option+shift+q'], shortcut_aside_close);
Mousetrap.bind(['option+shift+a'], shortcut_aside_refresh);
Mousetrap.bind(['option+shift+c'], shortcut_aside_search);

Mousetrap.bind('up up down down left right left right enter', function() {
    console.log('debugging..');
    $(".section").css("position",'relative');
    $("[data-sectionid]").each(function(e){
        var div = $("<div/>").css({
            'font-size' : '12px',
            'position' : 'absolute',
            'padding' : '3px 5px',
            'background' : '#000000',
            'color': '#ffffff'
        }).text("SID: "+ $(this).attr("data-sectionid"));
        $(this).prepend(div);
    });
    $(".task-item-wrapper").css("position",'relative');
    $(".task-item-wrapper[data-taskid]").each(function(e){
        var div = $("<div/>").css({
            'font-size' : '12px',
            'position' : 'absolute',
            'padding' : '3px',
            'background' : '#5bc0de',
            'color': '#ffffff',
            'right': '0'
        }).text("TID: "+ $(this).attr("data-taskid"));
        $(this).prepend(div);
    });
});

/* On init */
$(document).on("click",".openkeyboardsc",function(){
    $("#keyboard_shortcuts").modal('show');
});

$(document).on("ready",function(){
    $('[rel="tooltip"],[data-rel="tooltip"]').tooltip({"placement":"top",delay: { show: 400, hide: 200 }});
});

// dev
function dd(obj) {
    return console.log(obj);
}