(function () {

    var laroute = (function () {

        var routes = {

            absolute: false,
            rootUrl: 'http://localhost',
            routes : [{"host":null,"methods":["GET","HEAD"],"uri":"\/","name":"overview","action":"App\Http\Controllers\HomeController@overview"},{"host":null,"methods":["GET","HEAD"],"uri":"tag\/{tag}","name":"tag","action":"App\Http\Controllers\HomeController@tag"},{"host":null,"methods":["GET","HEAD"],"uri":"permalink\/task\/{alphaid}","name":"permalink.task","action":"App\Http\Controllers\HomeController@permalinkTask"},{"host":null,"methods":["GET","HEAD"],"uri":"permalink\/comment\/{alphaid}","name":"permalink.comment","action":"App\Http\Controllers\HomeController@permalinkComment"},{"host":null,"methods":["POST"],"uri":"client\/search","name":"client.search","action":"App\Http\Controllers\HomeController@clientSearch"},{"host":null,"methods":["GET","HEAD"],"uri":"tasks\/comments\/preview\/small\/attachment\/{id?}","name":"tasks.previewattachment","action":"App\Http\Controllers\TaskController@previewAttachment"},{"host":null,"methods":["GET","HEAD"],"uri":"tasks\/comments\/preview\/medium\/attachment\/{id?}","name":"tasks.previewattachmentmed","action":"App\Http\Controllers\TaskController@previewAttachmentMedium"},{"host":null,"methods":["GET","HEAD"],"uri":"tasks\/comments\/preview\/custom\/attachment\/{id?}","name":"tasks.previewattachmentcust","action":"App\Http\Controllers\TaskController@previewAttachmentCustom"},{"host":null,"methods":["GET","HEAD"],"uri":"media\/avatar\/{id?}","name":"avatar","action":"App\Http\Controllers\MediaController@avatar"},{"host":null,"methods":["GET","HEAD"],"uri":"project\/{id}","name":"project","action":"App\Http\Controllers\ProjectController@view"},{"host":null,"methods":["POST"],"uri":"projects\/create","name":"projects.create","action":"App\Http\Controllers\ProjectController@createProject"},{"host":null,"methods":["POST"],"uri":"projects\/update-privacy","name":"projects.updateprivacy","action":"App\Http\Controllers\ProjectController@updatePrivacy"},{"host":null,"methods":["POST"],"uri":"projects\/delete","name":"projects.delete","action":"App\Http\Controllers\ProjectController@deleteProject"},{"host":null,"methods":["POST"],"uri":"projects\/rename","name":"projects.rename","action":"App\Http\Controllers\ProjectController@renameProject"},{"host":null,"methods":["POST"],"uri":"projects\/templates\/actions","name":"projects.tplactions","action":"App\Http\Controllers\ProjectController@TemplateactionProject"},{"host":null,"methods":["POST"],"uri":"projects\/loadTemplates","name":"projects.loadTemplates","action":"App\Http\Controllers\ProjectController@loadTemplates"},{"host":null,"methods":["POST"],"uri":"projects\/createFromTemplate","name":"projects.createFromTemplate","action":"App\Http\Controllers\ProjectController@createFromTemplate"},{"host":null,"methods":["GET","HEAD"],"uri":"projects\/files\/{id}","name":"projects.files","action":"App\Http\Controllers\ProjectController@files"},{"host":null,"methods":["GET","HEAD"],"uri":"projects\/progress\/{id}","name":"projects.progress","action":"App\Http\Controllers\ProjectController@progress"},{"host":null,"methods":["GET","HEAD"],"uri":"notifications\/get","name":"notifications.get","action":"App\Http\Controllers\NotificationController@getLatest"},{"host":null,"methods":["GET","HEAD"],"uri":"notifications\/task\/view\/{id?}","name":"notifications.task_view","action":"App\Http\Controllers\NotificationController@redirectTask"},{"host":null,"methods":["GET","HEAD"],"uri":"notifications\/task\/comment\/{id?}","name":"notifications.task_comment","action":"App\Http\Controllers\NotificationController@redirectTaskComment"},{"host":null,"methods":["POST"],"uri":"notifications\/read","name":"notifications.mark_read","action":"App\Http\Controllers\NotificationController@markRead"}],
            prefix: '',


            route : function (name, parameters, route) {
                route = route || this.getByName(name);

                if ( ! route ) {
                    return undefined;
                }

                return this.toRoute(route, parameters);
            },

            setRootUrl : function (url) {
                this.rootUrl = url;
            },

            url: function (url, parameters) {
                    parameters = parameters || [];

                    var uri = url + '/' + parameters.join('/');

                    return this.getCorrectUrl(uri);
                },

            toRoute : function (route, parameters) {
                var uri = this.replaceNamedParameters(route.uri, parameters);
                var qs  = this.getRouteQueryString(parameters);

                if (this.absolute && this.isOtherHost(route)){
                    return "//" + route.host + "/" + uri + qs;
                }
                var url = this.getCorrectUrl(uri + qs);
                var fullUrl = this.rootUrl + url;
                return fullUrl;
            },

            isOtherHost: function (route){
                return route.host && route.host != window.location.hostname;
            },

            replaceNamedParameters : function (uri, parameters) {
                uri = uri.replace(/\{(.*?)\??\}/g, function(match, key) {
                    if (parameters.hasOwnProperty(key)) {
                        var value = parameters[key];
                        delete parameters[key];
                        return value;
                    } else {
                        return match;
                    }
                });

                // Strip out any optional parameters that were not given
                uri = uri.replace(/\/\{.*?\?\}/g, '');

                return uri;
            },

            getRouteQueryString : function (parameters) {
                var qs = [];
                for (var key in parameters) {
                    if (parameters.hasOwnProperty(key)) {
                        qs.push(key + '=' + parameters[key]);
                    }
                }

                if (qs.length < 1) {
                    return '';
                }

                return '?' + qs.join('&');
            },

            getByName : function (name) {
                for (var key in this.routes) {
                    if (this.routes.hasOwnProperty(key) && this.routes[key].name === name) {
                        return this.routes[key];
                    }
                }
            },

            getByAction : function(action) {
                for (var key in this.routes) {
                    if (this.routes.hasOwnProperty(key) && this.routes[key].action === action) {
                        return this.routes[key];
                    }
                }
            },

            getCorrectUrl: function (uri) {
                var url = this.prefix + '/' + uri.replace(/^\/?/, '');

                if ( ! this.absolute) {
                    return url;
                }

                return this.rootUrl.replace('/\/?$/', '') + url;
            }
        };

        var getLinkAttributes = function(attributes) {
            if ( ! attributes) {
                return '';
            }

            var attrs = [];
            for (var key in attributes) {
                if (attributes.hasOwnProperty(key)) {
                    attrs.push(key + '="' + attributes[key] + '"');
                }
            }

            return attrs.join(' ');
        };

        var getHtmlLink = function (url, title, attributes) {
            title      = title || url;
            attributes = getLinkAttributes(attributes);

            return '<a href="' + url + '" ' + attributes + '>' + title + '</a>';
        };

        return {
            // Generate a url for a given controller action.
            // laroute.action('HomeController@getIndex', [params = {}])
            action : function (name, parameters) {
                parameters = parameters || {};

                return routes.route(name, parameters, routes.getByAction(name));
            },

            // Generate a url for a given named route.
            // laroute.route('routeName', [params = {}])
            route : function (route, parameters) {
                parameters = parameters || {};

                return routes.route(route, parameters);
            },

            // Generate a fully qualified URL to the given path.
            // laroute.route('url', [params = {}])
            url : function (route, parameters) {
                parameters = parameters || {};

                return routes.url(route, parameters);
            },

            // Generate a html link to the given url.
            // laroute.link_to('foo/bar', [title = url], [attributes = {}])
            link_to : function (url, title, attributes) {
                url = this.url(url);

                return getHtmlLink(url, title, attributes);
            },

            // Generate a html link to the given route.
            // laroute.link_to_route('route.name', [title=url], [parameters = {}], [attributes = {}])
            link_to_route : function (route, title, parameters, attributes) {
                var url = this.route(route, parameters);

                return getHtmlLink(url, title, attributes);
            },

            // Generate a html link to the given controller action.
            // laroute.link_to_action('HomeController@getIndex', [title=url], [parameters = {}], [attributes = {}])
            link_to_action : function(action, title, parameters, attributes) {
                var url = this.action(action, parameters);

                return getHtmlLink(url, title, attributes);
            },

            // Reset the rootUrl value
            // laroute.set_root_url('url')
            set_root_url : function(url) {
                if (typeof url === "undefined" || !url) {
                    return;
                }
                routes.setRootUrl(url);
            },

        };

    }).call(this);

    /**
     * Expose the class either via AMD, CommonJS or the global object
     */
    if (typeof define === 'function' && define.amd) {
        define(function () {
            return laroute;
        });
    }
    else if (typeof module === 'object' && module.exports){
        module.exports = laroute;
    }
    else {
        window.laroute = laroute;
    }

}).call(this);

