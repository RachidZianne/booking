<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> <?php echo e(trans('common.menu')); ?> </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="<?php echo e(route("profile")); ?>"><i class="fa fa-user"></i> <?php echo e(trans('common.profile')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("profile_changepw")); ?>"><i class="fa fa-lock"></i> <?php echo e(trans('common.change_password')); ?></a>
        </div>
    </li>
</ol>