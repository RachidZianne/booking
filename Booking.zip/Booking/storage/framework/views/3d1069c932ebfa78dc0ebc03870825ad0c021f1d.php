<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(trans('common.api')); ?>

                        </div>
                        <div class="card-block">
                            <div class="card-block">

                                <div class="form-group row">
                                    <div class="col-md-4 form-control-label"><?php echo e(trans('admin.reset_api_token')); ?>

                                    </div>

                                    <?php if(!empty(Settings::gets("api_key"))): ?>
                                        <div class="col-md-8">
                                        <input type='text' class="form-control apikey" name="api" value="<?php echo e(Settings::gets("api_key")); ?>" readonly="readonly"/>
                                        <p class="help-text"><i class="fa fa-lock"></i> <?php echo e(trans('admin.token_privacy')); ?></p>

                                            <div class="col-md-4 form-control-label">
                                            </div>
                                            <div class="col-md-8">
                                                <div class="pt-3">
                                                    <form action="<?php echo e(route("admin.api_regen")); ?>" method="POST" class="inline-form">
                                                        <button type="button" class="confirm-submit btn btn-secondary" id="regen_token"><?php echo e(trans('admin.regenerate_token')); ?></button>
                                                        <?php echo e(csrf_field()); ?>

                                                    </form>
                                                    <form action="<?php echo e(route("admin.api_delete")); ?>" method="POST" class="inline-form">
                                                        <button type="button" class="delete-submit btn btn-outline-danger"><?php echo e(trans('common.disable')); ?></button>
                                                        <?php echo e(csrf_field()); ?>

                                                    </form>
                                                </div>

                                            </div>

                                        </div>
                                              </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <div class="form-group row">
                                                    <div class="col-md-8 form-control-label"><?php echo e(trans('admin.enable_oauth')); ?>

                                                        <p class="help-text"><?php echo e(trans('admin.enable_oauth_msg')); ?></p>
                                                    </div>
                                                    <div class="col-md-3">

                                                        <form action="<?php echo e(route("admin.oauth_toggle")); ?>" method="POST" class="inline-form">
                                                            <?php if(Settings::gets("enable_oauth")): ?>
                                                                <button type="submit" class="btn-outline-warning btn"><?php echo e(trans('common.disable')); ?></button>
                                                            <?php else: ?>
                                                                <button type="button" class="confirm-submit btn btn-primary"><?php echo e(trans('common.enable')); ?></button>
                                                            <?php endif; ?>
                                                            <?php echo e(csrf_field()); ?>

                                                        </form>

                                                    </div>
                                                    <div class="col-md-1">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    <?php else: ?>
                                        <?php $__env->startSection("enable_api"); ?>
                                        <div class="col-md-8">
                                              <form action="<?php echo e(route("admin.api_regen")); ?>" method="POST" class="inline-form">
                                                <button type="button" class="confirm-submit btn btn-primary"><?php echo e(trans('common.enable')); ?></button>
                                                <?php echo e(csrf_field()); ?>

                                            </form>
                                        </div>
                                    </div>
                            <?php $__env->appendSection(); ?>
                                    <?php endif; ?>
                            <?php echo $__env->yieldContent("enable_api"); ?>

                                </div>








                                <!--/.row-->
                            </div>
                        </div>
                    </div>

                </div>

            </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">
        $(document).ready(function() {

            $(document).on("key")

        });
    </script>

<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>