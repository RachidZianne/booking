<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.profile", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("profile_save")); ?>">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> <?php echo e(trans('common.profile')); ?>

                    </div>
                    <div class="card-block">
                        <div class="card-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.name')); ?></label>
                                        <input type="text" class="form-control" name="name" placeholder="<?php echo e(trans('common.name')); ?>" value="<?php echo e(Auth::user()->name); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.email')); ?></label>
                                        <input type="email" class="form-control" name="email" placeholder="<?php echo e(trans('common.email_address')); ?>"  value="<?php echo e(Auth::user()->email); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.language')); ?></label>
                                        <select name="language" class="form-control">
                                                <option value="0">Default</option>
                                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($language->code); ?>" <?php if($language->code == $language_selected): ?> selected <?php endif; ?>><?php echo e($language->language); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.avatar')); ?></label>
                                        <div class="row">
                                            <div class="col-md-3 col-lg-2">
                                              <img src="<?php echo e(route('avatar',Auth::id())); ?>" class="avatar avatar-lg">
                                            </div>
                                            <div class="col-md-9 col-lg-8">
                                            <input type="file" class="form-control col-md-9" name="avatar">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--/.row-->


                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <?php echo e(csrf_field()); ?>

    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>