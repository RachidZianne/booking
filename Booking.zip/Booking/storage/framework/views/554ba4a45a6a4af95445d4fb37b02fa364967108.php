<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.users", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-users"></i> <?php echo e(trans('common.teams')); ?>

                </div>
                <div class="card-block">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th><?php echo e(trans('common.id')); ?></th>
                            <th colspan="2"><?php echo e(trans('common.team')); ?></th>
                            <th><?php echo e(trans('common.action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                <td width="80"><?php echo e($team->id); ?></td>
                                 <td colspan="2">
                                     <?php echo e($team->title); ?>

                                 </td>
                                <td width="200">
                                    <a  class="btn btn-sm btn-secondary" href="<?php echo e(route("user.team.edit",$team)); ?>"><i class="fa fa-edit"></i> <?php echo e(trans('common.edit')); ?> </a>
                                    <form method="POST" action="<?php echo e(route("user.team.delete")); ?>" class="inline-form">
                                        <input type="hidden" name="model_id" value="<?php echo e($team->id); ?>"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> <?php echo e(trans('common.delete')); ?> </a>
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($teams->links()); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>