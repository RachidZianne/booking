<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> <?php echo e(trans('common.menu')); ?> </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="<?php echo e(route("admin.insight.teams")); ?>"><i class="fa fa-user-circle"></i> <?php echo e(trans('common.teams')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.insight.projects")); ?>"><i class="icon-folder-alt"></i> <?php echo e(trans('common.projects')); ?></a>
        </div>
    </li>
</ol>