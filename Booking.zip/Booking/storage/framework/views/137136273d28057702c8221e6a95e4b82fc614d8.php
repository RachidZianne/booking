<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.users", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("user.team.store")); ?>">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> <?php echo e(isset($team->title) ? $team->title : trans("common.team")); ?>

                    </div>
                    <div class="card-block">
                        <div class="card-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.title')); ?></label>
                                        <input type="text" class="form-control" name="title" placeholder="<?php echo e(trans('common.title')); ?>" value="<?php echo e(isset($team->title) ? $team->title : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            <?php if($team): ?>
                                <input type="hidden" name="team_id" value="<?php echo e($team->id); ?>" />
                            <?php endif; ?>
                            <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <?php echo e(csrf_field()); ?>

    </form>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>