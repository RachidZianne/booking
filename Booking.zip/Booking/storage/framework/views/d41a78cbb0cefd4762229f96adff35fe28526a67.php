<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
            <?php if(Session::has("rate")): ?>
                <?php echo $__env->make("fragments.rate_metis", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-2 col-lg-2"></div>
                <div class="col-lg-8 col-md-8">

                    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("update.check")); ?>">

                        <div class="card">
                            <div class="card-header">
                                <i class="fa fa-leaf"></i> Verify Purchase
                            </div>
                            <div class="card-block">
                                <div class="card-block">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="name">Purchase Code</label>
                                                <input type="text" class="form-control" name="code" placeholder="e.g: 9ad2ff5d-b854-3jd4-73a0-0bd1e5701337" autocomplete="off">
                                                <?php if(!Config::get("hide_metis_label")): ?>
                                                 <p class="help-text">This will attempt to send your purchase code to Metis Server for verification using Envato API</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!--/.row-->
                                </div>
                                <div class="form-actions">
                                    <button type="submit" class="btn btn-success">Verify</button>
                                </div>
                            </div>
                        </div>
                        <?php echo e(csrf_field()); ?>

                    </form>

                </div>

            </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>

<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>