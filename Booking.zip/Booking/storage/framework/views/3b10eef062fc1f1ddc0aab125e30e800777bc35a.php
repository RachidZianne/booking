<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("admin.map_save")); ?>">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(trans('common.location_sharing_settings')); ?>

                        </div>
                        <div class="card-block">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('common.location_sharing')); ?></label> <br />
                                            <label class="switch switch-text switch-primary">
                                                <input type="checkbox" name="location_enabled" class="switch-input" <?php if(Settings::gets("location_enabled")  == 1): ?> checked <?php endif; ?>>
                                                <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                                <span class="switch-handle"></span>
                                            </label>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('admin.gmaps_api_key')); ?> <a class="btn btn-xxsmall btn-secondary" href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank"><?php echo e(trans('common.get_key')); ?></a> </label>
                                            <input type="text" class="form-control" name="location_js_api" placeholder="<?php echo e(trans('admin.gmaps_api_key')); ?>" value="<?php echo e(Settings::gets("location_js_api")); ?>">
                                            <p class="help-block text-danger"><?php echo e(trans('common.required')); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('admin.gmaps_embed_key')); ?> <a class="btn btn-xxsmall btn-secondary" href="https://developers.google.com/maps/documentation/embed/get-api-key" target="_blank"><?php echo e(trans('common.get_key')); ?></a> </label>
                                            <input type="text" class="form-control" name="location_embed_api" placeholder="<?php echo e(trans('admin.gmaps_embed_key')); ?>" value="<?php echo e(Settings::gets("location_embed_api")); ?>">
                                            <p class="help-block"><?php echo e(trans('admin.gmaps_embed_key_msg')); ?></p>
                                        </div>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php echo e(csrf_field()); ?>

        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>