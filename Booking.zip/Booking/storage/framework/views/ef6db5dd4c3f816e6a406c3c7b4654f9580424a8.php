<div class="row project-head">
    <div class="col-md-7">
        <div class="project-detail">
            <h4 class="title"><?php echo e($team->title); ?></h4>
        </div>
    </div>
</div>



<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">

    </script>
<?php $__env->appendSection(); ?>