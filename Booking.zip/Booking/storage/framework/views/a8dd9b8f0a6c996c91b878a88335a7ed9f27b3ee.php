<?php $__env->startSection("content"); ?>
<h3>That's it!</h3>

<h4>You can find your Application at the following link</h4>
<a class="btn btn-primary" href="<?php echo e(route("home")); ?>"><?php echo e(route("overview")); ?></a>


<?php $__env->stopSection(); ?>

<?php $__env->startSection("extrajs"); ?>

<?php $__env->appendSection(); ?>
<?php echo $__env->make("install.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>