<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Metis Installer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/installer.css")); ?>">
    <?php echo $__env->yieldContent("extracss"); ?>
</head>
<style>
    body{
        background: #F9F9F9;
    }
    .container-fluid.installer{
        padding-top:50px;
    }
    .logo{
        display: block;
        margin: 0 auto;
        text-align: center;
        padding:10px;
    }
    .container-fluid.installer>.content-i{
        margin: 0 auto;
        text-align: center;
    }
    .container-fluid.installer>.content-i>table.table{
        width: 35%;
        margin: 1em auto;
    }
    .green{
        color:#21BA45!important
    }
    .red{
        color:#DB2828!important
    }
    .content{
        display: inline;
    }
    form.cform{
        background: white;
        padding: 50px;
        margin:10px auto;
        width:33%;
        border-radius:3px;
    }
    .feedback-msg{
        padding-top:10px;
        width: 33%;
        margin: 0 auto;
    }
    .help-block{
        text-align: left;
        color: #797979;
    }


</style>
<body>
<div class="container-fluid installer">
        <div class="logo">
            <img src="<?php echo e(asset("assets/img/firecrown.png")); ?>" />
        </div>
    <div class="content-i">
        <?php if(session("success") || session("error")): ?>
            <div class="row feedback-msg">
                <div class="col-md-12">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php echo $__env->yieldContent("content"); ?>
    </div>
</div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php echo $__env->yieldContent("extrajs"); ?>
</html>