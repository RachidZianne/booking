<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.users", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="row">

            <div class="col-lg-6 col-md-6">
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("user.store")); ?>">

                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-user"></i> <?php echo e(isset($user->name) ? $user->name : 'User'); ?>

                    </div>
                    <div class="card-block">
                        <div class="card-block">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.name')); ?></label>
                                        <input type="text" class="form-control" name="name" placeholder="<?php echo e(trans('common.name')); ?>" value="<?php echo e(isset($user->name) ? $user->name : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.email')); ?></label>
                                        <input type="email" class="form-control" name="email" placeholder="<?php echo e(trans('common.email_address')); ?>"  value="<?php echo e(isset($user->email) ? $user->email : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.new_password')); ?></label>
                                        <input type="text" class="form-control" name="password" placeholder="<?php echo e(trans('common.new_password')); ?>" autocomplete="off">
                                        <span class="help-block text-muted text-smaller"><?php echo e(trans('common.field_visible')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(trans('common.avatar')); ?></label>
                                        <div class="row">
                                            <div class="col-md-3 col-lg-2">
                                              <img src="<?php echo e(route('avatar',$user)); ?>" class="avatar avatar-lg">
                                            </div>
                                            <div class="col-md-9 col-lg-8">
                                            <input type="file" class="form-control col-md-9" name="avatar">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!--/.row-->
                            <div class="row">
                                <div class="col-md-12">
                                    <hr class="divider" />
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-sm-12">

                                    <div class="form-group">
                                        <label><?php echo e(trans('common.user_type')); ?></label>
                                        <select class="form-control" name="user_type" id="usertype">
                                            <option value="staff" <?php 
            if( isset($user->type) && $user->type == 'staff' ) echo 'selected';          
             ?>><?php echo e(trans('common.staff')); ?></option>
                                            <option value="client" <?php 
            if( isset($user->type) && $user->type == 'client' ) echo 'selected';          
             ?>><?php echo e(trans('common.client')); ?></option>
                                            <option value="root" <?php 
            if( isset($user->type) && $user->type == 'root' ) echo 'selected';          
             ?>><?php echo e(trans('common.administrator')); ?></option>
                                        </select>
                                    </div>
                                    <div id="utteams">
                                        <div class="form-group">
                                            <label><?php echo e(trans('common.teams')); ?></label>
                                            <input type="text" class="form-control" id="user_teams" name="teams" value="<?php if(isset($user->teams)): ?><?php echo e($user->teams->pluck('id')->implode(',')); ?><?php endif; ?>">
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <!--/.row-->


                            <!--/.row-->
                        </div>
                        <div class="form-actions">
                            <?php if($user): ?>
                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>" />
                            <?php endif; ?>
                            <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                        </div>
                    </div>
                </div>
                    <?php echo e(csrf_field()); ?>

                </form>

            </div>
            <?php if(!isset($user)): ?>
                <div class="col-lg-6 col-md-6">
                    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('user.send_invite')); ?>">

                        <div class="card">
                            <div class="card-header">
                                <i class="fa fa-user-plus"></i> <?php echo e(trans('common.invite_user')); ?>

                            </div>
                            <div class="card-block">
                                <div class="card-block">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="name"><?php echo e(trans('common.email')); ?></label>
                                                <input type="email" class="form-control" name="email" placeholder="<?php echo e(trans('common.email_address')); ?>"  value="">
                                                <p class="help-text"><?php echo e(trans('messages.pref_page_client_type')); ?> </p>
                                            </div>
                                        </div>
                                    </div>

                                    <!--/.row-->
                                </div>
                                <div class="form-actions">
                                    <button type="submit" class="btn btn-success"><?php echo e(trans('common.send_invite')); ?></button>
                                </div>
                            </div>
                        </div>
                        <?php echo e(csrf_field()); ?>

                    </form>

                </div>
            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">
        var teams = <?php echo $teams->toJson(); ?>;

        $("#user_teams").selectize({
            plugins: ['remove_button'],
            delimiter: ',',
            persist: false,
            valueField: 'id',
            labelField: 'title',
            options:teams,
            create:false
        });
        $("#user_type").selectize();

        $(document).on("change","#usertype",function(e)
        {
            var type = $(this).val();
            if(type == 'staff')
            {
                $("#utteams").removeClass('hide');
            }
            else{
                $("#utteams").addClass('hide');
            }
        });

        $("#usertype").trigger("change");

    </script>
<?php $__env->appendSection(); ?>


<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>