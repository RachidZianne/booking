<!DOCTYPE html>
<html lang="en" <?php if((Cookie::get("nightmode") == 'on')): ?> class="nightmode" <?php endif; ?>>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(Settings::gets("site_name")); ?></title>
    <?php echo $__env->make("misc.common_css", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("misc.common_js", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent("extra_css"); ?>
    <?php echo $__env->renderWhen((Config::get("metis.demo") == 1),"fragments.demo_frag", array_except(get_defined_vars(), array('__data', '__path'))); ?>
</head>

<body class="firecamp metis-custom app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden <?php echo $__env->yieldContent("extra_body_class"); ?> <?php if(Settings::gets("fullscreen_mode") == 1): ?> full-screen-aside <?php endif; ?>">
    <header class="app-header navbar">
        <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button"><i class="icon-menu"></i></button>
        <a class="navbar-brand" href="<?php echo e(route("overview")); ?>">
            <div class="fc-logo">
                <img src="<?php echo e(route("logo")); ?>">
            </div>
        </a>
        <ul class="nav navbar-nav d-md-down-none" id="navbar_teams">
            <li class="nav-item">
                <a class="nav-link navbar-toggler sidebar-toggler" href="#"><i class="icon-menu"></i></a>
            </li>
            <li class="nav-item px-3">
                <a class="nav-link" href="<?php echo e(route("overview")); ?>"><?php echo e(trans("common.overview")); ?></a>
            </li>
            <?php $__currentLoopData = Auth::user()->getTeams(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item px-3">
                <a class="nav-link" href="<?php echo e(route("team",$team->id)); ?>"><?php echo e($team->title); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <ul class="nav navbar-nav ml-auto nav-user-action">
            <li class="nav-item desktop-only">
                <a class="nav-link nightmode-icon nightmode-toggle" href="#"><i class="fa fa-moon-o"></i></a>
            </li>
            <li class="nav-item dropdown notifications-nav">
                <a class="nav-link nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-globe fa-2x"></i><span class="badge badge-pill badge-danger notifications-count"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header text-center">
                        <strong><?php echo e(trans('common.notifications')); ?></strong>
                    </div>
                    <div class="notification-items"></div>
                </div>
            </li>
            <li class="nav-item dropdown name-nav">
                <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <span class="d-md-down-none"><?php echo e(Auth::user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header text-center">
                        <strong><?php echo e(trans('common.account')); ?></strong>
                    </div>

                    <a class="dropdown-item" href="<?php echo e(route("profile")); ?>"><i class="fa fa-user"></i> <?php echo e(trans('common.profile')); ?></a>
                    <?php if(Auth::user()->isStaff()): ?>
                    <a class="dropdown-item" href="<?php echo e(route("profile.templates")); ?>"><i class="fa fa-folder"></i> <?php echo e(trans('common.profile')); ?></a>
                    <?php endif; ?>
                    <a class="dropdown-item mobile-only nightmode-toggle" href="#"><i class="fa fa-moon-o"></i><?php echo e(trans('common.night_mode')); ?></a>

                <?php if(Auth::user()->isAdmin()): ?>
                    <div class="dropdown-header text-center">
                        <strong><?php echo e(trans('common.administrator')); ?></strong>
                    </div>
                    <a class="dropdown-item" href="<?php echo e(route("admin.insight.teams")); ?>"><i class="fa fa-bar-chart"></i> <?php echo e(trans('common.insights')); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route("user.index")); ?>"><i class="fa fa-users"></i> <?php echo e(trans('common.users_and_teams')); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route("admin.history")); ?>"><i class="fa fa-file"></i> <?php echo e(trans('common.history')); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route("admin.general")); ?>"><i class="fa fa-cog"></i> <?php echo e(trans('common.metis_settings')); ?></a>
                    <div class="divider"></div>
                    <?php endif; ?>
                    <a class="dropdown-item" href="<?php echo e(route("logout")); ?>"><i class="fa fa-lock"></i> <?php echo e(trans('common.logout')); ?></a>
                </div>
            </li>
            <li class="nav-item d-md-down-none">
            </li>
        </ul>
    </header>

    <div class="app-body">
        <div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
                    <li class="nav-title">
                        <?php echo e(trans('common.dashboard')); ?>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route("overview")); ?>"><i class="icon-home"></i> <?php echo e(trans('common.home')); ?></a>
                    </li>
                    <?php if(Auth::user()->isStaff()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route("selfassigned")); ?>"><i class="icon-notebook"></i> <?php echo e(trans('common.assigned_to_me')); ?></a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route("calendar")); ?>"><i class="icon-calendar"></i> <?php echo e(trans('common.calendar')); ?></a>
                    </li>
                    <li class="nav-title mobile-only-team">
                    <?php echo e(trans('common.teams')); ?>

                    </li>
                    <?php $__currentLoopData = Auth::user()->getTeams(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item mobile-only-team">
                            <a class="nav-link" href="<?php echo e(route("team",$team->id)); ?>"><?php echo e($team->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-title">
                        <?php if(isset($view_type)): ?>
                            <?php if($view_type == 'team'): ?>
                            <?php echo e(trans('common.team_projects')); ?>

                            <?php elseif($view_type == 'project' || $view_type == 'overview'): ?>
                            <?php echo e(trans('common.recent_projects')); ?>

                            <?php else: ?>
                                <?php echo e(trans('common.recent_projects')); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            <?php echo e(trans('common.recent_projects')); ?>

                        <?php endif; ?>
                            <?php if(Auth::user()->isStaff()): ?>
                                <a href="#" class="create-project"><i class="fa fa-plus-circle"></i></a>
                            <?php endif; ?>
                       </li>
                    <?php if(isset($projects) && !empty($projects)): ?>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($project != null): ?>
                            <li class="nav-item project">
                                <a class="nav-link" href="<?php echo e(route("project",$project->id)); ?>"><i class="icon-direction"></i> <?php echo e($project->title); ?></a>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </ul>
            </nav>
        </div>
        <!-- Main content -->
        <main class="main">
            <div class="container-fluid <?php if(Settings::gets("tweaks_stack") == 1): ?> stack-view <?php endif; ?> <?php echo e(isset($layout_type) ? $layout_type : ''); ?><?php echo $__env->yieldContent("view_type"); ?> <?php echo $__env->yieldContent("extra_container_class"); ?>">
                <!-- Breadcrumb -->
                <?php echo $__env->yieldContent("breadcrumb"); ?>
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <div class="alert-heading"><?php echo e(trans('common.error')); ?></div>
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent("content"); ?>
            </div>
            <!-- /.conainer-fluid -->
        </main>
       <?php echo $__env->make('layouts.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

    <?php echo $__env->yieldContent("footer"); ?>
    <?php echo $__env->make('fragments.templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('fragments.aside_templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
<script type="text/javascript">
    var public_users = <?php echo $public_users->toJson(); ?>;
    var most_used_tags = <?php echo App\TaskTag::mostUsed()->pluck('tag.title')->toJson(); ?>;
    var public_teams = <?php echo $public_teams->toJson(); ?>;
    var is_user_admin = <?php echo e((Auth::user()->isAdmin())); ?>;
</script>
<script type="text/javascript">
function airdatepicker_language(){
    <?php if(is_locale_supported("airpicker",App::getLocale())): ?>
    var lang = "<?php echo e(App::getLocale()); ?>";
    <?php else: ?>
    var lang = "en";
    <?php endif; ?>
    return lang;
}

</script>

<?php echo $__env->yieldContent("extra_js"); ?>
</html>