<?php $__env->startSection("content"); ?>
    <form class="cform form-horizontal" method="POST" action="<?php echo e(route("inst1Save")); ?>">
        <h3>Database Installation</h3>
        <div class="form-group">
            <label class="col-sm-2 control-label">Database Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Database Name" name="dbname" value="metis">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">Database Username</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Database Username" name="username">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">Database Password</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Database Password" name="password">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">Host</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Database Host" name="host" value="localhost">
            </div>
        </div>

        <button class="btn btn-success" type="submit">Continue</button>
    </form>

    <p style="color:#a1a1a1;width:33%;margin:0 auto; padding-top:40px;">
        <i class="fa fa-question-circle"></i> P.S: If you faced any issue importing the database you can import the .sql file manually through phpmyadmin then importing file located at <br /> <span class="text-muted"><?php echo e(storage_path("install/metis.sql")); ?></span> , then you can <a href="<?php echo e(route("inst2")); ?>">skip</a> to after database installation and configuring config/database.php file </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("install.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>