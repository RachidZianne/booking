<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("admin.mail_save")); ?>">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(trans('admin.mail_settings')); ?>

                        </div>
                        <div class="card-block">
                            <div class="card-block">


                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo e(trans('admin.mail_driver')); ?></label>
                                    <div class="col-sm-9">
                                        <select class="form-control" name="driver" id="driver">
                                            <option value="sendmail" <?php if(Config::get("mail.driver") == "sendmail"): ?>  selected <?php endif; ?> >PHP Sendmail</option>
                                            <option value="mail" <?php if(Config::get("mail.driver") == "mail"): ?>  selected <?php endif; ?> >PHP Mail</option>
                                            <option value="smtp" <?php if(Config::get("mail.driver") == "smtp"): ?> selected <?php endif; ?> >SMTP</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo e(trans('admin.default_sender')); ?></label>
                                    <div class="col-sm-9">
                                        <input type="email" name="defaultmail" class="form-control" placeholder="<?php echo e(trans('admin.default_sender')); ?>" value="<?php echo e(Config::get("mail.from.address")); ?>">
                                    </div>
                                </div>

                                <div id="smtp_sett">
                                    <div class="form-group">
                                        <div class="p-3 text-muted"><?php echo e(trans('admin.smtp_settings')); ?> </div>
                                        <label class="col-sm-3 control-label"><?php echo e(trans('admin.mail_host')); ?></label>
                                        <div class="col-sm-9">
                                            <input type="text" name="host" class="form-control" placeholder="<?php echo e(trans('admin.mail_host')); ?>" value="<?php echo e(Config::get("mail.host")); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"><?php echo e(trans('admin.mail_username')); ?></label>
                                        <div class="col-sm-9">
                                            <input type="text" name="username" class="form-control" placeholder="<?php echo e(trans('admin.mail_username')); ?>" value="<?php echo e(Config::get("mail.username")); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"><?php echo e(trans('admin.mail_password')); ?></label>
                                        <div class="col-sm-9">
                                            <input type="text" name="password" class="form-control" placeholder="<?php echo e(trans('admin.mail_password')); ?>" value="<?php echo e(Config::get("mail.password")); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"><?php echo e(trans('admin.mail_port')); ?></label>
                                        <div class="col-sm-9">
                                            <input type="text" name="port" class="form-control" placeholder="<?php echo e(trans('admin.mail_port')); ?>" value="<?php echo e(Config::get("mail.port")); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"><?php echo e(trans('admin.host_encryption')); ?></label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="encryption" id="encryption">
                                                <option value="" <?php if(Config::get("mail.encryption") == "tls" || Config::get("mail.encryption") == ""): ?>  selected <?php endif; ?> >TLS/No encryption</option>
                                                <option value="ssl" <?php if(Config::get("mail.encryption") == "ssl"): ?>  selected <?php endif; ?> >SSL</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php echo e(csrf_field()); ?>

        </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#driver").on("change",function(e){
               if($(this).val() == 'smtp'){
                   $("#smtp_sett").show();
               }
               else{
                   $("#smtp_sett").hide();
               }
            });
            $("#driver").trigger("change");
        });
    </script>

<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>