<?php $__env->startSection("content"); ?>
<h3>Welcome to installation</h3>
<h4>Follow the easy steps below to complete your installation</h4>


<table class="ui celled table">
    <thead>
    <tr>
        <th>Name</th>
        <th>Test</th>
        <th>Status</th>
        <th>Notes</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>PHP Version</td>
        <td><?php echo e(PHP_VERSION); ?></td>
        <?php if(version_compare(PHP_VERSION, '5.6.4') >= 0): ?>
            <td class="positive">Approved</td>
            <td>-</td>
        <?php else: ?>
            <td class="negative">Not Approved</td>
            <td>PHP Version must be 5.6.4 or newer</td>
        <?php endif; ?>
    </tr>
    <tr>
        <td>PDO MySQL</td>
        <td>PDO</td>
        <?php if(class_exists('PDO')): ?>
            <td class="positive">Approved</td>
            <td>-</td>
        <?php else: ?>
            <td class="negative">Not Approved</td>
            <td>PDO MySQL Is not installed</td>
        <?php endif; ?>
    </tr>
    <tr>
        <td>OpenSSL </td>
        <td><?php echo e(defined('OPENSSL_VERSION_TEXT')? OPENSSL_VERSION_TEXT : "-"); ?></td>
        <?php if(extension_loaded('openssl')): ?>
            <?php if(OPENSSL_VERSION_NUMBER < 0x1000009f): ?>
                <td class="warning">Warning</td>
                <td class="warning">OpenSSL Must be of version v1.0.1 or greater to support TLS 1.2 <strong>required by PayPal</strong> </td>
            <?php else: ?>
                <td class="positive">Approved</td>
                <td>-</td>
            <?php endif; ?>
        <?php else: ?>
            <td class="negative">Not Approved</td>
            <td>You need to install OpenSSL extension</td>
        <?php endif; ?>
    </tr>
    <tr>
        <td>Mbstring </td>
        <td>Mbstring</td>
        <?php if(extension_loaded('mbstring')): ?>
            <td class="positive">Approved</td>
            <td>-</td>
        <?php else: ?>
            <td class="negative">Not Approved</td>
            <td>You need to install PHP mbstring extension</td>
        <?php endif; ?>
    </tr>
    <tr>
        <td>Tokenizer </td>
        <td>Tokenizer</td>
        <?php if(extension_loaded('tokenizer')): ?>
            <td class="positive">Approved</td>
            <td>-</td>
        <?php else: ?>
            <td class="negative">Not Approved</td>
            <td>You need to install PHP tokenizer extension</td>
        <?php endif; ?>
    </tr>
    <tr>
        <td>Writeable Folders</td>
        <td>
            <div class="ui list">
                <div class="item">
                    <?php $writeableflag = true; ?>
                    <?php if(is_writable(config_path())): ?>
                        <i class="green fa fa-check"></i>
                    <?php else: ?>
                        <?php $writeableflag = false; ?>
                        <i class="red remove circle icon"></i>
                    <?php endif; ?>
                    <div class="content popup" data-content="<?php echo e(config_path()); ?>">
                        Config
                    </div>
                </div>
                <div class="item">
                    <?php if(is_writable(storage_path("/"))): ?>
                        <i class="green fa fa-check"></i>
                    <?php else: ?>
                        <?php $writeableflag = false; ?>
                        <i class="red remove circle icon"></i>
                    <?php endif; ?>
                    <div class="content popup" data-content="<?php echo e(storage_path("/")); ?>">
                        Storage
                    </div>
                </div>

            </div>
        </td>
        <?php if($writeableflag): ?>
            <td class="positive">Approved</td>
            <td>-</td>
        <?php else: ?>
            <td class="negative">Not Approved</td>
            <td>Change permissions to 755 or 77 on unwriteable folder</td>
        <?php endif; ?>
    </tr>

    <tr>
        <td>Public Folder</td>
        <td>-</td>
        <?php if( (stripos(Request::server("REQUEST_URI"),"public")) === false): ?>
            <td class="positive">Approved</td>
            <td>-</td>
        <?php else: ?>
            <td class="negative">Visible</td>
            <td>Public Folder should be a DocumentRoot. <a href="http://www.firecrown.io/s/public">Why?</a> </td>
        <?php endif; ?>
    </tr>

    </tbody>
</table>

<form method="get" action="<?php echo e(route("inst1")); ?>">
    <button class="btn btn-success button" type="submit">
        Start
    </button>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("extrajs"); ?>
    <script type="text/javascript">
        $( document ).ready(function() {




        });

    </script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make("install.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>