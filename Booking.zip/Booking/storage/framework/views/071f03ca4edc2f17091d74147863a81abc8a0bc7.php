<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route("admin.tweaks_save")); ?>" class="form-horizontal">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(trans('common.tweaks')); ?>

                        </div>
                        <div class="card-block">
                            <div class="card-block">
                                <div class="mb-5"><h6><i class="icon-chemistry"></i> <?php echo e(trans('common.experimental')); ?></h6>
                                    <p class="help-text"><?php echo e(trans('messages.some_expert')); ?></p>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-8 form-control-label"><?php echo e(trans('messages.dd_disable')); ?>

                                    <p class="help-text"><?php echo e(trans('messages.dd_disable_msg')); ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="switch switch-text switch-primary">
                                            <input type="checkbox" name="tweaks_ddm" class="switch-input" <?php if(Settings::gets("tweaks_ddm")  == 1): ?> checked <?php endif; ?>>
                                            <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                            <span class="switch-handle"></span>
                                        </label>
                                    </div>
                                </div>



                                <div class="form-group row">
                                    <div class="col-md-8 form-control-label"><?php echo e(trans('messages.stack_sec_view')); ?>

                                    <p class="help-text"><?php echo e(trans('messages.alt_sec_view')); ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="switch switch-text switch-primary">
                                            <input type="checkbox" name="tweaks_stack" class="switch-input" <?php if(Settings::gets("tweaks_stack")  == 1): ?> checked <?php endif; ?>>
                                            <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                            <span class="switch-handle"></span>
                                        </label>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <div class="col-md-8 form-control-label"><?php echo e(trans('messages.fullscreen_mode')); ?>

                                        <p class="help-text"><?php echo e(trans('messages.fullscreen_mode_msg')); ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="switch switch-text switch-primary">
                                            <input type="checkbox" name="fullscreen_mode" class="switch-input" <?php if(Settings::gets("fullscreen_mode")  == 1): ?> checked <?php endif; ?>>
                                            <span class="switch-label" data-on="ON" data-off="OFF"></span>
                                            <span class="switch-handle"></span>
                                        </label>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php echo e(csrf_field()); ?>

        </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">
        $(document).ready(function() {


        });
    </script>

<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>