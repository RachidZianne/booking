<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.project_templates", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-folder"></i> <?php echo e(trans('common.project_templates')); ?>

                </div>
                <div class="card-block">
                    <table class="table table-striped table-responsive">
                        <thead>
                        <tr>
                            <th colspan="2"><?php echo e(trans('common.template')); ?></th>
                            <th class="text-align-right"><?php echo e(trans('common.action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr class="template">
                                 <td colspan="2">
                                     <div class="template-title"> <?php echo e($template->title); ?></div>
                                     <div class="small text-muted">
                                         <?php echo e(trans('common.saved')); ?> <?php echo e($template->created_at->diffForHumans()); ?>

                                     </div>
                                 </td>
                                <td class="text-align-right">
                                    <a class="btn btn-sm btn-secondary template-rename" href="#" data-templateid="<?php echo e($template->id); ?>"><i class="icon-note"></i> <?php echo e(trans('common.rename')); ?> </a>
                                    <a class="btn btn-sm btn-secondary" href="<?php echo e(route("profile.template_download",$template)); ?>"><i class="fa fa-download"></i> <?php echo e(trans('common.download')); ?> </a>
                                    <form method="POST" action="<?php echo e(route("profile.template_delete")); ?>" class="inline-form">
                                        <input type="hidden" name="model_id" value="<?php echo e($template->id); ?>"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> <?php echo e(trans('common.delete')); ?> </a>
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($templates->links()); ?>

                </div>
            </div>
        </div>
    </div>


    <div id="project_template_import" class="hide">
        <div class="popover-body popover-tpl">
            <form action="<?php echo e(route("profile.template_import")); ?>" method="POST" enctype="multipart/form-data">
              <h6><?php echo e(trans('common.import_project_template')); ?></h6>
                <label class="strong-label"><?php echo e(trans('common.project_templates')); ?></label>
                <input type="file" name="file" class="form-control" accept=".json" />
                <div class="row">
                    <div class="col-md-12 mt-3 text-align-right">
                        <button type="submit" class="btn btn-primary"><?php echo e(trans('common.import')); ?></button>
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">
        $(function(){
            $("[data-toggle=popover]").popover({
                html : true,
                content: function() {
                    var content = $(this).attr("data-popover-content");
                    return $(content).html();
                }
            });
        });

        $(document).on("click",".template-rename",function(e){
            var template = $(this).parents(".template");
            var tpl_id = $(this).attr("data-templateid");
            var tpl_title = $(template).find(".template-title").text();

            swal({
                    title: "<?php echo e(trans("common.rename")); ?>",
                    text: tpl_title,
                    type: "input",
                    showCancelButton: true,
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true,
                    inputPlaceholder: "<?php echo e(trans("common.template_title")); ?>"
                },
                function(inputValue){
                    if (inputValue === false) return false;
                    if (inputValue === "") {
                        swal.showInputError("<?php echo e(trans("common.you_need_to_write_something")); ?>");
                        return false
                    }
                    axios({
                        method:'post',
                        url:'<?php echo e(route('profile.template_rename')); ?>',
                        data:{
                            title: inputValue,
                            model_id: tpl_id
                        }
                    }).then(function(response) {
                        $(template).find(".template-title").text(inputValue);
                        swal("<?php echo e(trans("common.completed")); ?>", Lang.get("messages.title_renamed",{title:tpl_title, newtitle:inputValue}), "success");
                    });
                });

        });
    </script>

<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>