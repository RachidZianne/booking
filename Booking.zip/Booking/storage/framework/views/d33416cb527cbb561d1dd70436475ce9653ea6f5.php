<?php $__env->startSection("extra_menu_buttons"); ?>
    <?php if(Auth::id() == $project->user_id || Auth::user()->isAdmin()): ?>
        <a class="btn btn-secondary project-rename" href="#"><i class="icon-note"></i> &nbsp;<span class="btn-title"><?php echo e(trans('common.rename')); ?></span> </a>
        <a class="btn btn-secondary dropdown-toggle project-export" data-projectid="<?php echo e($project->id); ?>" href="#" data-toggle="popover" data-placement="bottom" title="Export Project"><i class="fa fa-level-up"></i> <span class="btn-title"><?php echo e(trans('common.templates')); ?></span> </a>
        <form class="inline-form" action="<?php echo e(route("projects.archive")); ?>" method="POST">
            <?php if($project->archived == 1): ?>
                <a class="btn btn-secondary confirm-submit text-warning" href="#"><i class="icon-arrow-up-circle"></i> &nbsp; <span class="btn-title"><?php echo e(trans('common.restore')); ?></span> </a>
            <?php else: ?>
                <a class="btn btn-secondary confirm-submit" href="#"><i class="icon-arrow-down-circle"></i> <span class="btn-title"><?php echo e(trans('common.archive')); ?></span> </a>
            <?php endif; ?>
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="model_id" value="<?php echo e($project->id); ?>" />
        </form>
        <form class="inline-form" action="<?php echo e(route("projects.delete")); ?>" method="POST">
            <a class="btn btn-secondary delete-submit" href="#"><i class="icon-trash"></i> &nbsp;<span class="btn-title"><?php echo e(trans('common.delete')); ?></span> </a>
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="model_id" value="<?php echo e($project->id); ?>" />
        </form>

    <?php endif; ?>

<?php $__env->appendSection(); ?>