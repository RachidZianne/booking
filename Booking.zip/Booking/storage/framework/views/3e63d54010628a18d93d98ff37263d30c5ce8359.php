<?php $__env->startSection('language_form'); ?>

    <div class="card">
        <div class="card-header">
            <?php echo e(trans('common.languages')); ?>

        </div>
        <div class="card-block">
            <a href="<?php echo e(route("admin.languages.add")); ?>" class="btn btn-primary mb-3"><?php echo e(trans('admin.new_language')); ?></a>
            <a href="<?php echo e(route("admin.languages.translator")); ?>" class="btn btn-success mb-3"><?php echo e(trans('admin.easy_translator')); ?></a>

            <table class="table table-responsive">
                <tr>
                    <th><?php echo e(trans('common.id')); ?></th>
                    <th><?php echo e(trans("common.title")); ?></th>
                    <th><?php echo e(trans('common.locale')); ?></th>
                    <th><?php echo e(trans("common.author")); ?></th>
                    <th class="center-text"><?php echo e(trans("common.active")); ?></th>
                    <th class="center-text"><?php echo e(trans("common.default")); ?></th>
                    <th class="center-text"></th>
                </tr>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="title"><?php echo e($language->id); ?></td>
                        <td><?php echo e($language->language); ?></td>
                        <td><?php echo e($language->code); ?></td>
                        <td><?php if(isset($language->author_url)): ?><a href="<?php echo e($language->author_url); ?>" target="_blank"><?php echo e($language->author); ?></a><?php else: ?><?php echo e($language->author); ?><?php endif; ?></td>
                        <td class="center-text"><?php if($language->active == 1): ?> <i class="text-green fa fa-check-circle fa-2x"></i> <?php else: ?> <i class="text-grey fa fa-power-off fa-2x"></i>  <?php endif; ?></td>
                        <td class="center-text"><?php if((Config::get("app.locale") == $language->code)): ?> <i class="text-green fa fa-check-circle fa-2x  <?php if($language->code == 'en'): ?> readonlytrans <?php endif; ?>"></i> <?php endif; ?></td>
                        <td class="td-fit" align="right">
                            <?php if((Config::get("app.locale") != $language->code)): ?>
                                <form method="POST" action="<?php echo e(route("admin.languages.default")); ?>" class="inline-form">
                                    <input type="hidden" name="model_id" value="<?php echo e($language->id); ?>"/>
                                    <a class="btn btn-sm btn-success confirm-submit" href="#"><i class="fa fa-home"></i> <?php echo e(trans('common.make_default')); ?> </a>
                                    <?php echo e(csrf_field()); ?>

                                </form>

                            <?php endif; ?>
                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route("admin.languages.update",$language)); ?>"><i class="fa fa-refresh"></i> <?php echo e(trans('common.update')); ?> </a>
                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route("admin.languages.export",$language)); ?>"><i class="fa fa-level-up"></i> <?php echo e(trans('common.export')); ?> </a>
                            <form method="POST" action="<?php echo e(route("admin.languages.delete")); ?>" class="inline-form">
                                <input type="hidden" name="model_id" value="<?php echo e($language->id); ?>"/>
                                <a class="btn btn-sm btn-outline-danger delete-submit <?php if($language->code == 'en' || (Config::get("app.locale") == $language->code) ): ?> disabled <?php endif; ?>" href="#" ><i class="fa fa-remove"></i> <?php echo e(trans('common.delete')); ?> </a>
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin.languages.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>