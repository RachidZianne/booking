<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> <?php echo e(trans('common.menu')); ?> </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <?php if(Request::has('archive') && Request::input('archive') == 1): ?>
            <a class="btn btn-secondary" href="<?php echo e(Request::fullUrlWithQuery(['archive' => 0])); ?>"><i class="icon-arrow-up"></i> &nbsp;<?php echo e(trans('common.all_tasks')); ?></a>
            <?php else: ?>
                <a class="btn btn-secondary" href="<?php echo e(Request::fullUrlWithQuery(['archive' => 1])); ?>"><i class="icon-arrow-down"></i> &nbsp;<?php echo e(trans('common.active_tasks')); ?></a>
            <?php endif; ?>
            
            <?php echo $__env->yieldContent("extra_menu_buttons"); ?>
        </div>
    </li>
    <?php if($view_type == 'project'): ?>
        <li class="breadcrumb-menu right-side mobile project-navigation">
            <a class="btn btn-secondary btn-open" href="#"><i class="icon-list"></i> <?php echo e(trans('common.section')); ?> </a>
            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                <a class="btn btn-secondary <?php if(isset($subcat_active) && $subcat_active == 'board'): ?> active <?php endif; ?>" href="<?php echo e(route("project",$project)); ?>"><?php echo e(trans('common.board')); ?></a>
                <a class="btn btn-secondary <?php if(isset($subcat_active) && $subcat_active == 'files'): ?> active <?php endif; ?>" href="<?php echo e(route("projects.files",$project)); ?>"><?php echo e(trans('common.files')); ?></a>
                <a class="btn btn-secondary <?php if(isset($subcat_active) && $subcat_active == 'about'): ?> active <?php endif; ?>" href="<?php echo e(route("projects.about",$project)); ?>"><?php echo e(trans('common.about')); ?></a>

            </div>
        </li>
    <?php endif; ?>

</ol>