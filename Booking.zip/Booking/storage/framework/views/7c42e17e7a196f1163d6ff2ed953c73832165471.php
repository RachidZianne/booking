<ol class="breadcrumb responsive-menu">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> <?php echo e(trans('common.menu')); ?> </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="<?php echo e(route("admin.general")); ?>"><i class="fa fa-cog"></i> <?php echo e(trans('common.site_settings')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.preferences")); ?>"><i class="icon-cup"></i> <?php echo e(trans('common.preferences')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.languages.index")); ?>"><i class="fa fa-language"></i> <?php echo e(trans('common.languages')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.themes")); ?>"><i class="fa fa-paint-brush"></i> <?php echo e(trans('common.themes')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.map")); ?>"><i class="fa fa-street-view"></i> <?php echo e(trans('common.location_sharing')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.mail")); ?>"><i class="fa fa-envelope-o"></i> <?php echo e(trans('common.mail_configuration')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.tweaks")); ?>"><i class="icon-equalizer"></i> <?php echo e(trans('common.tweaks')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.api")); ?>"><i class="fa fa-cloud"></i> <?php echo e(trans('common.api')); ?> </a>
            <a class="btn btn-secondary" href="<?php echo e(route("admin.info")); ?>"><i class="fa fa-question-circle"></i> <?php echo e(trans('common.software_info')); ?> </a>
        </div>
    </li>
</ol>