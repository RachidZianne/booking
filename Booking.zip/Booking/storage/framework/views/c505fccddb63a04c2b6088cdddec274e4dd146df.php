<ol class="breadcrumb">
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu mobile">
        <a class="btn btn-secondary btn-open" href="#"><i class="icon-menu"></i> <?php echo e(trans('common.menu')); ?> </a>
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="btn btn-secondary" href="<?php echo e(route("user.index")); ?>"><i class="fa fa-users"></i> <?php echo e(trans('common.users')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("user.new")); ?>"><i class="fa fa-user-plus"></i> <?php echo e(trans('common.new_user')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("user.team.index")); ?>"><i class="fa fa-user-circle"></i> <?php echo e(trans('common.teams')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("user.team.new")); ?>"><i class="fa fa-user-circle-o"></i> <?php echo e(trans('common.new_team')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("user.clients")); ?>"><i class="icon-people"></i> <?php echo e(trans('common.clients')); ?></a>
            <a class="btn btn-secondary" href="<?php echo e(route("user.invited")); ?>"><i class="icon-envelope-letter"></i> <?php echo e(trans('common.invited')); ?></a>
        </div>
    </li>
</ol>