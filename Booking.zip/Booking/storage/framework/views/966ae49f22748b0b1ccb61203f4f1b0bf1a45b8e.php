<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.users", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-users"></i> <?php echo e(trans('common.clients')); ?>

                </div>
                <div class="card-block">
                    <table class="table table-striped table-responsive">
                        <thead>
                        <tr>
                            <th><?php echo e(trans('common.id')); ?></th>
                            <th colspan="2"><?php echo e(trans('common.user')); ?></th>
                            <th><?php echo e(trans('common.email')); ?></th>
                            <th><?php echo e(trans('common.action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                <td><?php echo e($user->id); ?></td>
                                 <td class="">
                                     <div class="avatar">
                                         <img src="<?php echo e(route("avatar",$user)); ?>" class="img-avatar" >
                                         <?php if(($user->last_login)): ?>
                                          <?php if($user->last_login->diffInMinutes() <= 5): ?>
                                              <span class="avatar-status badge-success"></span>
                                          <?php elseif($user->last_login->diffInMinutes() <= 15): ?>
                                              <span class="avatar-status badge-info"></span>
                                          <?php else: ?>
                                              <span class="avatar-status badge-danger"></span>
                                          <?php endif; ?>
                                          <?php else: ?>
                                             <span class="avatar-status badge-default"></span>
                                         <?php endif; ?>
                                     </div>
                                 </td>
                                 <td>
                                     <div> <?php echo e($user->name); ?>

                                         <?php if($user->type == 'root'): ?>
                                             <span class="badge badge-danger"><?php echo e(trans('common.administrator')); ?></span>
                                         <?php endif; ?>
                                     </div>
                                     <div class="small text-muted">
                                         Last login:
                                             <?php if(!empty($user->last_login)): ?>
                                                 <?php echo e($user->last_login->diffForHumans()); ?>

                                             <?php else: ?>
                                                 Never
                                             <?php endif; ?>
                                     </div>
                                 </td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <a  class="btn btn-sm btn-secondary" href="<?php echo e(route("user.edit",$user)); ?>"><i class="fa fa-edit"></i> <?php echo e(trans('common.edit')); ?> </a>
                                    <form method="POST" action="<?php echo e(route("user.delete")); ?>" class="inline-form">
                                        <input type="hidden" name="model_id" value="<?php echo e($user->id); ?>"/>
                                        <a class="btn btn-sm btn-outline-danger delete-submit" href="#"><i class="fa fa-remove"></i> <?php echo e(trans('common.delete')); ?> </a>
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>