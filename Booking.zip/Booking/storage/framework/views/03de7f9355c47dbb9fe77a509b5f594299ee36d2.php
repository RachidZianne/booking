<template id="template-ca-vcard">
    <div class="vcard-comment">
        <div class="field required">
            <label class="label"><?php echo e(trans('common.name')); ?></label>
            <input class="fc-control" type="text" id="pm-vcv-name" value="{{vcardName}}">
        </div>
        <div class="field">
            <label class="label"><?php echo e(trans('common.number')); ?></label>
            <input class="fc-control" type="text" id="pm-vcv-number" value="{{vcardNumber}}">
        </div>
        <div class="field">
            <label class="label"><?php echo e(trans('common.email')); ?></label>
            <input class="fc-control" type="text" id="pm-vcv-email" value="{{vcardEMail}}">
        </div>
        <div class="field">
            <label class="label"><?php echo e(trans('common.address')); ?></label>
            <textarea class="fc-control"  id="pm-vcv-address">{{vcardAddr}}</textarea>
        </div>
        <div class="pb-2 float-right">
            <button class="btn btn-secondary btn-sm reset"><?php echo e(trans('common.reset')); ?></button>
            <button class="btn btn-primary btn-sm hide-po"><?php echo e(trans('common.save')); ?></button>
        </div>
    </div>
</template>

<template id="template-aside-title">
    <span class="task-head-title">{{title}}</span>
    <div class="tags" data-taglist="{{taglist}}">
        {{#tags}}
        <span class="tag">#{{tag.title}}</span>
        {{/tags}}
    </div>
</template>

<template id="template-aside-subtasks">
    <div class="subtasks-section">
        <ul class="subtasks">
            {{#subtasks}}
                {{> partial_task_item}}
            {{/subtasks}}
        </ul>
    </div>
</template>

<template id="template-aside-subtask-add">
    <div class="subtask-add">
        <input type="text" class="form-control addsubtask" placeholder="<?php echo e(trans('common.subtask_title')); ?>"/><button class="fc-btn mt-1 createnewsubtask"><?php echo e(trans('common.save')); ?></button>
    </div>
</template>

<template id="template-subtask-item">
    <li class="subtask" data-subtaskid="{{id}}" data-userid="{{user_id}}" data-assigned="{{assigned_to}}" data-duedate="{{due_date}}"><span class="subtask-checkbox {{#done}} done {{/done}}"></span><div class="title"><div class="head"><div class="head-text">{{title}}</div><div class="head-details"><span class="subtask-duedate">{{#due_date}} — {{due_date}} {{/due_date}}</span> {{> partial_avatar}} </div></div><div class="tools"><i class="icon-user subtask-actionable" data-action="user" data-toggle="popover"></i><i class="icon-calendar subtask-actionable" data-action="calendar" data-toggle="popover"></i> <i class="icon-trash subtask-delete"></i> <i class="icon-pencil subtask-rename"></i> </div> </div> </li>
</template>

<template id="template-aside-details">
    <?php echo e(trans('common.in')); ?> <a href="">{{sectionname}}</a> – <?php echo e(trans('common.posted')); ?> <a href="">{{time}}</a>
</template>

<template id="template-subtask-item-avatar">
    {{#assigned_to}}<img class="avatar avatar-small avatar-circle align-top" src="<?php echo e(route("avatar")); ?>/{{assigned_to}}">{{/assigned_to}}
</template>

<template id="template-aside-assign">
    <a href="" class="assigned-user" data-assigneduser="{{assigned.id}}">{{#assigned}} <i class="icon-user"></i> <?php echo e(trans('common.assigned_to')); ?> {{assigned.name}} {{/assigned}}</a>{{^assigned}} <?php echo e(trans('common.not_assigned')); ?> {{/assigned}}
    |   {{#due}}<?php echo e(trans('common.due_in')); ?> <a href="" class="duedateat" data-duedateat="{{due_org}}">{{due}}</a> {{/due}} {{^due}} <?php echo e(trans('common.no_due_date')); ?> {{/due}}
</template>

<template id="template-aside-fake-comment">
    <li class="comment pending">
        <div class="comment-avatar">
            <img class="comment-avatar-img" src="<?php echo e(route("avatar")); ?>/<?php echo e(Auth::id()); ?>" />
        </div>
        <div class="comment-details">
            <span class="name"><?php echo e(Auth::user()->name); ?></span>
            <span class="text">{{{text}}}</span>
            <div class="comment-meta"><?php echo e(trans('common.just_now')); ?></div>
        </div>
    </li>
</template>
<template id="template-aside-comments">
    {{#comments}}
    <li class="comment" data-taskcommentid="{{id}}" data-userid="{{user_id}}" data-canedit="{{is_comment_owner}}">
        <div class="comment-avatar">
            <img class="comment-avatar-img" src="<?php echo e(route("avatar")); ?>/{{user_basic.id}}{{^user_basic.id}}0{{/user_basic.id}}" />
        </div>
        <div class="comment-details">
            <span class="name">{{user_basic.name}}{{^user_basic.name}}User{{/user_basic.name}}</span>
            <span class="text">{{{content}}}</span>
            {{#attachment_files.length}}
            <div class="comment-attachments">
               <ul class="attachments">
                   {{#attachment_files}}
                    <li class="attachment download-attachment" data-attchid="{{id}}" data-ext="{{ext}}"><i class="icon-doc"></i> {{name}}</li>
                   {{/attachment_files}}
               </ul>
            </div>
            {{/attachment_files.length}}
            {{#attachment_vcard.length}}
                {{#attachment_vcard}}
                <div class="comment-vcard">
                    <a href="#" target="_blank" class="download-attachment" data-attchid="{{id}}">
                        <div class="snf-lg user-id snf-inline snf-height"> </div>
                        <span class="vcard-name">{{name}}</span>
                    </a>
                </div>
                {{/attachment_vcard}}
            {{/attachment_vcard.length}}
                {{#attachment_location}}
                <div class="comment-location">
                    <a href="https://www.google.com/maps/@{{location.lat}},{{location.long}},17z?hl=en" target="_blank">
                    <?php if(!empty(Settings::gets("location_embed_api"))): ?>
                    <div style="text-align: center">
                        <iframe
                                width="340"
                                height="130"
                                frameborder="0" style="border:0"
                                align="middle"
                                src="https://www.google.com/maps/embed/v1/view?key=<?php echo e(Settings::gets("location_embed_api")); ?>&center={{location.lat}},{{location.long}}&zoom=17" allowfullscreen>
                        </iframe>
                    </div>
                    <?php else: ?>
                        <div class="gmaps-icon"> </div>
                    <?php endif; ?>
                    <span class="location-name">{{location.name}}</span>
                    </a>
                </div>
                {{/attachment_location}}
            <div class="comment-meta">
                <span class="time" data-created="{{created_at}}"><?php echo e(trans('common.just_now')); ?></span>{{#edited}}<sup class="edited"><i class="fa fa-asterisk" title="<?php echo e(trans('common.edited_on')); ?> {{updated_at}}"></i>{{/edited}}</sup><span class="like-action">{{> partial_like}}</span>
                <?php if(Auth::user()->isStaff()): ?> <span class="remove-comment {{#is_comment_owner}}deleteable{{/is_comment_owner}} {{#is_user_admin}}deleteable{{/is_user_admin}}">
                <i class="fa fa-remove"></i>
                </span> <?php endif; ?>
            </div>
        </div>
    </li>
    {{/comments}}
</template>
<template id="template-aside-comment-like">
   {{#likes_count}}· <i class="fa fa-heart likes-icon"></i> <span class="likes-counter">{{likes_count}}</span> like this{{/likes_count}} – {{#is_comment_owner}}<span class="edit"> <a href="#" class="edit-this-comment">Edit</a> ·</span>{{/is_comment_owner}} {{#liked_by_auth_user}}<a class="comment-unlike" href="#">Unlike</a>{{/liked_by_auth_user}}{{^liked_by_auth_user}}<a class="comment-like" href="#">Like</a>{{/liked_by_auth_user}}
</template>

<template id="template-edit-aside">
    <aside class="aside aside-menu aside-menu-edit">
        <div class="task-parent" data-taskid="{{taskid}}">
            <div class="task-head">
                <a class="close-et-button close-button"><i class="fa fa-remove"></i></a>
                <div class="action-buttons">
                    <form class="inline-form" method="POST" action="<?php echo e(route("tasks.delete")); ?>">
                    <button type="button" class="delete-submit fc-btn bg-danger fc-btn-m remove-edits-button"><?php echo e(trans('common.delete')); ?></button>
                        <input type="hidden" name="model_id" value="{{taskid}}" />
                        <?php echo e(csrf_field()); ?>

                    </form>
                    <button class="fc-btn fc-btn-m save-edits-button"><?php echo e(trans('common.save')); ?></button>
                </div>
            </div>
            <div class="details">
               <ul class="list-edit">
                    <li>
                        <input type="text" class="tedit title" value="{{title}}" placeholder="<?php echo e(trans('common.title')); ?>" name="title">
                    </li>
                    <li>
                       <label><?php echo e(trans('common.tags')); ?></label>
                       <input type="text" class="tedit normal tags" value="{{taglist}}" placeholder="<?php echo e(trans('common.select_tags')); ?>" name="tags">
                    </li>
                    <li>
                       <label><?php echo e(trans('common.assigned')); ?></label>
                       <input type="text" class="tedit normal assigned" value="{{assigned}}" placeholder="<?php echo e(trans('common.assigned_to')); ?>" name="assigned">
                    </li>
                    <li>
                       <label><?php echo e(trans('common.due_at')); ?></label>
                       <input type="text" class="tedit normal dueat" value="{{due}}" placeholder="<?php echo e(trans('common.due_at')); ?>" name="due">
                    </li>
               </ul>
                <input type="hidden" name="taskid" class="tedit" value="{{taskid}}" />
            </div>
        </div>
    </aside>
</template>

<div class="modal fade" id="template-locationpick" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-primary" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(trans('common.location_pick')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="pickedmap" style="width: 100%; height: 400px;"></div>
                <div class="form-group mt-3">
                    <label><?php echo e(trans('common.address')); ?></label>
                    <input class="fc-control" id="mp-addr" />
                </div>
                <div class="row">
                    <div class="col-md-6 col-xs-12 col-lg-6">
                        <div class="form-group">
                            <label><?php echo e(trans('common.latitude')); ?></label>
                            <input class="fc-control" id="mp-lat" />
                        </div>
                    </div>
                    <div class="col-md-6  col-xs-12 col-lg-6">
                        <div class="form-group">
                            <label><?php echo e(trans('common.longitude')); ?></label>
                            <input class="fc-control" id="mp-long" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="mp-reset"><?php echo e(trans('common.reset')); ?></button>
                <button type="button" class="btn btn-primary" id="mp-save"><?php echo e(trans('common.save')); ?></button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
