<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.tasks", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($attachment->task_comment_attachment_type != "location"): ?>
                        <div class="col-md-3 mb-3">
                            <div class="mcard np"> <?php echo e($attachment->type); ?>

                                <div class="attachment-body">
                                    <?php if(is_valid_image_type($attachment->ext)): ?>
                                        <div class="mb-attachment-preview" style="background-image:url('<?php echo e(route("tasks.previewattachmentmed",$attachment)); ?>')">
                                        </div>
                                    <?php else: ?>
                                        <?php if($attachment->task_comment_attachment_type != "vcard"): ?>
                                            <span class="attachment-file">
                                                   <span class="fa-stack fa-lg">
                                                      <i class="fa fa-circle fa-stack-2x"></i>
                                                      <i class="fa fa-<?php echo e(fa_file($attachment->ext)); ?> fa-stack-1x fa-inverse"></i>
                                                    </span>
                                            </span>

                                        <?php else: ?>
                                            <span class="attachment-file">
                                                   <span class="fa-stack fa-lg">
                                                      <i class="fa fa-circle fa-stack-2x"></i>
                                                      <i class="fa fa-vcard-o fa-stack-1x fa-inverse"></i>
                                                    </span>
                                            </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>

                                <a class="attachment-link" href="<?php echo e(route("tasks.downloadattachment",$attachment)); ?>">
                                    <img class="avatar-responsive-height avatar-circle" src="<?php echo e(route("avatar",$attachment->taskComment->user_id)); ?>"> <span class="attachment-title" title="<?php echo e($attachment->name); ?>"><?php echo e(str_limit($attachment->name,16)); ?></span>
                                    <span class="btn btn-outline-primary float-right"><i class="fa fa-download"></i></span>
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-3"></div>
                        <div class="col-md-6 mb-3">
                            <div class="mcard">
                                <h5><?php echo e(trans("common.no_files")); ?></h5>
                                <p class="help-text"><?php echo e(trans("messages.no_files_found")); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
    </div>


<?php $__env->appendSection(); ?>

<?php $__env->startSection("extra_js"); ?>
<script type="text/javascript">

</script>
<?php $__env->appendSection(); ?>

<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>