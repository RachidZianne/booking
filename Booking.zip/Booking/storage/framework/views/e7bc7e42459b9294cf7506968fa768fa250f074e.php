<?php $__env->startSection("content"); ?>
    <form class="cform form-horizontal" method="POST" action="<?php echo e(route("inst2Save")); ?>">
        <h3>Site Configuration</h3>
        <div class="form-group">
            <label class="col-sm-2 control-label">Site Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Site or Business Name" name="sitename" value="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">Site URL</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Site URL" name="siteurl" value="<?php echo e(url('')); ?>">
                <div class="help-block">Without trailing slash "/" in the end</div>
            </div>
        </div>
        <hr />
        <div class="form-group">
            <label class="col-sm-2 control-label">Admin Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Name" name="aname" value="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">Admin Email</label>
            <div class="col-sm-10">
                <input type="email" class="form-control" placeholder="Admin Email" name="aemail">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">Admin Password  </label>
            <div class="col-sm-10">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-eye"></i></div>
                    <input type="text" class="form-control" placeholder="Admin Password" name="apass">
                </div>
            </div>
        </div>
        <button class="btn btn-success" type="submit">Continue</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("install.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>