<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.general_save')); ?>">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(trans('admin.general_settings')); ?>

                        </div>
                        <div class="card-block">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('admin.site_name')); ?></label>
                                            <input type="text" class="form-control" name="site_name" placeholder="<?php echo e(trans('admin.site_name')); ?>" value="<?php echo e(Settings::gets("site_name")); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('admin.site_url')); ?></label>
                                            <input type="text" class="form-control" name="site_url" placeholder="<?php echo e(trans('admin.site_url')); ?>" value="<?php echo e(Config::get("app.url")); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('admin.timezone')); ?></label>
                                           <?php echo Timezone::selectForm(Settings::gets("timezone"),trans('admin.timezone'),['class' => 'form-control','name' => 'timezone']); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(trans('admin.start_of_week')); ?></label>
                                            <select name="firstday" class="form-control">
                                                <option value="0"  <?php if(Settings::gets("start_day") == "0"): ?> selected <?php endif; ?> >Sunday</option>
                                                <option value="1"  <?php if(Settings::gets("start_day") == "1"): ?> selected <?php endif; ?>>Monday</option>
                                                <option value="2"  <?php if(Settings::gets("start_day") == "2"): ?> selected <?php endif; ?>>Tuesday</option>
                                                <option value="3"  <?php if(Settings::gets("start_day") == "3"): ?> selected <?php endif; ?>>Wednesday</option>
                                                <option value="4"  <?php if(Settings::gets("start_day") == "4"): ?> selected <?php endif; ?>>Thursday</option>
                                                <option value="5"  <?php if(Settings::gets("start_day") == "5"): ?> selected <?php endif; ?>>Friday</option>
                                                <option value="6"  <?php if(Settings::gets("start_day") == "6"): ?> selected <?php endif; ?>>Saturday</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="name">Logo</label>
                                            <div class="admin-logo-container">
                                                <img src="<?php echo e(route("logo")); ?>" class="logo-admin"/>
                                            </div>
                                            <input type="file" class="form-control" name="logo">
                                            <p class="text-muted"><?php echo e(trans('admin.rec_logo_size')); ?>: 440x100</p>
                                        </div>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php echo e(csrf_field()); ?>

        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>