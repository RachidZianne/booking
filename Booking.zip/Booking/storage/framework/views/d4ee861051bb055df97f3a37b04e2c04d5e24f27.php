<template id="template-notification-item">
    <a class="dropdown-item" href="{{uri}}" data-notid="{{notification_id}}">
        {{{text}}}
        <div class="details">
            <i class="fa fa-clock-o"></i> <span class="time">{{time}}</span>
        </div>
    </a>
</template>

<template id="template-comment-attach">
    <li class="dz-preview dz-file-preview cattachment">
        <div class="dz-filename">
            <i class="icon-doc"></i> <span data-dz-name></span> <span class="remove remove-attachment"><i class="fa fa-remove"></i></span>
            <div class="progress progress-xs my-3">
                <div class="progress-bar bg-info" role="progressbar" data-dz-uploadprogress style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
        <div class="dz-progress"><span class="dz-upload" ></span></div>
        <div class="dz-success-mark"><span></span></div>
        <div class="dz-error-mark"><span></span></div>
        <div class="dz-error-message"><span data-dz-errormessage></span></div>
    </li>
</template>
<template id="template-task-item">
    <li class="task-item-wrapper" data-taskid="{{taskid}}">
        <a class="task-item" data-taskid="{{taskid}}"><span class="task-checkbox"></span> {{tasktitle}}</a>
    </li>
</template>
<template id="template-section">
    <div class="section kanban-view" data-sectionId="{{sectionid}}" data-sectiontitle="{{sectiontitle}}">
        <div class="task-section-title"><span class="section-title">{{sectiontitle}}</span>  <i class="icon-arrow-down section-options" data-toggle="popover" data-placement="bottom"></i></div>
        <div class="task-section">
            <div class="task-body">
                <ul class="task-list"></ul>
            </div>
        </div>
        <div class="task-section-newtask">
            <div class="new-task-label">
                <i class="fa fa-plus"></i> <?php echo e(trans('common.new_task')); ?>

            </div>
            <div class="quick-task hide">
                <textarea maxlength="191" class="comment-text" placeholder="<?php echo e(trans('common.new_task')); ?>"></textarea>
                <input type="hidden" class="assigned_to" name="assigned_to">
                <input type="hidden" class="due_date" name="due_date">
                <input type="hidden" class="tags" name="tags">
                <ul class="quick-task-actions">
                    <li class="task-action" data-action="user" data-toggle="popover" data-placement="top" data-content=""><i class="icon-user"></i></li>
                    <li class="task-action" data-action="calendar" data-toggle="popover" data-placement="top" data-content=""><i class="icon-calendar"></i></li>
                    <li class="task-action" data-action="tag" data-toggle="popover" data-placement="top" data-content=""><i class="icon-tag"></i></li>
                    <li class="save-button"> <button class="save task-save"><?php echo e(trans('common.save')); ?></button> </li>
                </ul>
            </div>
        </div>
        <input type="hidden" class="order" value="">
    </div>
</template>
<template id="template-new-section">
    <div class="section kanban-view pending">
        <div autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="task-section-title" contenteditable="true" placeholder="<?php echo e(trans('common.new_section')); ?>"></div>
        <div class="task-section">
            <div class="task-body">
                <ul class="task-list"></ul>
            </div>
        </div>
        <div class="task-section-newtask">
        </div>
    </div>
</template>
<template id="template-section-options">
    <ul class="fc-list section-action-choose">
        <li class="rename"><?php echo e(trans('common.rename')); ?></li>
        <li class="delete"><?php echo e(trans('common.delete')); ?></li>
        <li class="archive"><?php echo e(trans('common.archive_done_tasks')); ?></li>
    </ul>
</template>
<template id="task-action-user">
    <input type="hidden" class="action">
    <div class="task-action-label">
    </div>
    <div class="choose-user-field">
        <ul class="choose-user">
            <?php $__currentLoopData = $public_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-userid="<?php echo e($puser->id); ?>" data-name="<?php echo e($puser->name); ?>"><img src="<?php echo e(route("avatar",$puser->id)); ?>"/> <?php echo e($puser->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</template>
<template id="task-action-calendar">
    <input type="hidden" class="action">
    <div class="task-action-label">
    </div>
    <div class="datechoose"></div>
</template>
<template id="task-action-tag">
    <input type="hidden" class="action">
    <div class="task-action-label selectizetag">
        <input type="text" class="task-action-control"  value="" placeholder="<?php echo e(trans('common.select_tags')); ?>" />
    </div>
    <div class="choose-tag-field">
        <h6><?php echo e(trans('common.most_used_tags')); ?></h6>
        <ul class="choose-tag">
            {{#mostusedtags}}
            <li data-tag="{{.}}">{{.}}</li>
            {{/mostusedtags}}
        </ul>
    </div>
</template>
<template id="task-action-top-label">
    <span class="chosen">{{content}}</span>
    <span class="delete"><i class="fa fa-remove"></i></span>
</template>


<template id="project-choose-type">
    <div class="project-choose project-type-choose">
        <div class="col-md-12 col-xs-12 col-lg-12">
            <div class="radio">
                <label for="radio1">
                    <input class="radio visibleInput"  id="radio1" type="radio" name="projecttype" value="new" checked="checked"> <span><?php echo e(trans('common.new_project')); ?></span>
                    <p><?php echo e(trans('common.start_new_project')); ?></p>
                </label>
            </div>
            <div class="radio">
                <label for="radio2">
                    <input  class="radio visibleInput"  id="radio2" type="radio" name="projecttype" value="template"><span><?php echo e(trans('common.template_project')); ?></span>
                    <p><?php echo e(trans('common.create_template_from_saved')); ?></p>
                </label>
            </div>
        </div>
    </div>
</template>

<template id="project-create-from-tpl">
        <div class="col-md-12 col-xs-12 col-lg-12">
            <h4><?php echo e(trans('common.choose_template')); ?> </h4>
            <select class="form-control select-templates" name="templates">
            </select>
            <a href="#" class="btn btn-secondary show-template-file-upload mt-3"><?php echo e(trans('common.upload_template')); ?></a>
            <div class="hide template-file-outer">
                <hr />
                <h4><?php echo e(trans('common.upload_template')); ?></h4>
                <input class="form-control template-file" name="tplfile" type="file" />
            </div>
        </div>
</template>

<template id="project-choose-privacy">
    <div class="project-choose project-privacy-choose">
        <div class="col-md-12 col-xs-12 col-lg-12">
            <div class="radio">
                <label for="radio1">
                    <input class="radio visibleInput"  id="radio1" type="radio" name="privacy" value="public"> <span><?php echo e(trans('common.privacy_everyone')); ?></span>
                    <p><?php echo e(trans('common.privacy_everyone_msg')); ?></p>
                </label>
            </div>
            <div class="radio">
                <label for="radio2">
                    <input  class="radio visibleInput"  id="radio2" type="radio" name="privacy" value="teams"><span><?php echo e(trans('common.privacy_teams')); ?></span>
                    <p><?php echo e(trans('common.privacy_teams_msg')); ?></p>
                </label>
            </div>
            <div class="radio">
                <label for="radio3">
                    <input class="radio visibleInput" id="radio3" type="radio" name="privacy" value="users"><span><?php echo e(trans('common.privacy_custom')); ?></span>
                    <p><?php echo e(trans('common.privacy_custom_msg')); ?></p>
                </label>
            </div>
            <div class="radio">
                <label for="radio4">
                    <input class="radio visibleInput" id="radio4" type="radio" name="privacy" value="me"><span><?php echo e(trans('common.privacy_me')); ?></span>
                    <p><?php echo e(trans('common.privacy_me_msg')); ?></p>
                </label>
            </div>
        </div>
    </div>
</template>

<template id="project-export-template">
    <form action="<?php echo e(route("projects.tplactions")); ?>" method="POST" enctype="multipart/form-data">

                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">
                            <label class="pt-1 pl-2 strong-label"><?php echo e(trans('common.action')); ?></label>
                        </div>
                    </div>
                    <select class="form-control project-export-format" name="templateaction">
                        <option value="file"><?php echo e(trans('common.download_file')); ?></option>
                        <option value="template"><?php echo e(trans('common.save_template')); ?></option>
                        <option value="importtemplatefile"><?php echo e(trans('common.import_template_file')); ?></option>
                        <option value="importtemplate"><?php echo e(trans('common.import_template')); ?></option>
                    </select>
                </div>
                <div class="tpl-export-actions">
                    <div class="row">
                        <div class="col-md-12">
                            <label class="pt-1 pl-2 strong-label"><?php echo e(trans('common.options')); ?></label>
                        </div>
                    </div>
                        <div class="col-md-12">
                            <input type="checkbox" id="checkbox_s1" name="done_status" value="1"> <label for="checkbox_s1" class="m-label"><?php echo e(trans('common.export_done_status')); ?></label>
                        </div>
                        <div class="col-md-12">
                            <input type="checkbox" id="checkbox_s2" name="assigned_status" value="1"> <label for="checkbox_s2" class="m-label"><?php echo e(trans('common.export_assigned_status')); ?></label>
                        </div>
                        <div id="project_export_title" class="col-md-12 hide">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="pt-1 pl-2 strong-label"><?php echo e(trans('common.template_title')); ?></label>
                                        </div>
                                    </div>
                            <div class="col-md-12">
                                <input class="form-control" name="title" />
                            </div>

                        </div>
                    </div>
                    <div class="col-md-12 tpl-import-actions hide">
                                <div class="import-template-file">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="pt-1 pl-2 strong-label"><?php echo e(trans('common.import_template')); ?></label>
                                        </div>
                                    </div>
                                    <div class="row project-import-tpl-file">
                                        <div class="col-md-12">
                                            <input type="file" class="form-control" name="templatefile">
                                        </div>
                                    </div>
                                    <div class="row project-import-tpl-db">
                                            <div class="col-md-12">
                                                <select class="form-control project-import-template" name="project-import-template">
                                                    <?php if(isset($personal_templates)): ?>
                                                        <?php $__currentLoopData = $personal_templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pstpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($pstpl->id); ?>"><?php echo e($pstpl->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                    </div>
                                </div>
                    </div>
                     <div class="col-md-12">
                            <div class="p-2 text-align-center">
                                <button type="submit" class="btn btn-primary"><?php echo e(trans('common.save')); ?></button>
                                <button type="submit" class="btn btn-outline-secondary"><?php echo e(trans('common.cancel')); ?></button>
                            </div>
                    </div>
        <input type="hidden" name="model_id" class="projectid" value="" />
        <?php echo e(csrf_field()); ?>

    </form>
</template>

<template id="project-choose-teams">
    <input type="text" class="sct-select" />
</template>

<template id="add-task-input">
    <li class="add-subtask-input"><span class="subtask-checkbox readonly"></span> <input class="subtask-input"> </li>
</template>

<template id="mainsection-subtask">
    <li class="subtask" data-subtaskid="{{id}}"><span class="subtask-checkbox"></span>{{content}}</li>
</template>

<div id="input_readonly" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body">
                <input class="form-control readinput" readonly/>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('common.close')); ?></button>
            </div>
        </div>

    </div>
</div>

<div id="snooze_task_modal" class="modal fade snooze-task" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content text-center">
            <div class="modal-body">
                <h4 class="title"><?php echo e(trans('common.snooze_task')); ?></h4>
                <h6 class="subtitle"><?php echo e(trans('common.snooze_until')); ?>:</h6>
                <div class="datepicker-snooze" data-timepicker="true"></div>
                <input class="snoozedate" type="hidden" name="snoozedate" />
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary save"><?php echo e(trans('common.save')); ?></button>
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('common.close')); ?></button>
            </div>
        </div>

    </div>
</div>

<div id="keyboard_shortcuts" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content text-center">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(trans('common.keyboard_shortcuts')); ?></h4>
            </div>
            <div class="modal-body">
               <table class="table table-responsive table-shortcuts table-striped">
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">S</kbd></td>
                       <td class="description"><?php echo e(trans('common.new_section')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">F</kbd></td>
                       <td class="description"><?php echo e(trans('common.toggle_filters')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">]</kbd></td>
                       <td class="description"><?php echo e(trans('common.move_to_next_section')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">[</kbd></td>
                       <td class="description"><?php echo e(trans('common.move_to_prev_section')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">T</kbd></td>
                       <td class="description"><?php echo e(trans('common.new_project')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">N</kbd></td>
                       <td class="description"><?php echo e(trans('common.switch_on_off_nightmode')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">D</kbd></td>
                       <td class="description"><?php echo e(trans('common.mark_currently_open_task')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">Q</kbd></td>
                       <td class="description"><?php echo e(trans('common.close_open_task')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">A</kbd></td>
                       <td class="description"><?php echo e(trans('common.refresh_open_task')); ?></td>
                   </tr>
                   <tr>
                       <td class="key"><kbd class="shortcut">Alt</kbd> + <kbd class="shortcut">Shift</kbd> + <kbd class="shortcut">C</kbd></td>
                       <td class="description"><?php echo e(trans('common.search_open_task')); ?></td>
                   </tr>
               </table>
                <div class="alert alert-warning">
                    <?php echo trans('messages.keyboard_mask',
                    ['firstkey'=> '<kbd class="shortcut">Option</kbd>',
                    'secondkey' => '<kbd class="shortcut">Alt</kbd>']); ?>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('common.ok')); ?></button>
            </div>
        </div>

    </div>
</div>

<div id="create_project_modal" class="modal fade cp-modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body">
                <div class="cp-panel-left text-align-left">
                    <h5>Create project</h5>
                    <input class="form-control" placeholder="Project Name" />

                    <div class="row pt-4">
                        <div class="col-md-12">
                            <input type="radio" name="template" /> Project <br />
                            <p class="help-text">Create new project from scratch</p>
                        </div>
                        <div class="col-md-12">
                            <input type="radio" name="template" /> Template <br />
                            <p class="help-text">Create new project from a saved template, you can import a template file or use one of the saved templates</p>
                        </div>
                    </div>
                </div>
                <div class="cp-panel-right text-align-left">
                    <h6>Settings</h6>

                    <div class="row">
                        <div class="col-md-8">

                            <div class="row pt-2">
                                <div class="col-md-6">
                                    <div class="form-group input-limited">
                                        <label for="name">Start date</label>
                                        <input type="text" class="form-control" placeholder="Starting date">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group input-limited">
                                        <label for="name">End date</label>
                                        <input type="text" class="form-control" placeholder="Starting date">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h6 class="font-little-bold">Sharing</h6>
                            <div class="row pt-2">
                                <div class="col-md-12">
                                    <div class="form-group">
                                       <div class="sharing-form">
                                           <input type="radio"> <label>Everyone</label>
                                       </div>
                                       <div class="sharing-form">
                                           <input type="radio"> <label>Specific teams</label>
                                       </div>
                                       <div class="sharing-form">
                                           <input type="radio"> <label>Specific users and clients</label>
                                       </div>
                                       <div class="sharing-form">
                                           <input type="radio"> <label>Private</label>
                                       </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer text-align-left">
                <button type="button" class="btn btn-primary save">Save</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>


    
