<div class="row project-head">
    <div class="col-md-7">
        <div class="project-detail" data-projectid="<?php echo e($project->id); ?>">
            <h4 class="title"><?php echo e($project->title); ?></h4>
            <h6 class="subtitle"><?php echo e(trans('common.shared_with')); ?>

                <?php if($project->privacy == "teams"): ?>
                    <?php $__currentLoopData = $project->sharedteams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="shared"><?php echo e($steam->team->title); ?></span><?php if(!$loop->last): ?>, <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($project->privacy == "users"): ?>
                    <?php $__currentLoopData = $project->sharedusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $susers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="project-user">
                            <img src="<?php echo e(route("avatar",$susers->user)); ?>" class="avatar avatar-sm avatar-circle"> <span class="shared"><?php echo e($susers->user->name); ?> </span> <?php if($susers->user->type == 'invited'): ?> <i class="fa fa-clock-o invited"></i> <?php endif; ?>
                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($project->privacy == "public"): ?>
                    <span class="shared"><?php echo e(trans('common.privacy_everyone')); ?></span>
                <?php elseif($project->privacy == "me"): ?>
                    <span class="shared"><?php echo e(trans('common.privacy_me')); ?></span>
                <?php endif; ?>
                <?php if(Auth::id() == $project->user_id || Auth::user()->isAdmin()): ?>– <a href="#" data-privacy="<?php echo e($project->privacy); ?>" class="update-privacy" data-projectid="<?php echo e($project->id); ?>" data-sharedwith="<?php if(!($project->sharedteams->isEmpty())): ?><?php echo e($project->sharedteams->pluck('team_id')->toJson()); ?><?php elseif(!($project->sharedusers->isEmpty())): ?><?php echo e($project->sharedusers->pluck('user_id')->toJson()); ?><?php else: ?><?php echo e('[]'); ?><?php endif; ?>"><?php echo e(trans('common.edit_privacy')); ?></a>  <?php endif; ?>

            </h6>
        </div>

    </div>

</div>

<?php $__env->startSection("extra_js"); ?>
    <script type="text/javascript">



    </script>
<?php $__env->appendSection(); ?>