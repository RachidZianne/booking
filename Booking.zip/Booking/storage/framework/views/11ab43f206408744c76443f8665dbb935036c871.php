<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.tasks", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
        <div id="calendar-container">
            <div id="tasks-calendar" class="tasks-calendar"></div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <?php echo $__env->make("fragments.aside_js", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.6.1/fullcalendar.min.js"></script>
    <?php if(is_locale_supported("fullcalendar",App::getLocale())): ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.6.1/locale/<?php echo e(App::getLocale()); ?>.js"></script>
    <?php endif; ?>
    <script type="text/javascript">
        var archive = <?php echo e($with_archive); ?>;
        $(document).ready(function() {

            // page is now ready, initialize the calendar...

            $('#tasks-calendar').fullCalendar({
                events: function(start, end, timezone, callback) {
                    axios({
                        method:'post',
                        url:'<?php echo e(route('tasks.loadtasks')); ?>',
                        data:{
                            start: start,
                            end:end,
                            with_archive: archive
                        }
                    }).then(function(response) {
                        var events = [];
                        var tasks = response.data.data;
                        tasks.forEach(function(element) {
                            if(element.due_date != null){
                                events.push({
                                    id: element.id,
                                    title: element.title,
                                    start: element.due_date,
                                    done: element.done
                                });
                            }
                        });
                        callback(events);
                    });
                },
                height:'parent',
                aspectRatio: 2,
                nowIndicator:false,
                contentHeight:'auto',
                displayEventTime : false,
                firstDay:<?php echo e(Settings::gets("start_day")); ?>,
                    header:{
                    left:   'month basicWeek listMonth',
                    center: 'title',
                    right:  'today prev,next'
                },

                eventRender: function(event, element , view) {
                    var checkbox = $('<span class="task-checkbox readonly"></span>');
                    if(event.done)
                        $(checkbox).addClass('done');


                    if(view.name == "listMonth"){
                        $(element).find(".fc-list-item-marker.fc-widget-content").html(checkbox);
                        $(element).attr("data-taskid",event.id);
                    }
                    else{
                    $(element).find(".fc-content").prepend(checkbox);
                    $(element).attr("data-taskid",event.id);
                    }
                }

            });

            // task event click

            $(document).on("click",".fc-event[data-taskid],.fc-list-item",function(e){
                var taskid = $(this).attr("data-taskid");
                loadTask(taskid);
            });

        });

    </script>
<?php $__env->appendSection(); ?>
<?php $__env->startSection("extra_css"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.6.1/fullcalendar.min.css" />
    <link href="<?php echo e(asset("assets/css/firecamp_calendar.css")); ?>" rel="stylesheet">
<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>