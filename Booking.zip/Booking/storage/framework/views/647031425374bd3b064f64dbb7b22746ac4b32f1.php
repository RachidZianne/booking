<?php $__env->startSection('content'); ?>

    <div class="page-middle">
            <?php if($errors->has('email')): ?>
                <div class="alert alert-danger">
                                        <?php echo e($errors->first('email')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->has('password')): ?>
                    <div class="alert alert-danger">
                                        <?php echo e($errors->first('password')); ?>

                    </div>
            <?php endif; ?>
                <?php if(Config::get("metis.demo") != 1): ?>
                    <div class="card">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <h1><?php echo e(trans('common.login')); ?></h1>
                            <p class="text-muted"><?php echo e(trans('messages.sign_in_account')); ?></p>
                            <div class="input-box">
                                <input type="email" placeholder="<?php echo e(trans('common.email_address')); ?>" name="email" required autofocus >
                            </div>
                            <div class="input-box">
                                <a class="smallbox" href="<?php echo e(route("password.request")); ?>" tabindex="-1">
                                    <?php echo e(trans('common.forgot')); ?>

                                </a>
                                <div class="input-inner-box">
                                    <input type="password" placeholder="<?php echo e(trans('common.password')); ?>" name="password" >
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-centered"><?php echo e(trans('common.login')); ?></button>
                            <a type="button" href="<?php echo e(route("password.request")); ?>" class="btn btn-secondary sm-mobile-only"><?php echo e(trans('common.forgot')); ?></a>
                        </form>
                        
                    </div>
                <?php else: ?>
                    <?php echo $__env->make("auth.demo_login", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.simple', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>