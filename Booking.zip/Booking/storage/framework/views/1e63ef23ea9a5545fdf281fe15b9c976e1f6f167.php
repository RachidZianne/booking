<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.themes_save')); ?>" id="cssform">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e(trans('common.themes')); ?>

                        </div>
                        <div class="card-block">
                            <div class="card-block">

                                <div class="row">
                                    <div class="col-sm-1">
                                        <label for="name">Custom CSS</label>

                                    </div>
                                    <div class="col-sm-11">
                                        <div class="form-group">
                                            <div>
                                                <textarea class="hide" data-lang="css" id="cssdata" name="cssdata"><?php echo e(\App\Hardsetting::gets("customcss")); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <!--/.row-->
                            </div>
                            <div class="form-actions">
                                <button type="button" id="css_savechanges" class="btn btn-primary"><?php echo e(trans('common.save_changes')); ?></button>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php echo e(csrf_field()); ?>

        </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra_js"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/addon/runmode/colorize.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/mode/css/css.min.js"></script>
    <script type="text/javascript">
        myTextArea = document.getElementById("csseditor");
        myHiddenTxt = document.getElementById("cssdata");
        var myCodeMirror = CodeMirror.fromTextArea(myHiddenTxt,{
            theme:'hopscotch',
            lineNumbers:true
        });
        $(document).ready(function(){

            $(document).on("click","#css_savechanges",function(e){
                 $("#cssdata").html(myCodeMirror.getValue());
                 $("#cssform").submit();
            });


        });

    </script>
<?php $__env->appendSection(); ?>
<?php $__env->startSection("extra_css"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/codemirror.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.31.0/theme/hopscotch.min.css" />
<?php $__env->appendSection(); ?>
<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>