<div class="clearfix">
    <div class="float-left">
        <?php if($test): ?>
            <button type="button" class="btn btn-success"><?php echo e(trans('admin.Passed')); ?></button>
        <?php else: ?>
            <button type="button" class="btn btn-danger"><?php echo e(trans('admin.failed')); ?></button>
        <?php endif; ?>
    </div>
    <div class="float-right software-info">
        <?php if($test): ?>
        <small class="text-muted"><?php echo e($success); ?></small>
        <?php else: ?>
        <small class="text-danger"><?php echo e($fail); ?></small>
        <?php endif; ?>
    </div>
</div>