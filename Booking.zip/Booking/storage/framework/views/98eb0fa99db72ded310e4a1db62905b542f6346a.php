<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(Settings::gets("site_name")); ?></title>
    <link href="<?php echo e(asset("assets/css/simple-line-icons.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("assets/css/metis_login.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("custom.css")); ?>" rel="stylesheet">
    <?php echo $__env->renderWhen((Config::get("metis.demo") == 1),"fragments.demo_frag", array_except(get_defined_vars(), array('__data', '__path'))); ?>
</head>

<body class="simple metis-custom metis-login">
<div class="container">
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <div class="alert-heading"><?php echo e(trans('common.error')); ?></div>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent("content"); ?>
</div>
<!-- Bootstrap and necessary plugins -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>