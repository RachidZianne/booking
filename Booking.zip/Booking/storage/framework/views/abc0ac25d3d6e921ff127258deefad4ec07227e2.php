<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row settings-page">

        <div class="col-lg-12 col-md-12">
            <?php echo $__env->yieldContent("language_form"); ?>
        </div>


    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>