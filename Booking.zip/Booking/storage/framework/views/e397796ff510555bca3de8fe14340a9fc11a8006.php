<?php $__env->startSection("breadcrumb"); ?>
    <?php echo $__env->make("menus.tasks", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="mcard mb-5">
                    <h6><?php echo e(trans('common.about_project')); ?></h6>
                    <p class="help-text"><?php echo e(trans('common.created_by')); ?> <?php echo e(isset($project->user->name) ? $project->user->name : trans('common.system')); ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="mcard mb-5">
                    <h6 class="mb-3"><?php echo e(trans('common.progress')); ?></h6>
                    <div class="task-count text-blue">
                        <span class="number"><?php echo e($project->tasks->filter(function($item) { return ($item->done == 0); })->count()); ?></span>
                        <span class="label"><?php echo e(trans('common.tasks_remaining')); ?></span>
                    </div>
                    <div class="task-count text-redish">
                        <span class="number"><?php echo e($project->tasks->filter(function($item) {
                                            if($item->done == 0 && !empty($item->due_date)){
                                             return ($item->due_date->lt(Carbon::now()));
                                            }
                                            else{ return false; }
                                            })->count()); ?></span>
                        <span class="label"><?php echo e(trans('common.tasks_overdue')); ?></span>
                    </div>
                    <div class="task-count text-greenish">
                        <span class="number"><?php echo e($project->tasks->filter(function($item) { return ($item->done == 1); })->count()); ?></span>
                        <span class="label"><?php echo e(trans('common.tasks_completed')); ?></span>
                    </div>
                <div class="chart-wrapper px-3" style="height:175px;">
                    <canvas id="project_stats" class="chart chart-line" height="175"></canvas>
                </div>

            </div>

        </div>
    </div>

<?php $__env->appendSection(); ?>

<?php $__env->startSection("extra_js"); ?>
<script type="text/javascript">

    var project_data = <?php echo $pt_data; ?>

    var labels = Object.keys(project_data);
    var lineChartData = {
        labels : labels,
        datasets : [
            {
                label: 'Tasks Completed',
                backgroundColor : 'rgba(0,191,160,0.2)',
                borderColor : 'rgba(0,191,160,1)',
                pointBackgroundColor : 'rgba(0,191,160,1)',
                pointBorderColor : '#fff',
                spanGaps:true,
                data:Object.values(project_data)
            }
        ]
    }

    var ctx = document.getElementById('project_stats');
    var chart = new Chart(ctx, {
        type: 'line',
        data: lineChartData,
        options: {
            responsive: true,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true,
                        stepSize:1
                    }
                }]
            }
        }

    });


</script>
<?php $__env->appendSection(); ?>

<?php echo $__env->make("master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>