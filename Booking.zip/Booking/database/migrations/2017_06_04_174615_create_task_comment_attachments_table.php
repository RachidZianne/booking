<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTaskCommentAttachmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('task_comment_attachments', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('task_comment_id');
            $table->string('task_comment_attachment_type');
            $table->string('name');
            $table->string('ext')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('task_comment_attachments');
    }
}
