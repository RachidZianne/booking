<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterTasksTableSnooze extends Migration
{

    public function up()
    {
        Schema::table('tasks', function($table) {
            $table->dateTime('snoozed_until')->default(null)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('tasks', function($table) {
            $table->dropColumn('snoozed_until');
        });
    }
}
