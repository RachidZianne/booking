<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Fakerr;
use Faker\Generator as Fagen;
class DemoSeeder extends Seeder
{


    public function run()
    {



    }
}
