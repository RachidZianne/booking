<?php

return [

    'installed' => 1,
    'demo' => '0'

];
