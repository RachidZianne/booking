<?php
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['as' => 'api.', 'middleware' => []], function () {

    Route::group(['prefix' => 'auth','as' => 'auth.', 'middleware' => []], function () {
        Route::get('/token', 'Api\AuthController@generate')->name('generate');
        Route::get('/self', 'Api\AuthController@self')->name('generate');
    });


    Route::group(['prefix' => 'user','as' => 'user.', 'middleware' => ['notbearer']], function () {

        Route::get('/info/{id}', 'Api\UserController@getUser')->name('info');
        Route::get('/search/{name}', 'Api\UserController@searchUser')->name('search');

        Route::post('/create', 'Api\UserController@createUser')->name('create');
        Route::post('/update/{id}', 'Api\UserController@updateUser')->name('update');
        Route::post('/delete', 'Api\UserController@deleteUser')->name('delete');


    });

    Route::group(['prefix' => 'team','as' => 'team.', 'middleware' => ['notbearer']], function () {

        Route::get('/info/{id}', 'Api\TeamController@getTeam')->name('info');
        Route::get('/sections/{id}', 'Api\TeamController@getTeamSections')->name('sections');

        Route::post('/create', 'Api\TeamController@createTeam')->name('create');
        Route::post('/users/add/{id}', 'Api\TeamController@addUser')->name('add');
        Route::post('/users/remove/{id}', 'Api\TeamController@removeUser')->name('remove');

        Route::get('/users/list/{id}', 'Api\TeamController@listUsers')->name('listUsers');
        Route::get('/all', 'Api\TeamController@allTeams')->name('allTeams');

    });

    Route::group(['prefix' => 'project','as' => 'project.', 'middleware' => []], function () {

        Route::get('/info/{id}', 'Api\ProjectController@getProject')->name('info');
        Route::get('/sections/{id}', 'Api\ProjectController@getProjectSections')->name('sections');
        Route::get('/overview', 'Api\ProjectController@overview')->name('overview');

        Route::post('/create', 'Api\ProjectController@createProject')->name('create');
        Route::post('/privacy/add/team/{id}', 'Api\ProjectController@addTeamPrivacy')->name('addTeam');
        Route::post('/privacy/remove/team/{id}', 'Api\ProjectController@removeTeamPrivacy')->name('removeTeam');
        Route::post('/privacy/add/user/{id}', 'Api\ProjectController@addUserPrivacy')->name('addUser');
        Route::post('/privacy/remove/user/{id}', 'Api\ProjectController@removeUserPrivacy')->name('removeUser');
        Route::post('/delete', 'Api\ProjectController@deleteProject')->name('delete');

    });

    Route::group(['prefix' => 'section','as' => 'section.', 'middleware' => []], function () {

        Route::get('/info/{id}', 'Api\SectionController@getSection')->name('info');
        Route::get('/overview', 'Api\SectionController@overview')->name('overview');

        Route::post('/move/{id}', 'Api\SectionController@moveSection')->name('move');
        Route::post('/rename/{id}', 'Api\SectionController@renameSection')->name('rename');
        Route::post('/create', 'Api\SectionController@createSection')->name('create');
        Route::post('/delete', 'Api\SectionController@deleteSection')->name('delete');

    });

    Route::group(['prefix' => 'task','as' => 'task.', 'middleware' => []], function () {

        Route::get('/info/{id}', 'Api\TaskController@getTask')->name('info');

        Route::post('/mark/done/{id}', 'Api\TaskController@markDone')->name('done');
        Route::post('/mark/undone/{id}', 'Api\TaskController@markUndone')->name('undone');
        Route::post('/assign/{id}', 'Api\TaskController@assign')->name('undone');
        Route::post('/archive/{id}', 'Api\TaskController@archive')->name('archive');
        Route::post('/unarchive/{id}', 'Api\TaskController@unarchive')->name('unarchive');
        Route::post('/set/due-date/{id}', 'Api\TaskController@setDueDate')->name('setDueDate');
        Route::post('/unset/due-date/{id}', 'Api\TaskController@unsetDueDate')->name('unsetDueDate');
        Route::post('/add/comment/{id}', 'Api\TaskController@addComment')->name('comment');
        Route::post('/create', 'Api\TaskController@createTask')->name('create');

    });


});

