<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => 'installed'], function () {


Route::group(['middleware' => 'auth'], function () {
    Route::get('/', ['uses' => 'HomeController@overview', 'laroute' => true])->name('overview');
    Route::get('/self', 'HomeController@selfassigned')->name('selfassigned');
    Route::get('/calendar', 'HomeController@calendar')->name('calendar');
    Route::get('/team/{id}',  ['middleware' => 'checkTeam:teamId', 'uses' => 'HomeController@team'])->name('team');
    Route::get('/tag/{tag}', ['laroute' => true, 'uses' => 'HomeController@tag'])->name('tag');

    Route::get('/permalink/task/{alphaid}', ['laroute' => true, 'uses' => 'HomeController@permalinkTask'])->name('permalink.task');
    Route::get('/permalink/comment/{alphaid}', ['laroute' => true, 'uses' => 'HomeController@permalinkComment'])->name('permalink.comment');


    Route::post('/client/search', ['laroute' => true, 'uses' => 'HomeController@clientSearch'])->name('client.search');

    Route::post('/tasks/load', 'TaskController@loadTasks')->name('tasks.loadtasks');
    Route::post('/tasks/add', 'TaskController@addTask')->name('tasks.add');
    Route::post('/tasks/edit', 'TaskController@edit')->name('tasks.edit');
    Route::post('/tasks/check', 'TaskController@checkTask')->name('tasks.check');
    Route::post('/tasks/uncheck', 'TaskController@uncheckTask')->name('tasks.uncheck');

    Route::post('/tasks/subtask/check', 'TaskController@checkSubTask')->name('tasks.subtask.check');
    Route::post('/tasks/subtask/add', 'TaskController@addSubTask')->name('tasks.subtask.add');
    Route::post('/tasks/subtask/uncheck', 'TaskController@uncheckSubTask')->name('tasks.subtask.uncheck');
    Route::post('/tasks/subtask/delete', 'TaskController@deleteSubTask')->name('tasks.subtask.delete');
    Route::post('/tasks/subtask/rename', 'TaskController@renameSubTask')->name('tasks.subtask.rename');
    Route::post('/tasks/subtask/reassign', 'TaskController@reassignSubTask')->name('tasks.subtask.reassign');
    Route::post('/tasks/subtask/duedate', 'TaskController@dueSubTask')->name('tasks.subtask.duedate');

    Route::post('/tasks/move', 'TaskController@move')->name('tasks.move');
    Route::post('/tasks/comments/add', 'TaskController@addComment')->name('tasks.addcomment');
    Route::post('/tasks/comments/edit', 'TaskController@editComment')->name('tasks.editcomment');
    Route::post('/tasks/comments/load', 'TaskController@commentLoad')->name('tasks.commentload');
    Route::post('/tasks/comments/load-live', 'TaskController@commentLoadLive')->name('tasks.commentloadlive');
    Route::post('/tasks/comments/attach', 'TaskController@commentAttach')->name('tasks.commentattach');
    Route::post('/tasks/comments/like', 'TaskController@commentLike')->name('tasks.commentlike');
    Route::post('/tasks/comments/unlike', 'TaskController@commentUnlike')->name('tasks.commentunlike');
    Route::get('/tasks/comments/attachment/{id?}', 'TaskController@downloadAttachment')->name('tasks.downloadattachment');
    Route::get('/tasks/comments/preview/small/attachment/{id?}', ['laroute' => true, 'uses' => 'TaskController@previewAttachment'])->name('tasks.previewattachment');
    Route::get('/tasks/comments/preview/medium/attachment/{id?}', ['laroute' => true, 'uses' => 'TaskController@previewAttachmentMedium'])->name('tasks.previewattachmentmed');
    Route::get('/tasks/comments/preview/custom/attachment/{id?}', ['laroute' => true, 'uses' => 'TaskController@previewAttachmentCustom'])->name('tasks.previewattachmentcust');
    Route::post('/tasks/delete-task', 'TaskController@deleteTask')->name('tasks.delete');
    Route::post('/tasks/snooze-task', 'TaskController@snoozeTask')->name('tasks.snooze');
    Route::post('/tasks/unsnooze-task', 'TaskController@unsnoozeTask')->name('tasks.unsnooze');
    Route::post('/tasks/comments/delete', 'TaskController@deleteTaskComment')->name('tasks.deleteComment');

    Route::post('/sections/add', 'SectionController@addSection')->name('sections.add');
    Route::post('/sections/rename', 'SectionController@renameSection')->name('sections.rename');
    Route::post('/sections/delete', 'SectionController@deleteSection')->name('sections.delete');
    Route::post('/sections/archive', 'SectionController@archiveSectionTasks')->name('sections.archive');
    Route::post('/sections/resortTasks', 'SectionController@resortTasks')->name('sections.resorttasks');

    Route::get('/media/avatar/{id?}', ['uses' => 'MediaController@avatar' , 'laroute' => true])->name('avatar');

    Route::get('/project/{id}', ['uses' => 'ProjectController@view' , 'laroute' => true])->name('project');
    Route::post('/projects/create', ['uses' => 'ProjectController@createProject','laroute' => true])->name('projects.create');
    Route::post('/projects/update-privacy', ['uses' => 'ProjectController@updatePrivacy','laroute' => true])->name('projects.updateprivacy');
    Route::post('/projects/delete', ['uses' => 'ProjectController@deleteProject' , 'laroute' => true])->name('projects.delete');
    Route::post('/projects/archive', ['uses' => 'ProjectController@archiveProject' , 'laroute' => true])->name('projects.archive');
    Route::post('/projects/rename', ['uses' => 'ProjectController@renameProject' , 'laroute' => true])->name('projects.rename');
    Route::post('/projects/templates/actions', ['uses' => 'ProjectController@TemplateactionProject' , 'laroute' => true])->name('projects.tplactions');
    Route::post('/projects/loadTemplates', ['uses' => 'ProjectController@loadTemplates' , 'laroute' => true])->name('projects.loadTemplates');
    Route::post('/projects/createFromTemplate', ['uses' => 'ProjectController@createFromTemplate' , 'laroute' => true])->name('projects.createFromTemplate');

    Route::get('/projects/files/{id}', ['uses' => 'ProjectController@files' , 'laroute' => true])->name('projects.files');
    Route::get('/projects/about/{id}', ['uses' => 'ProjectController@about' , 'laroute' => true])->name('projects.about');


    Route::get('/profile', 'ProfileController@me')->name('profile');
    Route::get('/profile/change-password', 'ProfileController@changePw')->name('profile_changepw');
    Route::post('/profile', ['uses' => 'ProfileController@meSave'])->name('profile_save');
    Route::post('/profile/save-password', ['uses' => 'ProfileController@changePwSave'])->name('profile_savepw');

    // Templates
    Route::get('/profile/templates', 'ProfileController@projectTemplates')->name('profile.templates');
    Route::get('/profile/templates/download/{id}', 'ProfileController@projectTemplateDownload')->name('profile.template_download');
    Route::post('/profile/templates/delete', 'ProfileController@deleteProjectTemplate')->name('profile.template_delete');
    Route::post('/profile/templates/import', 'ProfileController@importProjectTemplate')->name('profile.template_import');
    Route::post('/profile/templates/rename', 'ProfileController@renameProjectTemplate')->name('profile.template_rename');


    // Notifications controllers
    Route::group(['laroute' => true], function () {

        Route::get('/notifications/get', 'NotificationController@getLatest')->name('notifications.get');
        Route::get('/notifications/task/view/{id?}', 'NotificationController@redirectTask')->name('notifications.task_view');
        Route::get('/notifications/task/comment/{id?}', 'NotificationController@redirectTaskComment')->name('notifications.task_comment');
        Route::post('/notifications/read', 'NotificationController@markRead')->name('notifications.mark_read');

    });



    // Admin
    Route::group(['prefix' => 'user','as' => 'user.', 'middleware' => 'admin'], function () {

        Route::get('/', 'UserController@index')->name('index');
        Route::get('/view/{id}', 'UserController@view')->name('view');
        Route::get('/edit/{id}', 'UserController@edit')->name('edit');
        Route::get('/new', 'UserController@create')->name('new');
        Route::post('/new', 'UserController@store')->name('store');
        Route::post('/delete', 'UserController@deleteUser')->name('delete');

        Route::get('/teams', 'UserController@teamIndex')->name('team.index');
        Route::get('/teams/new', 'UserController@teamNew')->name('team.new');
        Route::get('/teams/edit/{id}', 'UserController@teamEdit')->name('team.edit');
        Route::post('/teams/new', 'UserController@teamStore')->name('team.store');
        Route::post('/teams/delete', 'UserController@deleteTeam')->name('team.delete');
        Route::get('/clients', 'UserController@clientIndex')->name('clients');
        Route::get('/invited', 'UserController@invitedIndex')->name('invited');
        Route::post('/invite/resend', 'UserController@resendInvite')->name('resend_invite');
        Route::post('/invite/send', 'UserController@sendInvite')->name('send_invite');


    });

    // Admin Info
    Route::group(['prefix' => 'admin','as' => 'admin.', 'middleware' => 'admin'], function () {

        Route::get('/', 'AdminController@general')->name('general');
        Route::get('/preferences', 'AdminController@preferences')->name('preferences');
        Route::post('/preferences/save', 'AdminController@preferencesSave')->name('preferences_save');
        Route::get('/mail', 'AdminController@mail')->name('mail');
        Route::post('/mail/save', 'AdminController@mailSave')->name('mail_save');
        Route::get('/location', 'AdminController@map')->name('map');
        Route::post('/location/save', 'AdminController@mapSave')->name('map_save');
        Route::post('/save', 'AdminController@generalSave')->name('general_save');
        Route::get('/info', 'AdminController@info')->name('info');
        Route::post('/log', 'AdminController@downloadLog')->name('log');
        Route::get('/history', 'AdminController@history')->name('history');
        Route::get('/tweaks', 'AdminController@tweaks')->name('tweaks');
        Route::post('/tweaks/save', 'AdminController@tweaksSave')->name('tweaks_save');
        Route::get('/themes', 'AdminController@themes')->name('themes');
        Route::post('/themes/save', 'AdminController@themesSave')->name('themes_save');
        Route::post('/flush-cache', 'AdminController@flushCache')->name('flushcache');
        Route::get('/api', 'AdminController@api')->name('api');
        Route::post('/api/delete', 'AdminController@apiDelete')->name('api_delete');
        Route::post('/api/regenerate', 'AdminController@apiRegen')->name('api_regen');
        Route::post('/api/oauth', 'AdminController@oathToggle')->name('oauth_toggle');

        Route::get('/insight/teams', 'InsightController@teams')->name('insight.teams');
        Route::get('/insight/projects', 'InsightController@projects')->name('insight.projects');

        Route::group(['laroute' => true,'as' => 'languages.', 'prefix' => 'languages'], function () {

            Route::get('/', 'LanguagesController@index')->name('index');
            Route::get('/new', 'LanguagesController@add')->name('add');
            Route::post('/new', 'LanguagesController@create')->name('create');
            Route::get('/translator', 'LanguagesController@easyTranslator')->name('translator');
            Route::post('/translator', 'LanguagesController@saveEasyTranslator')->name('saveTranslator');
            Route::get('/export/{id}', 'LanguagesController@getExport')->name('export');
            Route::get('/update/{id}', 'LanguagesController@updateLanguage')->name('update');
            Route::post('/update/{id}', 'LanguagesController@SaveUpdateLanguage')->name('saveUpdateLanguage');
            Route::post('/delete', 'LanguagesController@deleteLanguage')->name('delete');
            Route::post('/default', 'LanguagesController@defaultLanguage')->name('default');

        });

    });

    // Updates routes
    Route::group(['prefix' => 'update','as' => 'update.', 'middleware' => 'admin'], function () {

        Route::get('/link', 'UpdatesController@link')->name('link');
        Route::post('/link', 'UpdatesController@linkSave')->name('link_save');
        Route::post('/check', 'UpdatesController@check')->name('check');
        Route::post('/check-updates', 'UpdatesController@checkUpdates')->name('check-updates');
        Route::post('/download-updates', 'UpdatesController@downloadUpdate')->name('download-updates');
        Route::get('/apply', 'UpdatesController@ApplyUpdates')->name('apply-updates');



    });

});


Route::get('/logout', 'HomeController@logout')->name('logout');
Route::get('/logo.png', 'MediaController@logo')->name('logo');
Route::get('/custom.css', 'MediaController@customCss')->name('customcss');


// Alias
Route::get('/home', function (){
    return redirect()->route('overview');
})->name('home');




// Auth routes

Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('login', 'Auth\LoginController@login');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');

// Password Reset Routes...
Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('password.change');


// Invite

Route::get('invitation/accept/{token}', 'InvitationController@form')->name('invite.new');
Route::post('invitation/accept/{token}', 'InvitationController@accept')->name('invite.post');


});


// Installation
Route::group(["middleware" => "notinstalled"], function () {
    Route::get('/install', ['as' => 'install', 'uses' => 'InstallController@compatibility']);
    Route::get('/install/step/1', ['as' => 'inst1', 'uses' => 'InstallController@db']);
    Route::post('/install/step/1', ['as' => 'inst1Save', 'uses' => 'InstallController@dbSave']);
    Route::get('/install/step/2', ['as' => 'inst2', 'uses' => 'InstallController@config']);
    Route::post('/install/step/2', ['as' => 'inst2Save', 'uses' => 'InstallController@configSave']);
    Route::get('/install/step/3', ['as' => 'inst3', 'uses' => 'InstallController@setup']);
    Route::post('/install/step/3', ['as' => 'inst3Save', 'uses' => 'InstallController@setupSave']);
    Route::get('/install/done', ['as' => 'inst4', 'uses' => 'InstallController@done']);
});

// Upgrade Controller
Route::group([], function () {
    Route::get('/upgrade', ['as' => 'upgrade', 'uses' => 'UpgradeController@upgrade']);
});