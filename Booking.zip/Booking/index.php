This folder should not be accessible through web <br />
The web document folder should be /public. <a href="http://www.firecrown.io/s/public">More here</a>. <br /><br />

<a href="public/install">Proceed to installation anyway</a> <br /> Or <a href="public">Proceed to site</a>